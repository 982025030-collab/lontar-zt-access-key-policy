from pathlib import Path
import json,reportlab
from reportlab.pdfgen import canvas
from reportlab.lib.colors import HexColor,white
R=Path(__file__).resolve().parents[2]; O=R/'outputs/submissions/computers_security'; W=720
blue=HexColor('#153D59'); light=HexColor('#EEF3F6'); ink=HexColor('#183244')
def box(c,x,y,w,h,title,lines=()):
 c.setFillColor(light);c.setStrokeColor(blue);c.roundRect(x,y,w,h,7,fill=1,stroke=1)
 c.setFillColor(ink);c.setFont('Helvetica-Bold',12);c.drawCentredString(x+w/2,y+h-20,title)
 c.setFont('Helvetica',11)
 for i,s in enumerate(lines):c.drawCentredString(x+w/2,y+h-39-15*i,s)
def arrow(c,a,b):
 import math
 c.setStrokeColor(blue);c.setFillColor(blue);c.setLineWidth(1.4);c.line(*a,*b)
 ang=math.atan2(b[1]-a[1],b[0]-a[0]);p=c.beginPath();p.moveTo(*b)
 for s in [-1,1]:p.lineTo(b[0]-7*math.cos(ang)+s*3.5*math.sin(ang),b[1]-7*math.sin(ang)-s*3.5*math.cos(ang))
 p.close();c.drawPath(p,fill=1,stroke=0)
def start(n,h):
 c=canvas.Canvas(str(O/(n+'.pdf')),pagesize=(W,h));c.setTitle('LONTAR-ZT: '+n);c.setAuthor('LONTAR authors; programmatic redraw 2026-10-29');return c
c=start('framework_comparison',300)
for x,t,ls in [(10,'NIST SP 800-207 / 207A',['Logical architecture','Policy engine / administrator','Policy enforcement points']), (250,'CISA ZTMM v2.0',['Maturity assessment','Identity, devices, networks','Data and application pillars']), (490,'LONTAR-ZT study',['Empirical policy selection','Evidence-bound signed permits','Use-time protected operation'])]:box(c,x,160,220,125,t,ls)
for x,t,ls in [(10,'Network Trust',['Identity and recorded context','Conditional evidence validity']), (250,'Adaptive key authorization',['Permit TTL + evidence deadline','AES-GCM / TLS unchanged']), (490,'Risk-Control',['Security + service losses','Conditional simultaneous bounds'])]:box(c,x,25,220,105,t,ls)
c.save()
c=start('lontar_positioning',350)
box(c,15,235,190,90,'Identity / entitlement',['Validated assertion','Subject and host binding'])
box(c,15,110,190,90,'Recorded posture',['Signed source statement','Source age != query duration'])
box(c,260,170,190,100,'Evidence-bound permit',['Subject / host / version','Expiry / one-use identifier'])
box(c,505,170,195,100,'PEP + key operation',['Use-time checks','Fail closed on rejection'])
arrow(c,(205,265),(260,240));arrow(c,(205,155),(260,200));arrow(c,(450,220),(505,220))
box(c,260,15,190,100,'Offline selection',['Tune -> certify -> lock','No feasible policy -> deny'])
arrow(c,(355,115),(355,170));box(c,505,15,195,100,'Boundary',['No hardware attestation','No production guarantee']);c.save()
c=start('architecture',330)
for x,t,ls in [(10,'Tuning: 16 blocks',['Rank six frozen candidates']), (250,'Certification: 107 blocks',['Two exact loss upper limits']), (490,'Test: 100 blocks',['Locked policy; untouched data'])]:box(c,x,235,220,80,t,ls)
arrow(c,(230,275),(250,275));arrow(c,(470,275),(490,275))
box(c,10,110,340,95,'Primary process-separated testbed',['Identity -> evidence -> gateway -> key service','Actual protected decrypt; single laboratory host'])
box(c,370,110,340,95,'Separate AWS staging',['API Gateway -> issuer / collector / PEP','Cognito M2M, DynamoDB, KMS data-key operation'])
box(c,100,10,520,70,'Inference boundary',['Different operations and environments: no pooled certificate']);c.save()
p=json.loads((R/'outputs/timing_amendment_20261029/FIGURE_TOOL_PROVENANCE.json').read_text());p['renderer']={'library':'ReportLab','version':reportlab.Version};p['new_figures']=['framework_comparison.pdf','lontar_positioning.pdf','architecture.pdf'];(R/'outputs/timing_amendment_20261029/FIGURE_REDRAW_PROVENANCE.json').write_text(json.dumps(p,indent=2)+'\n')
