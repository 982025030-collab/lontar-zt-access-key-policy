import json,hashlib,statistics
from pathlib import Path
from collections import Counter,defaultdict
O=Path(__file__).resolve().parent;R=O/'data/lontar-akp-isolated-timing-run-20261029-01'
def read(n):return json.loads((R/n).read_text())
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def stats(v):return {'n':len(v),'min':min(v) if v else None,'median':statistics.median(v) if v else None,'max':max(v) if v else None}
m=json.loads((O/'PUBLIC_SHA256.json').read_text());assert all(digest(O/n)==h for n,h in m.items())
rows=read('route_results.json');by={r['case']:r for r in rows};pairs=[]
for r in rows:
 if r.get('section') not in ('deadline_probe','age_probe') or not r['case'].endswith('_use'):continue
 b=r['response'];issue=by[r['case'][:-4]+'_issue'];ib=issue['response'];iat=b.get('permit_issued_ms',ib.get('permit_issued_ms'))
 p={k:r.get(k) for k in ['case','section','policy','repeat','planned_use_delay_s','injected_collector_delay_ms','status']};p.update(gate=b.get('gate',b.get('reason')),evidence_elapsed_ms=b.get('evidence_elapsed_ms'),evidence_stage=b.get('evidence_stage'),evidence_result=b.get('evidence_result'))
 for label,field in [('handler_arrival','start_ms'),('signature_verified','permit_signature_verified_ms'),('final_check','permit_final_check_completed_ms'),('last_check','last_permit_check_ms'),('dispatch','key_call_start_ms')]:
  t=b.get(field);p[label+'_age_s']=(t-iat)/1000 if isinstance(t,int) and isinstance(iat,int) else None
 pairs.append(p)
assert len(pairs)==54
queried=[r for r in rows if 'evidence_query_start_monotonic_ns' in r['response']]
for r in queried:
 b=r['response'];assert isinstance(b.get('evidence_elapsed_ms'),(int,float));assert abs((b['evidence_query_end_monotonic_ns']-b['evidence_query_start_monotonic_ns'])/1e6-b['evidence_elapsed_ms'])<.00001
locks=[r for r in rows if r.get('section')=='server_lock'];assert len(locks)==9 and all(r['status']==403 and not r['response']['key_operation_attempted'] for r in locks)
fails=[r for r in rows if r['status']!=200];assert all(not r['response']['key_operation_attempted'] for r in fails)
groups=defaultdict(list)
for p in pairs:groups[(p['section'],p['policy'],p['planned_use_delay_s'],p['injected_collector_delay_ms'])].append(p)
g=[]
for key,ps in sorted(groups.items(),key=lambda kv:str(kv[0])):
 d=dict(zip(['section','policy','planned_use_delay_s','injected_collector_delay_ms'],key));d.update(n=len(ps),status_counts=dict(Counter(p['status'] for p in ps)))
 for f in ['handler_arrival_age_s','signature_verified_age_s','final_check_age_s','dispatch_age_s','evidence_elapsed_ms']:d[f]=stats([p[f] for p in ps if p[f] is not None])
 g.append(d)
t=read('timeline.json');assert len([e for e in t if e['event']=='lambda_restored' and e['code_and_environment_equal']])==3;assert any(e['event']=='state_restored_readback' and e['equal'] for e in t);assert any(e['event']=='host_stopped_verified' for e in t)
audit=read('lambda_audit.json');collector=[]
for a in audit:
 if '"lontar_timing_audit"' in a['message']:
  try:b=json.loads(a['message']).get('lontar_timing_audit',{})
  except ValueError:continue
  if b.get('role')=='collector':collector.append(b)
collector_by={b.get('correlation_id'):b for b in collector}
correlations=[]
for r in queried:
 if r['response'].get('reason')!='dependency_transport_failure':continue
 b=collector_by.get(r['external_request_id']);correlations.append({'case':r['case'],'correlation_id':r['external_request_id'],'collector_status':b.get('status') if b else None,'collector_response_ms':b.get('response_ms') if b else None,'caller_query_end_ms':r['response']['evidence_query_end_ms']})
(O/'COLLECTOR_TIMEOUT_CORRELATIONS.json').write_text(json.dumps(correlations,indent=2)+'\n')
res={'campaign':read('summary.json'),'archive_sha256':'6cba732e5a1c36c8937b3a17556c8d7b0870295fdd0187737a44697966e09496','public_manifest_files_verified':len(m),'http_counts':dict(Counter(r['status'] for r in rows)),'successful_key_operations':sum(r['response'].get('key_operation_succeeded',False) for r in rows),'issue_use_pairs':54,'query_audits_with_numeric_elapsed':len(queried),'failed_queries_with_numeric_elapsed':sum(r['status']!=200 for r in queried),'deadline_rejections_with_elapsed':[{'case':r['case'],'deadline_ms':r['response'].get('evidence_deadline_ms'),'elapsed_ms':r['response']['evidence_elapsed_ms']} for r in queried if r['response'].get('gate')=='evidence_deadline'],'transport_failures_with_elapsed':[{'case':r['case'],'elapsed_ms':r['response']['evidence_elapsed_ms'],'stage':r['response'].get('evidence_stage'),'result':r['response'].get('evidence_result')} for r in queried if r['response'].get('reason')=='dependency_transport_failure'],'server_lock_denials':len(locks),'all_non200_key_not_attempted':True,'rollback':{'lambda_code_environment_equal':3,'state_readback_equal':True,'host_stopped_verified':True},'groups':g,'collector_audit_events':len(collector),'interpretation':'One actual host-day in project 501250588559, ap-southeast-2. Descriptive amendment, no retuning or new risk certificate. Planned delay is not achieved age; cross-Lambda wall-clock alignment is assumed, not measured. Collector completion during caller timeout is unknown unless separately correlated. No new CloudTrail capture; key non-attempt is handler evidence.'}
(O/'AMENDMENT_ANALYSIS.json').write_text(json.dumps(res,indent=2)+'\n');(O/'AMENDMENT_TIMING_PAIRS.json').write_text(json.dumps(pairs,indent=2)+'\n');print(json.dumps({k:v for k,v in res.items() if k not in ['groups','transport_failures_with_elapsed','deadline_rejections_with_elapsed']},indent=2));print('deadline',len(res['deadline_rejections_with_elapsed']),'transport',len(res['transport_failures_with_elapsed']))
