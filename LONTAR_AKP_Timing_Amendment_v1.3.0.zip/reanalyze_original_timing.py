import json,csv,hashlib,statistics
from pathlib import Path
from collections import defaultdict
OUT=Path(__file__).resolve().parent
SRC=OUT/'data/original_v1.2.0_route_results.json'
rows=json.loads(SRC.read_text()); index={r['case']:r for r in rows}; pairs=[]
for r in rows:
 if r.get('section')!='boundary' or not r['case'].endswith('_use'): continue
 issue=index[r['case'][:-4]+'_issue']; b=r['response']; ib=issue['response']
 iat=b.get('permit_issued_ms',ib.get('permit_issued_ms'))
 p={'case':r['case'],'policy':r['policy'],'profile':r['profile'],'repeat':r['repeat'],'planned_use_delay_s':r['planned_use_delay_s'],'issue_status':issue['status'],'use_status':r['status'],'gate':b.get('gate',b.get('reason')),'iat_ms':iat,'expiry_ms':b.get('permit_expiry_ms',ib.get('permit_expiry_ms')),'retrieval_elapsed_ms':b.get('evidence_elapsed_ms'),'key_attempted':b.get('key_operation_attempted'),'key_succeeded':b.get('key_operation_succeeded')}
 for label,field in [('handler_arrival','start_ms'),('final_validation','last_permit_check_ms'),('key_dispatch','key_call_start_ms')]:
  t=b.get(field);p[label+'_ms']=t;p[label+'_age_s']=round((t-iat)/1000,6) if isinstance(t,(int,float)) and isinstance(iat,(int,float)) else None
 pairs.append(p)
assert len(pairs)==180 and len({p['case'] for p in pairs})==180
(OUT/'ORIGINAL_180_TIMING_PAIRS.json').write_text(json.dumps(pairs,indent=2)+'\n')
with (OUT/'ORIGINAL_180_TIMING_PAIRS.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=list(pairs[0]));w.writeheader();w.writerows(pairs)
groups=defaultdict(list)
for p in pairs:groups[p['profile']].append(p)
s=[]
for name,ps in sorted(groups.items()):
 g={'profile':name,'n':len(ps),'planned_use_delay_s':ps[0]['planned_use_delay_s']}
 for k in ['handler_arrival_age_s','final_validation_age_s','key_dispatch_age_s','retrieval_elapsed_ms']:
  v=[p[k] for p in ps if p[k] is not None];g[k]={'n':len(v),'missing':len(ps)-len(v),'min':min(v) if v else None,'median':statistics.median(v) if v else None,'max':max(v) if v else None}
 s.append(g)
result={'source_sha256':hashlib.sha256(SRC.read_bytes()).hexdigest(),'pairs':180,'groups':s,'deadline_denials':sum(p['gate']=='evidence_deadline' for p in pairs),'deadline_denials_without_elapsed':sum(p['gate']=='evidence_deadline' and p['retrieval_elapsed_ms'] is None for p in pairs),'interpretation':'Timestamp differences across issuer and PEP Lambda wall clocks assume clock alignment; clock skew was not measured. They are not wire latency. Final-validation and dispatch ages are conditional on fields actually retained. Missing retrieval durations remain missing. No original observation or archive was changed.'}
(OUT/'ORIGINAL_TIMING_REANALYSIS.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='groups'}))
