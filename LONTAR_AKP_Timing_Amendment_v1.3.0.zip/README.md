# LONTAR access-key timing amendment v1.3.0

A separate actual staging campaign on 29 October 2026 in project 501250588559/ap-southeast-2. The frozen primary test and v1.2.0 are unchanged.

135 HTTP responses: 92 successful responses, 20 denials, 23 dependency failures. The run contains 54 timing issue/use pairs and 28 handler-recorded KMS successes. All 122 evidence queries retain numeric monotonic elapsed time, including 30 unsuccessful responses; five explicit deadline rejections and 22 query transport failures retain numerical durations. Nine server policy-lock cases deny before handler key attempt. Three Lambda code/environment snapshots match after rollback, state readback matches, host stopped. No new CloudTrail capture; do not add 28 to the earlier 191 correlated operations.

The 180 original v1.2.0 pairs are also reanalyzed. Planned 50-ms use was generally about 0.94 seconds at handler entry due to the old pacer. Missing duration on 13 original deadline denials remains missing. The amendment removes within-pair pacing but does not guarantee exact 50-ms arrival: cold starts and other delays remain in results. Cross-Lambda wall-clock skew was not independently calibrated. Monotonic query duration is not source age or collector completion.

Offline reanalysis (Python standard library; no AWS calls):

```
python3 analyze_amendment.py
python3 reanalyze_original_timing.py
```

Run in a disposable extracted copy: scripts regenerate derived JSON/CSV files. The public manifest validates distributed input/source bytes before analysis. It is not the excluded private-run manifest. Private original archive SHA256: 6cba732e5a1c36c8937b3a17556c8d7b0870295fdd0187737a44697966e09496.

23 offline unit checks require boto3/botocore, with AWS calls mocked:

```
python3 -m unittest discover -s aws_isolated/timing_amendment -p 'test_*.py' -v
```

Do not run cloud deployment during reanalysis. Live code requires fresh project verification, private journals, explicit authorization, and incurs AWS costs. No credential, token, live permit, private key, returned key material, configuration snapshot or rollback ZIP is distributed.

Default P60 uses a manifest bound to the frozen selection hash. F60/P2 are stricter operator diagnostics, not newly certified selector outputs. The infeasible state is an operator fixture, not a new statistical result. This one-host-day study establishes neither deployment risk nor independent-site generalization, hardware attestation or production governance.

The article and formatted report are not included. Figure redraw source/provenance is included. No historical tool version is reconstructed. Code MIT; measurements/documentation CC BY 4.0. Existing older archives remain separate byte-identical snapshots.
