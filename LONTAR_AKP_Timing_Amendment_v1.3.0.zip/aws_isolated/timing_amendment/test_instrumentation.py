"""Offline checks of failure telemetry and server policy lock, not AWS evidence."""
import importlib.util
import io
import json
import os
from pathlib import Path
import sys
from types import SimpleNamespace
import unittest
from unittest.mock import Mock, patch

import boto3
from botocore.exceptions import ReadTimeoutError

HERE = Path(__file__).parent
sys.path.insert(0, str(HERE))
fake_kms = Mock()
fake_kms.exceptions.KMSInvalidSignatureException = type('InvalidSignature', (Exception,), {})
with patch.object(boto3, 'client', return_value=fake_kms), patch.object(boto3, 'resource'):
    spec = importlib.util.spec_from_file_location('timing_runtime_test', HERE/'runtime.py')
    runtime = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(runtime)


class InstrumentationTests(unittest.TestCase):
    def setUp(self):
        self.env = patch.dict(os.environ, {'PROJECT':'project','HOST_ID':'host','COLLECTOR_ARN':'collector',
                'PERMIT_KEY':'permit','POSTURE_KEY':'posture','ROLE':'issuer','CAMPAIGN':'offline-test'})
        self.env.start(); self.addCleanup(self.env.stop)
        self.manifest = {'version':'v-test','policy':'online_60_patient','state':'feasible','origin':'test'}
        self.set_manifest(self.manifest)
        fake_kms.reset_mock()

    def set_manifest(self, manifest):
        os.environ['POLICY_MANIFEST'] = json.dumps(manifest)
        os.environ['POLICY_MANIFEST_SHA256'] = runtime.fingerprint(manifest)

    def call(self, body, role='issuer'):
        os.environ['ROLE'] = role
        event={'body':json.dumps(body),'requestContext':{'requestId':'external-1'}}
        with patch.object(runtime,'identity',return_value={'sub':'subject','exp':9999999999}), patch('builtins.print'):
            response=runtime.handler(event,SimpleNamespace(aws_request_id='lambda-1'))
        return response['statusCode'],json.loads(response['body'])

    def test_deadline_rejection_keeps_numeric_elapsed(self):
        audit={'correlation_id':'trace-1'}; client=Mock()
        stream=io.BytesIO(b'{}'); client.invoke.return_value={'Payload':stream}
        with patch.dict(runtime.BOUNDED,{500:client}), patch.object(runtime.time,'monotonic_ns',side_effect=[0,600000000]):
            with self.assertRaisesRegex(ValueError,'evidence_deadline'):
                runtime.collect('subject','use','nonce',500,audit)
        self.assertEqual(audit['evidence_elapsed_ms'],600)
        self.assertEqual(audit['evidence_stage'],'deadline')
        self.assertEqual(audit['evidence_result'],'response_received')
        self.assertTrue(stream.closed)
        sent=json.loads(client.invoke.call_args.kwargs['Payload'])
        self.assertEqual(sent['correlation_id'],'trace-1')

    def test_invoke_timeout_keeps_elapsed_completion_unknown(self):
        audit={}; client=Mock(); client.invoke.side_effect=ReadTimeoutError(endpoint_url='https://example.invalid')
        with patch.dict(runtime.BOUNDED,{100:client}), patch.object(runtime.time,'monotonic_ns',side_effect=[10,123000010]):
            with self.assertRaises(ReadTimeoutError): runtime.collect('subject','use','nonce',100,audit)
        self.assertEqual(audit['evidence_elapsed_ms'],123)
        self.assertEqual(audit['evidence_result'],'request_exception_collector_completion_unknown')
        self.assertEqual(audit['evidence_stage'],'invoke')

    def test_payload_timeout_keeps_stage_and_closes_stream(self):
        audit={}; stream=Mock(); stream.read.side_effect=ReadTimeoutError(endpoint_url='https://example.invalid')
        client=Mock(); client.invoke.return_value={'Payload':stream}
        with patch.dict(runtime.BOUNDED,{500:client}), patch.object(runtime.time,'monotonic_ns',side_effect=[0,540000000]):
            with self.assertRaises(ReadTimeoutError): runtime.collect('subject','use','nonce',500,audit)
        self.assertEqual(audit['evidence_elapsed_ms'],540)
        self.assertEqual(audit['evidence_stage'],'payload_read')
        stream.close.assert_called_once()

    def test_signature_failure_preserves_retrieval_duration(self):
        audit={}; client=Mock(); client.invoke.return_value={'Payload':io.BytesIO(b'{"claims":{}}')}
        with patch.dict(runtime.BOUNDED,{500:client}), patch.object(runtime.time,'monotonic_ns',side_effect=[0,80000000]), patch.object(runtime,'verify',side_effect=ValueError('signature_invalid')):
            with self.assertRaisesRegex(ValueError,'signature_invalid'): runtime.collect('subject','use','nonce',500,audit)
        self.assertEqual(audit['evidence_elapsed_ms'],80)
        self.assertEqual(audit['evidence_stage'],'signature_and_contract')

    def test_server_manifest_digest_tamper_rejected(self):
        os.environ['POLICY_MANIFEST_SHA256']='bad'
        with self.assertRaisesRegex(ValueError,'server_manifest_hash'): runtime.selected_manifest({})

    def test_no_feasible_policy_rejects_issue_and_use(self):
        self.set_manifest(dict(self.manifest,state='infeasible'))
        for role in ('issuer','pep'):
            status,payload=self.call({'object':'alpha'},role)
            self.assertEqual(status,403); self.assertEqual(payload['gate'],'no_feasible_server_policy')
            self.assertFalse(payload['key_operation_attempted'])

    def test_offline_downgrade_rejected_before_collection(self):
        with patch.object(runtime,'collect') as collect:
            status,payload=self.call({'object':'alpha','policy':'offline_60'})
        self.assertEqual(status,403); self.assertEqual(payload['gate'],'client_policy_override'); collect.assert_not_called()

    def test_ttl_deadline_online_overrides_rejected(self):
        for key in ('ttl','deadline','online','evidence_deadline_ms'):
            status,payload=self.call({'object':'alpha',key:600})
            self.assertEqual(status,403); self.assertEqual(payload['gate'],'client_policy_override')

    def test_baseline_rejected_in_both_roles(self):
        for role in ('issuer','pep'):
            status,payload=self.call({'baseline':True},role)
            self.assertEqual(status,403); self.assertEqual(payload['gate'],'baseline_disabled')
            self.assertFalse(payload['key_operation_attempted'])
        fake_kms.generate_data_key.assert_not_called()

    def test_stale_client_version_rejected(self):
        status,payload=self.call({'object':'alpha','selection_version':'old'})
        self.assertEqual(status,403); self.assertEqual(payload['gate'],'client_policy_version')

    def test_old_signed_manifest_rejected_before_key_operation(self):
        g={'selection_version':'old','selection_manifest_sha256':'old','policy':'online_60_patient'}
        with patch.object(runtime,'verify',return_value=g): status,payload=self.call({'permit':{}},'pep')
        self.assertEqual(status,403); self.assertEqual(payload['gate'],'permit_server_policy_binding')
        self.assertFalse(payload['key_operation_attempted'])


if __name__ == '__main__': unittest.main()
