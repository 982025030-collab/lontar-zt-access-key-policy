"""Separate robustness campaign; does not alter the locked primary contract."""
import hashlib
import json
import math

POLICIES = {
    'offline_2': (2000, False, 0), 'offline_60': (60000, False, 0),
    'online_2_fast': (2000, True, 100), 'online_60_fast': (60000, True, 100),
    'online_2_patient': (2000, True, 500), 'online_60_patient': (60000, True, 500),
}
SOURCE_MAX_AGE_MS = 300000
SSM_MAX_AGE_MS = 600000


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()


def fingerprint(value):
    return hashlib.sha256(canonical(value)).hexdigest()


def valid_time(claim, now):
    if any(type(claim[k]) is not int for k in ('iat_ms', 'exp_ms')):
        raise ValueError('invalid_time_type')
    if not claim['iat_ms'] <= now < claim['exp_ms']:
        raise ValueError('expired_or_future')


def permit_valid(g, subject, host, project, now):
    valid_time(g, now)
    ttl, online, deadline = POLICIES[g['policy']]
    expected = {'typ': 'lontar-major-permit-v1', 'iss': project+'-issuer',
                'aud': project+'-pep', 'sub': subject, 'host': host, 'object': 'alpha',
                'operation': 'protected_key_use', 'online': online,
                'evidence_deadline_ms': deadline, 'source_max_age_ms': SOURCE_MAX_AGE_MS}
    if any(g.get(k) != v or type(g.get(k)) is not type(v) for k, v in expected.items()):
        raise ValueError('permit_binding')
    if not isinstance(g.get('jti'), str) or not 16 <= len(g['jti']) <= 128:
        raise ValueError('permit_jti')
    if g['exp_ms'] > min(g['iat_ms']+ttl, g['evidence_exp_ms'], g['identity_exp_ms']):
        raise ValueError('permit_expiry_binding')


def evidence_valid(e, subject, host, project, audience, nonce, now):
    valid_time(e, now)
    expected = {'typ': 'lontar-major-evidence-v1', 'iss': project+'-collector',
                'aud': audience, 'sub': subject, 'host': host, 'object': 'alpha',
                'nonce': nonce, 'healthy': True, 'entitled': True}
    if any(e.get(k) != v or type(e.get(k)) is not type(v) for k, v in expected.items()):
        raise ValueError('evidence_binding_or_negative')
    if type(e['operational_observed_ms']) is not int or not 0 <= now-e['operational_observed_ms'] <= SOURCE_MAX_AGE_MS:
        raise ValueError('source_observation_stale_or_future')


def deadline_valid(elapsed, deadline):
    if not math.isfinite(elapsed) or not 0 <= elapsed <= deadline:
        raise ValueError('evidence_deadline')
