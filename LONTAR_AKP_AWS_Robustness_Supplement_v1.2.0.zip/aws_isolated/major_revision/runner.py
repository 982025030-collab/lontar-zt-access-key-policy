"""Guarded actual AWS campaign with rollback; never logs bearer tokens/permits."""
import argparse
import base64
import concurrent.futures
import copy
import hashlib
import io
import json
import os
from pathlib import Path
import random
import shlex
import sys
import threading
import time
import urllib.error
import urllib.request
import uuid
import zipfile
from deploy_isolated import Lab, PROJECT, REGION, now
from deploy_p60 import PREFIX

CAMPAIGN = 'major-review-20261028-v1'
POSTURE_DIR = '/var/tmp/lontar-akp-isolated-major-20261028'


def source_bytes(name):
    if Path(sys.argv[0]).suffix == '.pyz':
        with zipfile.ZipFile(sys.argv[0]) as z:
            return z.read('major_revision/'+name)
    return Path(__file__).with_name(name).read_bytes()


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


class Campaign:
    def __init__(self, args):
        if Path(args.output).exists():
            raise ValueError('STOP_EXISTING_OUTPUT')
        self.lab = Lab(args)
        self.lab.r = json.loads(Path(args.journal).read_text())
        self.lab.guard_resources()
        self.p60 = json.loads(Path(args.p60_journal).read_text())
        if self.p60.get('project') != PROJECT or self.p60.get('prefix') != PREFIX:
            raise ValueError('STOP_P60_JOURNAL')
        self.args = args; self.rows = []; self.timeline = []; self.configs = {}; self.codes = {}
        self.protocol = json.loads(source_bytes('protocol.json'))
        self.host = self.lab.r['host_id']; self.subject = None; self.token = None
        self.state = None; self.original_state = None; self.last_measure = 0
        self.last_request = 0; self.pace_lock = threading.Lock(); self.row_lock = threading.Lock()
        self.changed = []; self.started = False; self.deny_created = False; self.cleanup = []
        self.counter = 0
        self.lab.write('protocol.json', self.protocol)
        self.lab.write('source_sha256.json', {n: digest(source_bytes(n)) for n in ('runtime.py', 'contract.py', 'protocol.json', 'runner.py')})

    def event(self, name, **fields):
        self.timeline.append(dict(event=name, utc=now(), **fields))
        self.lab.write('timeline.json', self.timeline)
        print(json.dumps(dict(event=name, **fields)), flush=True)

    def lambda_client(self):
        return self.lab.client('lambda')

    def environment(self, role, **changes):
        env = dict(self.configs[role]['Environment']['Variables'], ROLE=role, CAMPAIGN=CAMPAIGN)
        env.update(changes)
        self.lambda_client().update_function_configuration(FunctionName=self.p60['functions'][role], Environment={'Variables': env})
        self.lambda_client().get_waiter('function_updated_v2').wait(FunctionName=self.p60['functions'][role], WaiterConfig={'Delay': 2, 'MaxAttempts': 45})
        self.event('research_configuration', role=role, changes=changes)

    def capture(self):
        plan = self.lab.client('freetier').get_account_plan_state()
        self.lab.write('preflight.json', {'identity': self.lab.identity, 'plan_type': plan['accountPlanType'],
            'project': PROJECT, 'region': REGION, 'source': 'AWS_CLOUDSHELL_CONTROL_RUNNER' if self.args.cloudshell else 'LOCAL_SDK_CONTROL_RUNNER'})
        host = self.lab.client('ec2').describe_instances(InstanceIds=[self.host])['Reservations'][0]['Instances'][0]
        if host['State']['Name'] != 'stopped':
            raise ValueError('STOP_HOST_NOT_EXCLUSIVELY_STOPPED')
        self.lab.write('host_before.json', {'id': self.host, 'state': host['State']['Name'], 'type': host['InstanceType'],
            'image': host['ImageId'], 'zone': host['Placement']['AvailabilityZone']})
        for role in ('collector', 'issuer', 'pep'):
            fn = self.lambda_client().get_function(FunctionName=self.p60['functions'][role])
            if fn.get('Tags', {}).get('Project') != PREFIX:
                raise ValueError('STOP_OWNERSHIP')
            self.configs[role] = fn['Configuration']
            role_name = fn['Configuration']['Role'].rsplit('/', 1)[-1]
            if not role_name.startswith(PREFIX+'-'):
                raise ValueError('STOP_ROLE_OWNERSHIP')
            self.lab.write('role_before_'+role+'.json', self.lab.client('iam').get_role(RoleName=role_name)['Role'])
            # Presigned download URL is used only in memory and never saved.
            with urllib.request.urlopen(fn['Code']['Location'], timeout=30) as response:
                raw = response.read()
            if base64.b64encode(hashlib.sha256(raw).digest()).decode() != fn['Configuration']['CodeSha256']:
                raise ValueError('STOP_ROLLBACK_CODE_HASH')
            self.codes[role] = raw
            p = self.lab.root / ('rollback_'+role+'.zip'); p.write_bytes(raw); p.chmod(0o600)
            self.lab.write('configuration_before_'+role+'.json', self.configs[role])
        token, claims = self.lab.token(); self.token = token; self.subject = str(claims['sub']); self.claims = claims
        self.original_state = self.lab.state_table().get_item(Key={'pk': 'host:'+self.host}, ConsistentRead=True).get('Item')
        self.lab.write('state_before.json', self.original_state)
        self.lab.write('api_routes_before.json', self.lab.client('apigatewayv2').get_routes(ApiId=self.p60['api_id']))

    def install(self):
        data = io.BytesIO()
        with zipfile.ZipFile(data, 'w', zipfile.ZIP_DEFLATED) as z:
            z.writestr('p60_runtime.py', source_bytes('runtime.py'))
            z.writestr('contract.py', source_bytes('contract.py'))
        for role in ('collector', 'issuer', 'pep'):
            self.changed.append(role)
            self.lambda_client().update_function_code(FunctionName=self.p60['functions'][role], ZipFile=data.getvalue())
            self.lambda_client().get_waiter('function_updated_v2').wait(FunctionName=self.p60['functions'][role], WaiterConfig={'Delay': 2, 'MaxAttempts': 45})
            self.environment(role)
        self.lab.client('ec2').start_instances(InstanceIds=[self.host]); self.started = True
        self.event('host_started')
        for _ in range(90):
            nodes = self.lab.client('ssm').describe_instance_information(Filters=[{'Key': 'InstanceIds', 'Values': [self.host]}]).get('InstanceInformationList', [])
            if nodes and nodes[0].get('PingStatus') == 'Online':
                break
            time.sleep(5)
        else:
            raise ValueError('STOP_SSM_NOT_ONLINE')

    def measure(self, mode=0o600, publish=True):
        if mode not in (0o600, 0o644):
            raise ValueError('STOP_POSTURE_MODE')
        script = ("import json,pathlib,os,time,platform,subprocess; "
                  f"d=pathlib.Path({POSTURE_DIR!r}); d.mkdir(mode=0o700,exist_ok=True); "
                  "p=d/'probe'; p.write_text('non-sensitive research posture probe'); "
                  f"p.chmod({mode}); "
                  "print(json.dumps({'observed_guest_ms':time.time_ns()//1000000,'kernel':platform.release(),"
                  "'boot_id':pathlib.Path('/proc/sys/kernel/random/boot_id').read_text().strip(),"
                  "'mode':p.stat().st_mode&0o777,'ssm_active':subprocess.run(['systemctl','is-active','amazon-ssm-agent'],capture_output=True,text=True).stdout.strip()=='active'}))")
        ssm = self.lab.client('ssm')
        command = ssm.send_command(InstanceIds=[self.host], DocumentName='AWS-RunShellScript',
            Parameters={'commands': ['python3 -c '+shlex.quote(script)]}, TimeoutSeconds=60,
            Comment=PREFIX+' '+CAMPAIGN)['Command']['CommandId']
        for _ in range(40):
            try:
                invocation = ssm.get_command_invocation(CommandId=command, InstanceId=self.host)
            except ssm.exceptions.InvocationDoesNotExist:
                time.sleep(2); continue
            if invocation['Status'] in ('Success', 'Failed', 'Cancelled', 'TimedOut'):
                break
            time.sleep(2)
        else:
            raise ValueError('STOP_TELEMETRY_TIMEOUT')
        if invocation['Status'] != 'Success':
            raise ValueError('STOP_TELEMETRY_FAILURE')
        guest = json.loads(invocation['StandardOutputContent'].strip()); received = time.time_ns()//1000000
        observation = {'issuer': self.p60['environment']['TELEMETRY_ISSUER'], 'host': self.host,
            'subject': self.subject, 'observed_ms': guest['observed_guest_ms'], 'guest': guest,
            'control_receipt_ms': received, 'nonce': uuid.uuid4().hex, 'ssm_command_id': command,
            'criterion': 'actual guest file mode 0600 plus SSM service active; not attestation',
            'compliant': bool(guest['ssm_active'] and guest['mode'] == 0o600)}
        if publish:
            self.set_observation(observation)
            self.last_measure = time.monotonic()
        self.lab.write('observation_'+str(received)+'.json', observation)
        self.event('guest_measurement', mode=mode, published_to_collector=publish,
                   source_observed_ms=guest['observed_guest_ms'], control_receipt_ms=received)

    def set_observation(self, observation):
        raw = json.dumps(observation, sort_keys=True, separators=(',', ':')).encode()
        signature = self.lab.client('kms').sign(KeyId=self.p60['environment']['POSTURE_KEY'], Message=raw,
            MessageType='RAW', SigningAlgorithm='ECDSA_SHA_256')['Signature']
        self.state = {'pk': 'host:'+self.host, 'subject': self.subject, 'revoked': False,
                      'posture_raw': raw.hex(), 'signature': signature.hex(), 'research_delay_ms': 0}
        self.lab.state_table().put_item(Item=self.state)

    def state_change(self, **values):
        self.state = dict(self.state, **values)
        self.lab.state_table().put_item(Item=self.state)
        self.event('state_change', **values)

    def fresh(self):
        if time.time() > int(self.claims['exp'])-120:
            self.token, self.claims = self.lab.token()
        if time.monotonic()-self.last_measure > 90:
            self.measure()

    def request(self, case, path, body, *, expected=None, pace=True, **metadata):
        if pace:
            with self.pace_lock:
                delay = 1.02-(time.monotonic()-self.last_request)
                if delay > 0: time.sleep(delay)
                self.last_request = time.monotonic()
        stamp = now(); start = time.perf_counter_ns()
        request = urllib.request.Request(self.p60['endpoint']+path,
            data=json.dumps(body, separators=(',', ':')).encode(), method='POST',
            headers={'Authorization': 'Bearer '+self.token, 'Content-Type': 'application/json'})
        try:
            with urllib.request.urlopen(request, timeout=20) as response:
                status = response.status; payload = json.load(response); external = response.headers.get('apigw-requestid')
        except urllib.error.HTTPError as error:
            status = error.code; external = error.headers.get('apigw-requestid')
            try: payload = json.load(error)
            except ValueError: payload = {'reason': 'non_json_response'}
        except urllib.error.URLError as error:
            status = None; external = None; payload = {'reason': 'runner_transport_failure', 'error_type': type(error.reason).__name__}
        row = dict(case=case, status=status, expected_status=expected, request_start_utc=stamp, observed_utc=now(),
                   latency_ms=round((time.perf_counter_ns()-start)/1e6, 3), external_request_id=external,
                   host=self.host, response={k: v for k, v in payload.items() if k != 'permit'}, **metadata)
        with self.row_lock:
            self.counter += 1; row['ordinal'] = self.counter; self.rows.append(row)
            self.lab.write('route_results.json', self.rows)
        print(json.dumps({'case': case, 'status': status, 'reason': payload.get('reason'),
                          'key_operation': payload.get('key_operation_succeeded')}), flush=True)
        return payload, row

    def issue(self, label, requested_policy='online_60_patient', **metadata):
        payload, row = self.request(label+'_issue', '/permit', {'object': 'alpha', 'policy': requested_policy}, expected=200, **metadata)
        return payload.get('permit') if row['status'] == 200 else None

    def use(self, label, permit, **metadata):
        return self.request(label, '/key', {'permit': permit}, **metadata)

    def positive(self, label):
        self.fresh(); self.state_change(revoked=False, research_delay_ms=0)
        for attempt in range(3):
            g = self.issue(label+str(attempt))
            if g:
                _, row = self.use(label+str(attempt)+'_use', g, expected=200)
                if row['status'] == 200 and row['response'].get('key_operation_succeeded'):
                    return
        raise ValueError('STOP_POSITIVE_CONTROL_FAILED')

    def robustness(self):
        jobs = [(repeat, profile, policy) for repeat in range(self.protocol['boundary_repetitions'])
                for profile in self.protocol['boundary_profiles'] for policy in self.protocol['policy_family']]
        random.Random(self.protocol['boundary_seed']).shuffle(jobs)
        for ordinal, (repeat, profile, policy) in enumerate(jobs):
            self.fresh(); self.state_change(revoked=False, research_delay_ms=profile['collector_delay_ms'])
            metadata = {'section': 'boundary', 'repeat': repeat, 'profile': profile['name'], 'policy': policy,
                        'adverse': profile['transition'] != 'none', 'planned_use_delay_s': profile['use_delay_s'],
                        'injected_collector_delay_ms': profile['collector_delay_ms']}
            g = self.issue('boundary_'+str(ordinal), policy, **metadata)
            if not g: continue
            if profile['transition'] == 'revoked': self.state_change(revoked=True)
            until = g['claims']['iat_ms']/1000+profile['use_delay_s']
            time.sleep(max(0, until-time.time()))
            self.use('boundary_'+str(ordinal)+'_use', g, **metadata)
        self.state_change(revoked=False, research_delay_ms=0)

    def targeted(self):
        self.positive('targeted_start')
        cached = self.issue('posture_unpublished'); g = self.issue('posture_transition')
        if cached:
            self.measure(0o644, publish=False)
            self.use('actual_posture_change_unpublished', cached, section='freshness_counterexample', adverse=True,
                     limitation='bounded_age_cached_source_not_current_guest_measurement')
        if g:
            self.measure(0o644); self.use('actual_posture_transition', g, expected=403, section='targeted')
        self.measure(); self.positive('posture_recovered')
        g = self.issue('stale_source')
        if g:
            observation = json.loads(bytes.fromhex(self.state['posture_raw']))
            observation.update(observed_ms=time.time_ns()//1000000-301000, operator_timestamp_fixture=True)
            self.set_observation(observation)
            self.use('fresh_nonce_stale_source', g, expected=403, section='targeted', fixture='operator_signed_source_timestamp')
        self.measure()
        self.state_change(research_delay_ms=800)
        g = self.issue('timeout_consumption')
        if g:
            self.use('timeout_consumes_permit', g, expected=503, section='targeted')
            self.state_change(research_delay_ms=0)
            self.use('replay_after_timeout_recovery', g, expected=403, section='targeted')
        self.positive('timeout_recovered')
        g = self.issue('concurrent_replay')
        if g:
            time.sleep(1.2); barrier = threading.Barrier(self.protocol['concurrent_replays'])
            def challenge(i):
                barrier.wait()
                return self.use('concurrent_jti_'+str(i), g, section='concurrent', pace=False)
            with concurrent.futures.ThreadPoolExecutor(max_workers=self.protocol['concurrent_replays']) as pool:
                list(pool.map(challenge, range(self.protocol['concurrent_replays'])))
        for role, variable in [('collector', 'SSM_ENDPOINT'), ('pep', 'DDB_ENDPOINT')]:
            self.positive(variable+'_before')
            g = self.issue(variable)
            self.environment(role, **{variable: 'https://10.255.255.1'})
            if g: self.use(variable+'_transport_fault', g, expected=503, section='dependency')
            self.environment(role)
            self.positive(variable+'_after')
        # Denied wrong-key target is an actual AWS authorization failure and has
        # no IAM propagation ambiguity; it does not test permission-revocation timing.
        self.positive('kms_before'); g = self.issue('kms_denied')
        self.environment('pep', DATA_KEY=self.p60['environment']['POSTURE_KEY'])
        if g: self.use('kms_unauthorized_key_target', g, expected=503, section='dependency', fault='wrong_key_configuration_not_revocation_propagation')
        self.environment('pep'); self.positive('kms_after')
        for delay in (59.5, 60.5):
            self.fresh(); g = self.issue('ttl60_'+str(delay))
            if g:
                while time.time() < g['claims']['iat_ms']/1000+delay:
                    time.sleep(min(5, max(0, g['claims']['iat_ms']/1000+delay-time.time())))
                self.use('ttl60_'+str(delay)+'_use', g, section='ttl_boundary')

    def benchmark(self):
        self.measure(); self.environment('pep', BASELINE_ENABLED='true')
        rng = random.Random(self.protocol['warm_benchmark']['seed'])
        for block in range(4):
            for pair in range(10):
                self.fresh(); arms = ['baseline', 'full']; rng.shuffle(arms)
                for arm in arms:
                    meta = {'section': 'benchmark', 'block': block, 'pair': pair, 'arm': arm, 'planned_state': 'warm'}
                    if arm == 'baseline': self.request('warm_baseline', '/key', {'baseline': True}, expected=200, **meta)
                    else:
                        began = time.perf_counter_ns(); g = self.issue('warm_full', **meta)
                        if g:
                            _, row = self.use('warm_full_use', g, expected=200, **meta)
                            row['observed_issue_to_response_ms'] = round((time.perf_counter_ns()-began)/1e6, 3)
        for i in range(self.protocol['cold_benchmark_per_arm']):
            arms = ['baseline', 'full']; rng.shuffle(arms)
            for arm in arms:
                self.fresh(); g = self.issue('cold_full') if arm == 'full' else None
                self.environment('pep', BASELINE_ENABLED='true', GENERATION=str(uuid.uuid4()))
                meta = {'section': 'benchmark', 'block': i, 'arm': arm, 'planned_state': 'cold_candidate'}
                if arm == 'baseline': self.request('cold_baseline', '/key', {'baseline': True}, expected=200, **meta)
                elif g: self.use('cold_full_use', g, expected=200, **meta)
        self.lab.write('route_results.json', self.rows)
        self.environment('pep'); self.positive('final_recovery')

    def restore(self):
        for role in reversed(self.changed):
            try:
                self.lambda_client().update_function_code(FunctionName=self.p60['functions'][role], ZipFile=self.codes[role])
                self.lambda_client().get_waiter('function_updated_v2').wait(FunctionName=self.p60['functions'][role], WaiterConfig={'Delay': 2, 'MaxAttempts': 45})
                self.lambda_client().update_function_configuration(FunctionName=self.p60['functions'][role], Environment=self.configs[role]['Environment'])
                self.lambda_client().get_waiter('function_updated_v2').wait(FunctionName=self.p60['functions'][role], WaiterConfig={'Delay': 2, 'MaxAttempts': 45})
                current = self.lambda_client().get_function_configuration(FunctionName=self.p60['functions'][role])
                good = current['CodeSha256'] == self.configs[role]['CodeSha256'] and current['Environment'] == self.configs[role]['Environment']
                self.event('lambda_restored', role=role, code_and_environment_equal=good)
                if not good: self.cleanup.append({'role': role, 'error': 'RESTORE_MISMATCH'})
            except Exception as error:
                self.cleanup.append({'role': role, 'error_type': type(error).__name__})
        if self.started:
            try:
                self.measure(0o600)
                if self.original_state is not None:
                    self.lab.state_table().put_item(Item=self.original_state)
                self.lab.client('ec2').stop_instances(InstanceIds=[self.host])
                self.lab.client('ec2').get_waiter('instance_stopped').wait(InstanceIds=[self.host], WaiterConfig={'Delay': 5, 'MaxAttempts': 60})
                self.event('host_stopped_verified')
            except Exception as error:
                self.cleanup.append({'action': 'host_and_state_restore', 'error_type': type(error).__name__})
                # Still request stop if observation/state restoration failed.
                try: self.lab.client('ec2').stop_instances(InstanceIds=[self.host])
                except Exception as stop_error: self.cleanup.append({'action': 'host_stop_fallback', 'error_type': type(stop_error).__name__})

    def capture_logs(self):
        values = []
        for role in ('collector', 'issuer', 'pep'):
            try:
                for page in self.lab.client('logs').get_paginator('filter_log_events').paginate(logGroupName='/aws/lambda/'+PREFIX+'-'+role):
                    for item in page.get('events', []):
                        message = item.get('message', '')
                        if '"lontar_major_audit"' in message or message.startswith('REPORT RequestId:'):
                            values.append({'role': role, 'timestamp': item['timestamp'], 'message': message})
            except Exception as error: self.event('log_capture_error', role=role, error_type=type(error).__name__)
        self.lab.write('lambda_audit.json', values)

    def run(self):
        error = None
        try:
            self.capture(); self.install(); self.measure(); self.positive('initial')
            self.robustness(); self.targeted(); self.benchmark()
        except Exception as exc:
            error = {'error_type': type(exc).__name__}
            if isinstance(exc, ValueError) and str(exc).startswith('STOP_'): error['gate'] = str(exc)
            self.event('experiment_stopped', **error)
        finally:
            self.restore()
        self.capture_logs()
        self.lab.write('summary.json', {'campaign': CAMPAIGN, 'project': PROJECT, 'region': REGION,
            'error': error, 'cleanup_errors': self.cleanup, 'requests': len(self.rows),
            'claim_boundary': 'one-host staging robustness and matched route benchmark; no new primary/deployment certificate',
            'kms_fault_boundary': 'wrong-key unauthorized target, not dynamic IAM permission revocation'})
        manifest = {p.name: digest(p.read_bytes()) for p in self.lab.root.iterdir() if p.is_file()}
        self.lab.write('SHA256_MANIFEST.json', manifest)
        archive = self.lab.root.with_suffix('.zip')
        with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as z:
            for p in self.lab.root.iterdir():
                if p.is_file(): z.write(p, str(Path(self.lab.root.name)/p.name))
        print(json.dumps({'archive': str(archive), 'sha256': digest(archive.read_bytes()), 'error': error, 'cleanup_errors': self.cleanup}), flush=True)


def main():
    p = argparse.ArgumentParser(); p.add_argument('--cloudshell', action='store_true')
    p.add_argument('--journal', required=True); p.add_argument('--p60-journal', required=True)
    p.add_argument('--output', required=True); p.add_argument('--confirm-project', required=True)
    p.add_argument('--preflight-only', action='store_true')
    args = p.parse_args()
    if args.confirm_project != PROJECT: raise ValueError('STOP_PROJECT_CONFIRMATION')
    if args.cloudshell and os.environ.get('AWS_EXECUTION_ENV') != 'CloudShell': raise ValueError('STOP_CLOUDSHELL_REQUIRED')
    campaign = Campaign(args)
    if args.preflight_only:
        campaign.capture()
        campaign.event('read_only_preflight_complete', project=PROJECT, region=REGION,
                       runtime_functions=3, new_roles=0, new_kms_keys=0)
    else:
        campaign.run()


if __name__ == '__main__': main()
