"""Read-only CloudTrail correlation. Run in project-501 CloudShell only.

An absent event is recorded as pending/unmatched, never proof of non-execution.
Only allowlisted audit fields are retained; no credentials or key material.
"""
import argparse
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import zipfile

import boto3
from botocore.config import Config

PROJECT = '501250588559'
REGION = 'ap-southeast-2'
CAMPAIGN = 'major-review-20261028-v1'


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--run', required=True)
    parser.add_argument('--output', required=True)
    args = parser.parse_args()
    if os.environ.get('AWS_EXECUTION_ENV') != 'CloudShell':
        raise ValueError('STOP_CLOUDSHELL_REQUIRED')
    session = boto3.Session(region_name=REGION)
    config = Config(connect_timeout=5, read_timeout=20,
                    retries={'mode': 'standard', 'total_max_attempts': 3})
    identity = session.client('sts', config=config).get_caller_identity()
    if identity['Account'] != PROJECT:
        raise ValueError('STOP_PROJECT_MISMATCH')
    root = Path(args.run)
    summary = json.loads((root/'summary.json').read_text())
    if summary['project'] != PROJECT or summary['campaign'] != CAMPAIGN:
        raise ValueError('STOP_CAMPAIGN_MISMATCH')
    rows = json.loads((root/'route_results.json').read_text())
    start = min(dt.datetime.fromisoformat(r['request_start_utc']) for r in rows)-dt.timedelta(minutes=2)
    end = dt.datetime.now(dt.timezone.utc)
    events = []
    paginator = session.client('cloudtrail', config=config).get_paginator('lookup_events')
    for page in paginator.paginate(
            LookupAttributes=[{'AttributeKey': 'EventName', 'AttributeValue': 'GenerateDataKey'}],
            StartTime=start, EndTime=end):
        for outer in page.get('Events', []):
            event = json.loads(outer['CloudTrailEvent'])
            params = event.get('requestParameters') or {}
            context = params.get('encryptionContext') or {}
            if context.get('Campaign') != CAMPAIGN:
                continue
            events.append({
                'event_id': event.get('eventID'), 'event_time': event.get('eventTime'),
                'event_name': event.get('eventName'), 'region': event.get('awsRegion'),
                'recipient_project': event.get('recipientAccountId'),
                'kms_request_id': event.get('requestID'),
                'external_request_id': context.get('RequestId'),
                'campaign': context.get('Campaign'), 'project_prefix': context.get('Project'),
                'key_id': params.get('keyId'), 'error_code': event.get('errorCode'),
                'execution_role': event.get('userIdentity', {}).get('sessionContext', {}).get('sessionIssuer', {}).get('arn'),
            })
    successes = [r for r in rows if r['response'].get('key_operation_succeeded') is True]
    matched = [r['ordinal'] for r in successes if any(
        e['kms_request_id'] == r['response'].get('kms_request_id') and
        e['external_request_id'] == r.get('external_request_id') and
        e['recipient_project'] == PROJECT and not e['error_code'] for e in events)]
    output = Path(args.output)
    output.mkdir(exist_ok=False)
    report = {'project': PROJECT, 'region': REGION, 'campaign': CAMPAIGN,
              'source': 'AWS_CLOUDSHELL_READ_ONLY_CLOUDTRAIL_FOLLOWUP',
              'capture_utc': end.isoformat(), 'query_start_utc': start.isoformat(),
              'events': events, 'successful_route_operations': len(successes),
              'correlated_success_ordinals': matched,
              'unmatched_success_ordinals': [r['ordinal'] for r in successes if r['ordinal'] not in matched],
              'boundary': 'Event delivery may be delayed. Missing events do not prove that an operation did not execute.'}
    (output/'CLOUDTRAIL_CORRELATION.json').write_text(json.dumps(report, indent=2, sort_keys=True)+'\n')
    manifest = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in output.iterdir() if p.is_file()}
    (output/'SHA256_MANIFEST.json').write_text(json.dumps(manifest, indent=2)+'\n')
    archive = output.with_suffix('.zip')
    with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as z:
        for p in output.iterdir():
            z.write(p, output.name+'/'+p.name)
    print(json.dumps({'archive': str(archive), 'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
                      'events': len(events), 'successes': len(successes), 'matched': len(matched)}))


if __name__ == '__main__':
    main()
