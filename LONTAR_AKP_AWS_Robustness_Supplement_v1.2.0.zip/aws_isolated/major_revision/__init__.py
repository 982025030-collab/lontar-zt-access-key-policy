"""Additional campaign, isolated from primary locked study."""
