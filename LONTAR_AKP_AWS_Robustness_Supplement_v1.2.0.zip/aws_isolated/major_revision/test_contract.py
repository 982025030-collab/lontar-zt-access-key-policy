"""Policy and freshness invariants; offline tests are not cloud evidence."""
import copy
import unittest
from contract import POLICIES, SOURCE_MAX_AGE_MS, permit_valid, evidence_valid, deadline_valid


class ContractTests(unittest.TestCase):
    def permit(self, policy='online_60_patient'):
        ttl, online, deadline = POLICIES[policy]
        return dict(typ='lontar-major-permit-v1', iss='p-issuer', aud='p-pep', sub='s',
                    host='h', object='alpha', operation='protected_key_use', policy=policy,
                    iat_ms=1000, exp_ms=1000+ttl, identity_exp_ms=100000,
                    evidence_exp_ms=100000, online=online, evidence_deadline_ms=deadline,
                    source_max_age_ms=SOURCE_MAX_AGE_MS, jti='0123456789abcdef')

    def evidence(self):
        return dict(typ='lontar-major-evidence-v1', iss='p-collector', aud='p-pep',
                    sub='s', host='h', object='alpha', nonce='challenge', healthy=True,
                    entitled=True, iat_ms=301001, exp_ms=320000, operational_observed_ms=200000)

    def test_all_six_candidates(self):
        for p in POLICIES:
            permit_valid(self.permit(p), 's', 'h', 'p', 1500)

    def test_cannot_change_policy_without_matching_deadline(self):
        g = self.permit(); g['policy'] = 'online_60_fast'
        with self.assertRaises(ValueError): permit_valid(g, 's', 'h', 'p', 1500)

    def test_offline_cannot_claim_online_deadline(self):
        g = self.permit('offline_60'); g['evidence_deadline_ms'] = 500
        with self.assertRaises(ValueError): permit_valid(g, 's', 'h', 'p', 1500)

    def test_ttl_boundary(self):
        g = self.permit('offline_2')
        permit_valid(g, 's', 'h', 'p', 2999)
        with self.assertRaises(ValueError): permit_valid(g, 's', 'h', 'p', 3000)

    def test_expiry_capped_to_source(self):
        g = self.permit(); g['evidence_exp_ms'] = 2000
        with self.assertRaises(ValueError): permit_valid(g, 's', 'h', 'p', 1500)

    def test_fresh_nonce_does_not_refresh_old_source(self):
        e = self.evidence(); e['operational_observed_ms'] = 1000
        with self.assertRaises(ValueError): evidence_valid(e, 's', 'h', 'p', 'p-pep', 'challenge', 301001)

    def test_source_age_boundary(self):
        e = self.evidence(); e['operational_observed_ms'] = 1001
        evidence_valid(e, 's', 'h', 'p', 'p-pep', 'challenge', 301001)

    def test_nonce_binding(self):
        with self.assertRaises(ValueError): evidence_valid(self.evidence(), 's', 'h', 'p', 'p-pep', 'other', 301001)

    def test_negative_context(self):
        for field in ('healthy', 'entitled'):
            e = self.evidence(); e[field] = False
            with self.assertRaises(ValueError): evidence_valid(e, 's', 'h', 'p', 'p-pep', 'challenge', 301001)

    def test_cross_host_binding(self):
        with self.assertRaises(ValueError): permit_valid(self.permit(), 's', 'other', 'p', 1500)

    def test_deadline_is_elapsed_not_injected_sleep(self):
        deadline_valid(99.99, 100)
        with self.assertRaises(ValueError): deadline_valid(100.01, 100)
        deadline_valid(500, 500)
        with self.assertRaises(ValueError): deadline_valid(500.01, 500)

    def test_invalid_elapsed(self):
        for value in (-1, float('inf'), float('nan')):
            with self.assertRaises(ValueError): deadline_valid(value, 500)


if __name__ == '__main__': unittest.main()
