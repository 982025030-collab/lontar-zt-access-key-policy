"""Temporary research runtime. Same authorized endpoint; exact rollback required."""
import base64
import json
import os
import time
import uuid
import boto3
from botocore.config import Config
from botocore.exceptions import BotoCoreError, ClientError
from contract import (POLICIES, SOURCE_MAX_AGE_MS, SSM_MAX_AGE_MS, canonical,
                      fingerprint, valid_time, permit_valid, evidence_valid, deadline_valid)

CONF = Config(connect_timeout=.2, read_timeout=2, retries={'total_max_attempts': 1, 'mode': 'standard'})
KMS = boto3.client('kms', config=CONF)
DDB = boto3.resource('dynamodb', config=CONF, **({'endpoint_url': os.environ['DDB_ENDPOINT']} if os.environ.get('DDB_ENDPOINT') else {}))
SSM = boto3.client('ssm', config=CONF, **({'endpoint_url': os.environ['SSM_ENDPOINT']} if os.environ.get('SSM_ENDPOINT') else {}))
LAMBDA = boto3.client('lambda', config=CONF)
BOUNDED = {d: boto3.client('lambda', config=Config(connect_timeout=.1, read_timeout=d/1000,
           retries={'total_max_attempts': 1, 'mode': 'standard'})) for d in (100, 500)}
FIRST = True


class DependencyUnavailable(Exception):
    pass


def ms():
    return time.time_ns() // 1000000


def sign(claim, key):
    sig = KMS.sign(KeyId=key, Message=canonical(claim), MessageType='RAW', SigningAlgorithm='ECDSA_SHA_256')['Signature']
    return {'claims': claim, 'sig': base64.b64encode(sig).decode()}


def verify(envelope, key):
    claim = envelope['claims']
    if len(canonical(claim)) > 4096:
        raise ValueError('claim_size')
    response = KMS.verify(KeyId=key, Message=canonical(claim),
        Signature=base64.b64decode(envelope['sig'], validate=True), MessageType='RAW', SigningAlgorithm='ECDSA_SHA_256')
    if response.get('SignatureValid') is not True:
        raise ValueError('signature_invalid')
    valid_time(claim, ms())
    return claim


def collect_response(event):
    project = os.environ['PROJECT']; host = os.environ['HOST_ID']
    if event.get('host') != host or event.get('object') != 'alpha' or event.get('phase') not in ('issue', 'use'):
        raise ValueError('collector_binding')
    state = DDB.Table(os.environ['STATE_TABLE']).get_item(Key={'pk': 'host:'+host}, ConsistentRead=True).get('Item')
    if not state or state.get('subject') != event['sub']:
        raise ValueError('collector_subject')
    if event['phase'] == 'use':
        delay = int(state.get('research_delay_ms', 0))
        if not 0 <= delay <= 1000:
            raise ValueError('operator_delay_invalid')
        time.sleep(delay/1000)
    raw = bytes.fromhex(state['posture_raw']); source = json.loads(raw)
    proof = KMS.verify(KeyId=os.environ['POSTURE_KEY'], Message=raw,
        Signature=bytes.fromhex(state['signature']), MessageType='RAW', SigningAlgorithm='ECDSA_SHA_256')
    if proof.get('SignatureValid') is not True or source.get('issuer') != os.environ['TELEMETRY_ISSUER']:
        raise ValueError('source_signature_or_issuer')
    if source.get('subject') != event['sub'] or source.get('host') != host:
        raise ValueError('source_binding')
    source_age = ms()-source['observed_ms']
    if not 0 <= source_age <= SOURCE_MAX_AGE_MS:
        raise ValueError('source_observation_stale_or_future')
    nodes = SSM.describe_instance_information(Filters=[{'Key': 'InstanceIds', 'Values': [host]}]).get('InstanceInformationList', [])
    online = bool(nodes and nodes[0].get('PingStatus') == 'Online' and nodes[0].get('LastPingDateTime')
                  and 0 <= ms()-int(nodes[0]['LastPingDateTime'].timestamp()*1000) <= SSM_MAX_AGE_MS)
    stamp = ms()
    claim = {'typ': 'lontar-major-evidence-v1', 'iss': project+'-collector',
             'aud': project+('-issuer' if event['phase'] == 'issue' else '-pep'),
             'iat_ms': stamp, 'exp_ms': min(stamp+120000, source['observed_ms']+SOURCE_MAX_AGE_MS),
             'sub': event['sub'], 'host': host, 'object': 'alpha', 'nonce': event['nonce'],
             'healthy': bool(source.get('compliant') and online), 'entitled': not bool(state.get('revoked')),
             'operational_observed_ms': source['observed_ms'], 'source_age_ms_at_collector': stamp-source['observed_ms'],
             'assurance': 'signed_SSM_and_file_mode_observation_not_attestation'}
    return sign(claim, os.environ['POSTURE_KEY'])


def collect(subject, phase, nonce, deadline=500):
    start = time.monotonic_ns()
    response = (BOUNDED[deadline] if phase == 'use' else LAMBDA).invoke(
        FunctionName=os.environ['COLLECTOR_ARN'], InvocationType='RequestResponse',
        Payload=canonical({'sub': subject, 'host': os.environ['HOST_ID'], 'object': 'alpha', 'phase': phase, 'nonce': nonce}))
    raw = response['Payload'].read(); elapsed = (time.monotonic_ns()-start)/1e6
    if phase == 'use':
        deadline_valid(elapsed, deadline)
    if response.get('FunctionError'):
        raise ValueError('collector_function_error')
    envelope = json.loads(raw)
    # The collector returns a token-free error object on source/dependency faults.
    if 'claims' not in envelope:
        if envelope.get('statusCode') == 503:
            raise DependencyUnavailable('collector_dependency_unavailable')
        raise ValueError('collector_rejected_source_or_dependency')
    e = verify(envelope, os.environ['POSTURE_KEY'])
    evidence_valid(e, subject, os.environ['HOST_ID'], os.environ['PROJECT'],
                   os.environ['PROJECT']+('-pep' if phase == 'use' else '-issuer'), nonce, ms())
    return e, elapsed


def identity(event):
    claim = event.get('requestContext', {}).get('authorizer', {}).get('jwt', {}).get('claims', {})
    if claim.get('token_use') != 'access' or claim.get('client_id') != os.environ['CLIENT_ID'] or claim.get('iss') != os.environ['ISSUER']:
        raise ValueError('identity_binding')
    if os.environ['SCOPE'] not in str(claim.get('scope', '')).split():
        raise ValueError('scope')
    if not int(claim['iat']) <= time.time() < int(claim['exp']) or int(claim.get('nbf', 0)) > time.time():
        raise ValueError('identity_time')
    return claim


def handler(event, context):
    global FIRST
    audit = {'role': os.environ['ROLE'], 'first_handler_invocation': FIRST,
             'lambda_request_id': context.aws_request_id,
             'external_request_id': event.get('requestContext', {}).get('requestId'),
             'start_ms': ms(), 'campaign': os.environ['CAMPAIGN'],
             'key_operation_attempted': False, 'key_operation_succeeded': False}
    FIRST = False

    def answer(status, reason, **extra):
        audit.update(status=status, reason=reason, response_ms=ms())
        safe = dict(audit, **{k: v for k, v in extra.items() if k != 'permit'})
        print(json.dumps({'lontar_major_audit': safe}, sort_keys=True))
        return {'statusCode': status, 'headers': {'content-type': 'application/json', 'cache-control': 'no-store'},
                'body': json.dumps(dict(safe, **({'permit': extra['permit']} if 'permit' in extra else {})))}

    try:
        if os.environ['ROLE'] == 'collector':
            return collect_response(event)
        c = identity(event); body = json.loads(event.get('body') or '{}')
        if event.get('isBase64Encoded'):
            raise ValueError('encoded_body')
        project = os.environ['PROJECT']; subject = str(c['sub']); baseline = False
        if os.environ['ROLE'] == 'issuer':
            policy = body.get('policy', 'online_60_patient'); ttl, online, deadline = POLICIES[policy]
            if body.get('object') != 'alpha':
                raise ValueError('object')
            jti = uuid.uuid4().hex; e, elapsed = collect(subject, 'issue', jti+'issue'); stamp = ms()
            g = {'typ': 'lontar-major-permit-v1', 'iss': project+'-issuer', 'aud': project+'-pep',
                 'iat_ms': stamp, 'exp_ms': min(stamp+ttl, e['exp_ms'], int(c['exp'])*1000),
                 'identity_exp_ms': int(c['exp'])*1000, 'evidence_exp_ms': e['exp_ms'],
                 'sub': subject, 'host': os.environ['HOST_ID'], 'object': 'alpha',
                 'operation': 'protected_key_use', 'jti': jti, 'policy': policy, 'online': online,
                 'evidence_deadline_ms': deadline, 'source_max_age_ms': SOURCE_MAX_AGE_MS,
                 'issue_evidence_sha256': fingerprint(e)}
            audit.update(policy=policy, evidence_elapsed_ms=elapsed,
                         source_age_ms=ms()-e['operational_observed_ms'], source_observed_ms=e['operational_observed_ms'],
                         permit_issued_ms=stamp, permit_expiry_ms=g['exp_ms'])
            return answer(200, 'permit_issued', permit=sign(g, os.environ['PERMIT_KEY']))
        if body.get('baseline') is True:
            if os.environ.get('BASELINE_ENABLED') != 'true':
                raise ValueError('baseline_disabled')
            baseline = True; audit['policy'] = 'JWT_KMS_RESEARCH_BASELINE'
        else:
            g = verify(body['permit'], os.environ['PERMIT_KEY'])
            permit_valid(g, subject, os.environ['HOST_ID'], project, ms())
            audit.update(policy=g['policy'], permit_issued_ms=g['iat_ms'], permit_expiry_ms=g['exp_ms'], permit_sha256=fingerprint(body['permit']))
            table = DDB.Table(os.environ['REPLAY_TABLE'])
            try:
                table.put_item(Item={'pk': project+':major:'+g['jti'], 'expires_at': g['exp_ms']//1000+600}, ConditionExpression='attribute_not_exists(pk)')
            except table.meta.client.exceptions.ConditionalCheckFailedException:
                return answer(403, 'permit_replay')
            if g['online']:
                e, elapsed = collect(subject, 'use', g['jti']+'use', g['evidence_deadline_ms'])
                audit.update(evidence_elapsed_ms=elapsed, source_age_ms=ms()-e['operational_observed_ms'],
                             source_observed_ms=e['operational_observed_ms'])
            permit_valid(g, subject, os.environ['HOST_ID'], project, ms())
            audit['last_permit_check_ms'] = ms()
        audit.update(key_operation_attempted=True, key_call_start_ms=ms(), baseline=baseline)
        result = KMS.generate_data_key(KeyId=os.environ['DATA_KEY'], KeySpec='AES_256',
            EncryptionContext={'Project': project, 'RequestId': event['requestContext']['requestId'], 'Campaign': os.environ['CAMPAIGN']})
        audit.update(key_operation_succeeded=True, key_call_end_ms=ms(), kms_request_id=result['ResponseMetadata']['RequestId'])
        del result
        return answer(200, 'protected_key_operation')
    except KMS.exceptions.KMSInvalidSignatureException:
        return answer(403, 'signature_invalid')
    except DependencyUnavailable:
        return answer(503, 'collector_dependency_unavailable')
    except BotoCoreError as error:
        return answer(503, 'dependency_transport_failure', error_type=type(error).__name__)
    except ClientError as error:
        return answer(503, 'dependency_error', error_code=error.response.get('Error', {}).get('Code'))
    except (KeyError, TypeError, ValueError, OverflowError) as error:
        gate = str(error) if isinstance(error, ValueError) and len(str(error)) < 80 else type(error).__name__
        return answer(403, 'invalid_contract_or_evidence', gate=gate)
