"""Deterministic descriptive analysis of retained campaign evidence.

No request-level confidence interval is substituted for an independent host-day.
Every response, including unexpected responses, remains in the denominators.
"""
import argparse
from collections import Counter, defaultdict
import hashlib
import json
import math
from pathlib import Path
import re
import statistics


def distribution(values):
    values = sorted(values)
    if not values:
        return {'n': 0}
    return {'n': len(values), 'median_ms': statistics.median(values),
            'p95_ms': values[math.ceil(.95*len(values))-1],
            'p99_ms': values[math.ceil(.99*len(values))-1],
            'min_ms': values[0], 'max_ms': values[-1]}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('run', type=Path)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    manifest_file = args.run/'SHA256_MANIFEST.json'
    base = args.run
    if not manifest_file.exists():
        manifest_file = args.run.parent/'PUBLIC_SHA256.json'
        base = args.run.parent
    manifest = json.loads(manifest_file.read_text())
    for name, sha in manifest.items():
        if hashlib.sha256((base/name).read_bytes()).hexdigest() != sha:
            raise ValueError('Evidence integrity mismatch: '+name)
    rows = json.loads((args.run/'route_results.json').read_text())
    summary = json.loads((args.run/'summary.json').read_text())
    if summary['project'] != '501250588559':
        raise ValueError('Unexpected project')
    reports = {}
    for event in json.loads((args.run/'lambda_audit.json').read_text()):
        message = event['message']
        match = re.search(r'REPORT RequestId:\s*(\S+)', message)
        if match:
            init = re.search(r'Init Duration:\s*([\d.]+)\s*ms', message)
            reports[match[1]] = {'observed_state': 'cold' if init else 'warm',
                                 'init_duration_ms': float(init[1]) if init else None}
    boundary = defaultdict(list)
    boundary_issues = defaultdict(list)
    benchmark = defaultdict(list)
    benchmark_issuance = defaultdict(list)
    paired = defaultdict(dict)
    mismatches = []
    targeted = []
    timeline = json.loads((args.run/'timeline.json').read_text())
    for row in rows:
        response = row['response']
        if row.get('expected_status') is not None and row['status'] != row['expected_status']:
            mismatches.append({'ordinal': row['ordinal'], 'case': row['case'],
                               'expected': row['expected_status'], 'actual': row['status'],
                               'reason': response.get('reason'), 'gate': response.get('gate')})
        if row.get('section') == 'boundary' and row['case'].endswith('_use'):
            boundary[(row['policy'], row['profile'])].append(row)
        elif row.get('section') == 'boundary' and row['case'].endswith('_issue'):
            boundary_issues[(row['policy'], row['profile'])].append(row)
        if row.get('section') == 'benchmark' and not row['case'].endswith('_issue'):
            observed = reports.get(response.get('lambda_request_id'), {}).get('observed_state', 'unmatched_report')
            key = (row['arm'], row['planned_state'], observed)
            benchmark[key].append(row)
            if row.get('planned_state') == 'warm':
                paired[(row['block'], row['pair'])][row['arm']] = row
        elif row.get('section') == 'benchmark' and row['case'].endswith('_issue'):
            observed = reports.get(response.get('lambda_request_id'), {}).get('observed_state', 'unmatched_report')
            benchmark_issuance[(row['arm'], row['planned_state'], observed)].append(row)
        if row.get('section') in ('targeted', 'dependency', 'concurrent', 'ttl_boundary', 'freshness_counterexample'):
            targeted.append({'ordinal': row['ordinal'], 'case': row['case'], 'status': row['status'],
                'reason': response.get('reason'), 'gate': response.get('gate'),
                'key_operation_attempted': response.get('key_operation_attempted'),
                'key_operation_succeeded': response.get('key_operation_succeeded'),
                'source_age_ms': response.get('source_age_ms'),
                'evidence_elapsed_ms': response.get('evidence_elapsed_ms'),
                'key_call_start_ms': response.get('key_call_start_ms'),
                'permit_expiry_ms': response.get('permit_expiry_ms')})
    blocks = defaultdict(list)
    incomplete = []
    for (block, pair), arms in sorted(paired.items()):
        if set(arms) == {'baseline', 'full'} and all(
                r['status'] == 200 and reports.get(r['response'].get('lambda_request_id'), {}).get('observed_state') == 'warm'
                for r in arms.values()):
            blocks[block].append(arms['full']['latency_ms']-arms['baseline']['latency_ms'])
        else:
            incomplete.append({'block': block, 'pair': pair, 'arms': list(arms),
                               'status': {a: r['status'] for a, r in arms.items()}})
    result = {'campaign': summary['campaign'], 'scope': summary['claim_boundary'],
              'manifest_files_verified': len(manifest), 'summary': summary,
              'http_observations': len(rows), 'status_counts': dict(Counter(str(r['status']) for r in rows)),
              'expected_status_mismatches': mismatches,
              'boundary_cells': [], 'benchmark_cells': [],
              'benchmark_issuance_cells': [{'arm': arm, 'planned_state': planned, 'observed_state': observed,
                  'all_requests': len(cell), 'errors': sum(r['status'] != 200 for r in cell),
                  'route_latency': distribution([r['latency_ms'] for r in cell])}
                  for (arm, planned, observed), cell in sorted(benchmark_issuance.items())],
              'boundary_issuance_failures': [{'policy': p, 'profile': q,
                  'issued_attempts': len(cell), 'failed_issues': sum(r['status'] != 200 for r in cell)}
                  for (p, q), cell in sorted(boundary_issues.items()) if any(r['status'] != 200 for r in cell)],
              'paired_warm_blocks': [{'block': b, 'successful_pairs': len(v),
                                      'median_full_minus_baseline_ms': statistics.median(v)}
                                     for b, v in sorted(blocks.items())],
              'incomplete_failed_or_nonwarm_pairs': incomplete, 'targeted': targeted,
              'rollback_events': [e for e in timeline if e['event'] in ('lambda_restored', 'host_stopped_verified')],
              'uncertainty_boundary': 'One actual host-day in this campaign; no deployment or host-day confidence interval is estimated. Sequential benchmark blocks are not independent hosts or days.',
              'error_rate_boundary': 'All HTTP statuses remain in denominators. Success-only timing distributions are explicitly conditional.',
              'cold_boundary': 'Cold/warm classification requires a matched Lambda REPORT; unmatched reports are retained separately.'}
    for (policy, profile), cell in sorted(boundary.items()):
        result['boundary_cells'].append({'policy': policy, 'profile': profile, 'trials': len(cell),
            'issued_attempts': len(boundary_issues[(policy, profile)]),
            'failed_issues': sum(r['status'] != 200 for r in boundary_issues[(policy, profile)]),
            'adverse': cell[0]['adverse'], 'statuses': dict(Counter(str(r['status']) for r in cell)),
            'key_successes': sum(r['response'].get('key_operation_succeeded') is True for r in cell),
            'adverse_key_successes': sum(r['adverse'] and r['response'].get('key_operation_succeeded') is True for r in cell),
            'healthy_failures': sum(not r['adverse'] and r['response'].get('key_operation_succeeded') is not True for r in cell),
            'successful_route_latency': distribution([r['latency_ms'] for r in cell if r['status'] == 200])})
    for (arm, planned, observed), cell in sorted(benchmark.items()):
        result['benchmark_cells'].append({'arm': arm, 'planned_state': planned, 'observed_state': observed,
            'all_requests': len(cell), 'errors': sum(r['status'] != 200 for r in cell),
            'all_route_latency': distribution([r['latency_ms'] for r in cell]),
            'successful_route_latency': distribution([r['latency_ms'] for r in cell if r['status'] == 200]),
            'observed_issue_to_response_including_pacing': distribution([
                r['observed_issue_to_response_ms'] for r in cell if 'observed_issue_to_response_ms' in r])})
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True)+'\n')
    print(json.dumps({'rows': len(rows), 'boundary_cells': len(boundary), 'benchmark_cells': len(benchmark),
                      'mismatches': len(mismatches), 'experiment_error': summary['error'],
                      'cleanup_errors': summary['cleanup_errors']}))


if __name__ == '__main__':
    main()
