"""Read-only retrospective comparator definitions; never rewrites split locks."""
from pathlib import Path
import hashlib
import json
import sys
import copy
import argparse


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--primary-root', type=Path, default=Path(__file__).resolve().parents[2])
    args = parser.parse_args()
    ROOT = args.primary_root.resolve()
    PRIMARY = ROOT / 'access_key_testbed/v4'
    sys.path.insert(0, str(PRIMARY))
    from selector import select
    baseline = json.loads((Path(__file__).with_name('LOCKED_PRIMARY_BEFORE.json')).read_text())
    changed = [p for p, value in baseline.items() if hashlib.sha256((ROOT / p).read_bytes()).hexdigest() != value]
    if changed:
        raise ValueError(f'Locked primary files changed: {changed}')
    study = PRIMARY / 'results/frozen_study01'
    protocol = json.loads((PRIMARY / 'protocol.json').read_text())
    ranking = json.loads((study / 'tuning_lock.json').read_text())['ranking']
    certification = json.loads((study / 'certification/blocks.json').read_text())
    test = json.loads((study / 'test/blocks.json').read_text())
    exact = select(certification, protocol, ranking)
    empirical = []
    for policy in ranking:
        group = [r for r in certification if r['policy'] == policy]
        if sum(r['security_loss'] for r in group)/len(group) <= protocol['security_limit'] and sum(r['service_loss'] for r in group)/len(group) <= protocol['service_limit']:
            empirical.append(policy)
    choices = {'tuning_only': ranking[0], 'empirical_threshold': next(iter(empirical), None),
               'exact_screen': exact['selected_policy'], 'fixed_P60': 'online_60_patient'}
    values = []
    for label, policy in choices.items():
        group = [r for r in test if r['policy'] == policy]
        values.append({'rule': label, 'selected_policy': policy, 'test_blocks': len(group),
                       'security_failed_blocks': sum(r['security_loss'] for r in group),
                       'service_failed_blocks': sum(r['service_loss'] for r in group)})
    sensitivity = []
    for security_limit in (.01, .025, .05, .10):
        for service_limit in (.05, .10, .20, .30):
            alternative = copy.deepcopy(protocol)
            alternative.update(security_limit=security_limit, service_limit=service_limit)
            screen = select(certification, alternative, ranking)
            sensitivity.append({'security_limit': security_limit, 'service_limit': service_limit,
                                'eligible': screen['eligible'], 'selected': screen['selected_policy']})
    result = {'status': 'READ_ONLY_RETROSPECTIVE_COMPARISON', 'selection_inputs': 'original tuning ranking and certification only',
              'new_test_rows': 0, 'new_statistical_claim': False, 'comparators': values,
              'exact_admitted': exact['eligible'], 'empirical_admitted': empirical,
              'posthoc_threshold_sensitivity': sensitivity,
              'sensitivity_boundary': 'Same retained certification counts and simultaneous bounds; no observations changed, no replacement of original selection. Empty sets here illustrate unsupported tighter targets, not a newly executed workload.',
              'conclusion': 'No advantage over empirically screened or fixed P60 is inferred when all choose P60. The exact screen restricts admission more conservatively.',
              'locked_primary_files_verified': len(baseline)}
    Path(__file__).with_name('PRIMARY_COMPARATOR_RESULTS.json').write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__': main()
