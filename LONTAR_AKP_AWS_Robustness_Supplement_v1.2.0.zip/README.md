# LONTAR access-key revision supplement v1.2.0

Separate AWS staging campaign, 28 October 2026, project 501250588559/ap-southeast-2. This is not a replacement primary test.

539 HTTP observations include 180 boundary permit issues and 180 corresponding use trials, targeted failures, and a matched route benchmark. All 191 successful KMS operations correlate with CloudTrail. One unexpected 503 during post-DynamoDB recovery is retained; the subsequent new permit/use succeeded. Exact Lambda code/environment restoration and stopped host were recorded.

The source-freshness counterexample is a successful protected operation after an actual unpublished guest mode change, using an accepted 14.596-second-old observation. This is an adverse result, not a successful security protection. Nonces do not refresh source measurements. SSM/DynamoDB faults are endpoint transport overrides, not service-wide outages. KMS denial is an unauthorized key target, not IAM-revocation propagation.

Run (Python 3 standard library):

```
python3 analyze_campaign.py lontar-akp-isolated-major-run-20261028-01 --output REANALYSIS.json
python3 -m unittest discover -s aws_isolated/major_revision -p test_contract.py -v
```

The public analyzer verifies PUBLIC_SHA256.json for the bytes actually distributed. It does not require an excluded private manifest. To reproduce the retrospective primary comparator, separately extract the byte-identical original v1.0.0 artifact and run:

```
python3 compare_primary_selectors.py --primary-root /path/to/extracted-primary-root
```

All 53 protected primary files must match LOCKED_PRIMARY_BEFORE.json. The exact screen, empirical screen, and fixed P60 have identical primary test outcomes; do not claim selector superiority. Threshold sensitivity is retrospective, not a replacement selection.

Warm/cold labels require matched Lambda REPORTs. One planned-warm full-path request was actually cold and is excluded from observed-warm pairs. Four sequential benchmark blocks do not constitute four independent host-days. No request-level interval substitutes for independent hosts/days. All failures stay in denominators; success-conditional timing is separate. Issue-to-response values include pacing and are not pure service overhead.

Live deployment requires private journals, explicit authorization and project guards and incurs AWS charges. Never run cloud code as part of public offline reanalysis. Do not export CloudShell credentials. The formatted article, secrets, private journals and rollback code/configurations are excluded. Existing earlier supplements and original artifact are separate archives in the repository. This supplement changes neither their bytes nor the locked primary measurements.
