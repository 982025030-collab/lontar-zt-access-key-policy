"""Offline contract regression; not AWS or cryptographic execution evidence."""
import copy
import unittest
from p60_contract import *

class Contract(unittest.TestCase):
 def setUp(self):
  self.g={'typ':'lontar-permit-v1','iss':'project-issuer','aud':'project-pep','iat_ms':1000,'exp_ms':61000,
   'evidence_exp_ms':121000,'identity_exp_ms':100000,'sub':'subject','host':'host','object':'alpha',
   'operation':'protected_key_use','jti':'a'*32,'policy':POLICY,'online':True,'evidence_deadline_ms':500}
 def check(self,g,t=2000):permit_valid(g,'subject','host','project',t)
 def test_valid(self):self.check(self.g)
 def test_ttl_extension(self):
  self.g['exp_ms']=61001
  with self.assertRaises(ValueError):self.check(self.g)
 def test_bound_to_identity_expiry(self):
  self.g['identity_exp_ms']=3000;self.g['exp_ms']=3001
  with self.assertRaises(ValueError):self.check(self.g)
 def test_bound_to_evidence_expiry(self):
  self.g['evidence_exp_ms']=3000;self.g['exp_ms']=3001
  with self.assertRaises(ValueError):self.check(self.g)
 def test_policy_cannot_expand_deadline(self):
  self.g['evidence_deadline_ms']=60000
  with self.assertRaises(ValueError):self.check(self.g)
 def test_expiry_exact_boundary_denies(self):
  with self.assertRaises(ValueError):self.check(self.g,61000)
 def test_future_denies(self):
  with self.assertRaises(ValueError):self.check(self.g,999)
 def test_subject_host_object_operation_binding(self):
  for field in ('sub','host','object','operation','aud','iss','policy','jti'):
   g=copy.deepcopy(self.g);g[field]='wrong'
   with self.assertRaises(ValueError):self.check(g)
 def test_deadline_equality_and_late(self):
  deadline_valid(500)
  for elapsed in (500.001,float('inf'),float('nan')):
   with self.assertRaises(ValueError):deadline_valid(elapsed)
 def test_live_challenge_and_audience_binding(self):
  e={'typ':'lontar-evidence-v1','iss':'project-collector','aud':'project-pep','iat_ms':1000,'exp_ms':9000,
     'sub':'subject','host':'host','object':'alpha','nonce':'challenge','healthy':True,'entitled':True}
  evidence_valid(e,'subject','host','project','project-pep','challenge',2000)
  for field in ('nonce','aud','sub','host'):
   v=dict(e);v[field]='other'
   with self.assertRaises(ValueError):evidence_valid(v,'subject','host','project','project-pep','challenge',2000)
 def test_negative_evidence(self):
  e={'typ':'lontar-evidence-v1','iss':'project-collector','aud':'project-pep','iat_ms':1000,'exp_ms':9000,
     'sub':'subject','host':'host','object':'alpha','nonce':'challenge','healthy':True,'entitled':False}
  with self.assertRaises(ValueError):evidence_valid(e,'subject','host','project','project-pep','challenge',2000)
 def test_noninteger_time_rejected(self):
  self.g['exp_ms']=61000.0
  with self.assertRaises(ValueError):self.check(self.g)

if __name__=='__main__':unittest.main()
