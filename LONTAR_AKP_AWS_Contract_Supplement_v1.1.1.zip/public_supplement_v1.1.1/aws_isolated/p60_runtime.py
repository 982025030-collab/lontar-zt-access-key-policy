"""Three dedicated Lambda roles: collector, issuer, PEP. Never logs tokens/permits."""
import base64
import json
import os
import time
import uuid
import boto3
from boto3.dynamodb.conditions import Attr
from botocore.config import Config
from botocore.exceptions import BotoCoreError,ClientError
from p60_contract import canonical,fingerprint,valid_time,permit_valid,evidence_valid,deadline_valid,POLICY,TTL_MS,EVIDENCE_DEADLINE_MS

CONFIG=Config(connect_timeout=1,read_timeout=10,retries={'total_max_attempts':1,'mode':'standard'})
KMS=boto3.client('kms',config=CONFIG)
DDB=boto3.resource('dynamodb',config=CONFIG)
SSM=boto3.client('ssm',config=CONFIG)
LAMBDA=boto3.client('lambda',config=CONFIG)
BOUNDED_LAMBDA=boto3.client('lambda',config=Config(connect_timeout=.1,read_timeout=.5,retries={'total_max_attempts':1,'mode':'standard'}))
FIRST=True


def now_ms():return int(time.time()*1000)


def sign(claim,key):
    sig=KMS.sign(KeyId=key,Message=canonical(claim),MessageType='RAW',SigningAlgorithm='ECDSA_SHA_256')['Signature']
    return {'claims':claim,'sig':base64.b64encode(sig).decode()}


def verify(envelope,key):
    c=envelope['claims'];raw=canonical(c)
    if len(raw)>4096:raise ValueError('claim_size')
    valid=KMS.verify(KeyId=key,Message=raw,Signature=base64.b64decode(envelope['sig'],validate=True),MessageType='RAW',SigningAlgorithm='ECDSA_SHA_256')
    if valid.get('SignatureValid') is not True:raise ValueError('signature_invalid')
    valid_time(c,now_ms());return c


def collector(event):
    project=os.environ['PROJECT'];host=os.environ['HOST_ID'];subject=event['sub']
    if event.get('host')!=host or event.get('object')!='alpha' or event.get('phase') not in ('issue','use'):raise ValueError('collector_binding')
    audience=project+('-issuer' if event['phase']=='issue' else '-pep')
    # Delay is a deployment-only fault, never controlled by an HTTP caller.
    if event['phase']=='use':time.sleep(int(os.environ.get('USE_DELAY_MS','0'))/1000)
    state=DDB.Table(os.environ['STATE_TABLE']).get_item(Key={'pk':'host:'+host},ConsistentRead=True).get('Item')
    if not state or state.get('subject')!=subject:raise ValueError('collector_subject')
    raw=bytes.fromhex(state['posture_raw']);observation=json.loads(raw)
    proof=KMS.verify(KeyId=os.environ['POSTURE_KEY'],Message=raw,Signature=bytes.fromhex(state['signature']),MessageType='RAW',SigningAlgorithm='ECDSA_SHA_256')
    if proof.get('SignatureValid') is not True:raise ValueError('operational_signature')
    if observation.get('subject')!=subject or observation.get('host')!=host or observation.get('issuer')!=os.environ['TELEMETRY_ISSUER']:raise ValueError('operational_binding')
    if not 0<=now_ms()-observation['observed_ms']<=300000:raise ValueError('operational_stale')
    managed=SSM.describe_instance_information(Filters=[{'Key':'InstanceIds','Values':[host]}]).get('InstanceInformationList',[])
    online=bool(managed and managed[0].get('PingStatus')=='Online' and managed[0].get('LastPingDateTime') and 0<=time.time()-managed[0]['LastPingDateTime'].timestamp()<=600)
    stamp=now_ms();e={'typ':'lontar-evidence-v1','iss':project+'-collector','aud':audience,'iat_ms':stamp,
        'exp_ms':min(stamp+120000,observation['observed_ms']+300000),'sub':subject,'host':host,'object':'alpha',
        'nonce':event['nonce'],'healthy':bool(observation.get('compliant') and online),'entitled':not bool(state.get('revoked')),
        'operational_observed_ms':observation['observed_ms'],'assurance':'signed_operational_SSM_not_hardware_attestation'}
    return sign(e,os.environ['POSTURE_KEY'])


def collect(subject,phase,nonce):
    began=time.monotonic_ns()
    response=(BOUNDED_LAMBDA if phase=='use' else LAMBDA).invoke(FunctionName=os.environ['COLLECTOR_ARN'],InvocationType='RequestResponse',Payload=canonical({'sub':subject,'host':os.environ['HOST_ID'],'object':'alpha','phase':phase,'nonce':nonce}))
    if response.get('FunctionError'):raise ValueError('collector_function_error')
    payload=response['Payload'].read()
    elapsed=(time.monotonic_ns()-began)/1e6
    if phase=='use':deadline_valid(elapsed)
    envelope=json.loads(payload)
    evidence=verify(envelope,os.environ['POSTURE_KEY'])
    evidence_valid(evidence,subject,os.environ['HOST_ID'],os.environ['PROJECT'],os.environ['PROJECT']+('-pep' if phase=='use' else '-issuer'),nonce,now_ms())
    return evidence,elapsed


def identity(event):
    c=event.get('requestContext',{}).get('authorizer',{}).get('jwt',{}).get('claims',{})
    if c.get('token_use')!='access' or c.get('client_id')!=os.environ['CLIENT_ID'] or c.get('iss')!=os.environ['ISSUER'] or os.environ['SCOPE'] not in str(c.get('scope','')).split():raise ValueError('identity_binding')
    if not int(c['iat'])<=time.time()<int(c['exp']) or int(c.get('nbf',0))>time.time():raise ValueError('identity_time')
    return c


def handler(event,context):
    global FIRST
    cold=FIRST;FIRST=False;attempted=False;succeeded=False;elapsed=None;permit_hash=None
    role=os.environ['ROLE'];project=os.environ['PROJECT']
    def answer(status,reason,**extra):
        audit={'role':role,'status':status,'reason':reason,'key_operation_attempted':attempted,'key_operation_succeeded':succeeded,
               'lambda_request_id':context.aws_request_id,'external_request_id':event.get('requestContext',{}).get('requestId'),
               'first_handler_invocation':cold,'evidence_elapsed_ms':elapsed,'permit_sha256':permit_hash,'policy':POLICY,
               'evidence_deadline_ms':EVIDENCE_DEADLINE_MS,**extra}
        print(json.dumps({'lontar_p60_audit':{k:v for k,v in audit.items() if k!='permit'}},sort_keys=True))
        return {'statusCode':status,'headers':{'content-type':'application/json','cache-control':'no-store'},'body':json.dumps(audit)}
    try:
        if role=='collector':return collector(event)
        c=identity(event);body=json.loads(event.get('body') or '{}')
        if event.get('isBase64Encoded'):raise ValueError('encoded_body_not_supported')
        if role=='issuer':
            if body.get('object')!='alpha':raise ValueError('object_denied')
            jti=uuid.uuid4().hex;e,elapsed=collect(str(c['sub']),'issue',jti+'issue');stamp=now_ms()
            g={'typ':'lontar-permit-v1','iss':project+'-issuer','aud':project+'-pep','iat_ms':stamp,
               'exp_ms':min(stamp+TTL_MS,e['exp_ms'],int(c['exp'])*1000),'identity_exp_ms':int(c['exp'])*1000,
               'evidence_exp_ms':e['exp_ms'],'sub':str(c['sub']),'host':os.environ['HOST_ID'],'object':'alpha',
               'operation':'protected_key_use','jti':jti,'policy':POLICY,'online':True,'evidence_deadline_ms':EVIDENCE_DEADLINE_MS,
               'issue_evidence_sha256':fingerprint(e)}
            envelope=sign(g,os.environ['PERMIT_KEY']);permit_hash=fingerprint(envelope)
            return answer(200,'permit_issued',permit=envelope)
        # No compatibility path accepts the historical client timing headers.
        envelope=body['permit'];g=verify(envelope,os.environ['PERMIT_KEY']);permit_hash=fingerprint(envelope)
        permit_valid(g,str(c['sub']),os.environ['HOST_ID'],project,now_ms())
        table=DDB.Table(os.environ['REPLAY_TABLE'])
        try:table.put_item(Item={'pk':project+':'+g['jti'],'expires_at':g['exp_ms']//1000+600},ConditionExpression=Attr('pk').not_exists())
        except table.meta.client.exceptions.ConditionalCheckFailedException:return answer(403,'permit_replay')
        e,elapsed=collect(str(c['sub']),'use',g['jti']+'use')
        permit_valid(g,str(c['sub']),os.environ['HOST_ID'],project,now_ms())
        attempted=True
        result=KMS.generate_data_key(KeyId=os.environ['DATA_KEY'],KeySpec='AES_256',EncryptionContext={'Project':project,'RequestId':event['requestContext']['requestId']})
        succeeded=True;del result
        # This endpoint reports key-operation success, not business-data decryption.
        return answer(200,'protected_key_operation')
    except KMS.exceptions.KMSInvalidSignatureException:return answer(403,'signature_invalid')
    except BotoCoreError as error:return answer(503,'evidence_or_dependency_unavailable',error_type=type(error).__name__)
    except ClientError as error:return answer(503,'dependency_error',error_code=error.response.get('Error',{}).get('Code'))
    except (KeyError,TypeError,ValueError,OverflowError) as error:
        safe=str(error) if isinstance(error,ValueError) and len(str(error))<80 else type(error).__name__
        return answer(403,'invalid_contract_or_evidence',gate=safe)
