"""Isolated staging PEP. JWT signature verification belongs to API Gateway.

Only deployment configuration controls transport faults. The request cannot select
a fault. The signed telemetry is an IAM-authorized SSM observation, not a TPM quote.
No token, request headers, key plaintext, or ciphertext is logged or returned.
"""
import base64
import hashlib
import json
import os
import time
import uuid

import boto3
from boto3.dynamodb.conditions import Attr
from botocore.config import Config
from botocore.exceptions import BotoCoreError, ClientError

BOOT = str(uuid.uuid4())
FIRST = True
CFG = Config(connect_timeout=1, read_timeout=2,
             retries={"total_max_attempts": 1, "mode": "standard"})
KMS = boto3.client("kms", config=CFG)
SSM = boto3.client("ssm", config=CFG,
                   **({"endpoint_url": os.environ["SSM_ENDPOINT"]} if os.environ.get("SSM_ENDPOINT") else {}))
DDB = boto3.resource("dynamodb", config=CFG,
                     **({"endpoint_url": os.environ["DDB_ENDPOINT"]} if os.environ.get("DDB_ENDPOINT") else {}))


def evaluate(event, context, kms, ssm, ddb, env, cold):
    start = time.perf_counter_ns()
    timings = {}
    key_attempted = False
    key_succeeded = False
    request_id = event.get("requestContext", {}).get("requestId", context.aws_request_id)
    headers = {k.lower(): str(v) for k, v in (event.get("headers") or {}).items()}
    claims = event.get("requestContext", {}).get("authorizer", {}).get("jwt", {}).get("claims", {})

    def result(status, reason, **extra):
        body = {"decision": "allow" if status == 200 else "deny", "reason": reason,
                "key_operation_attempted": key_attempted, "key_operation_succeeded": key_succeeded,
                "request_id": request_id, "lambda_request_id": context.aws_request_id,
                "boot_id": BOOT, "first_handler_invocation": cold,
                "handler_ms": round((time.perf_counter_ns()-start)/1e6, 3),
                "dependency_ms": timings, "policy_version": env["POLICY_VERSION"], **extra}
        # Failures retain only an exception type / AWS error code; no raw response.
        print(json.dumps({"lontar_audit": body}, sort_keys=True))
        return {"statusCode": status, "headers": {"content-type": "application/json", "cache-control": "no-store"},
                "body": json.dumps(body, sort_keys=True)}

    def call(label, fn, **kwargs):
        began = time.perf_counter_ns()
        try:
            return fn(**kwargs)
        finally:
            timings[label] = round((time.perf_counter_ns()-began)/1e6, 3)

    if not claims or claims.get("token_use") != "access" or claims.get("client_id") != env["CLIENT_ID"]:
        return result(403, "identity_or_token_use_invalid")
    if claims.get("iss") != env["ISSUER"] or env["SCOPE"] not in str(claims.get("scope", "")).split():
        return result(403, "issuer_or_scope_invalid")
    try:
        now = int(time.time())
        if not int(claims["iat"]) <= now < int(claims["exp"]) or int(claims.get("nbf", 0)) > now:
            return result(403, "identity_time_invalid")
    except (ValueError, KeyError, TypeError):
        return result(403, "identity_time_invalid")
    baseline = event.get("routeKey") == "POST /baseline"
    try:
        if not baseline:
            if env.get("POLICY_STATE", "active") != "active":
                return result(403, "rollback_active")
            if headers.get("x-policy-version") != env["POLICY_VERSION"]:
                return result(403, "policy_version_mismatch")
            host = headers.get("x-host", "")
            if host != env["HOST_ID"]:
                return result(403, "host_binding_mismatch")
            subject = str(claims.get("sub", ""))
            nonce = headers.get("x-request-nonce", "")
            if not 16 <= len(nonce) <= 128:
                return result(403, "request_nonce_invalid")
            try:
                issued = int(headers.get("x-permit-issued-ms", ""))
                deadline = int(headers.get("x-deadline-ms", ""))
                now_ms = int(time.time()*1000)
                # Permit lifetime is at most 60s; transport cannot extend it.
                if not now_ms-60000 <= issued <= now_ms+1000 or not now_ms < deadline <= issued+60000:
                    return result(403, "permit_expired_or_invalid")
            except ValueError:
                return result(403, "permit_time_invalid")
            table = ddb.Table(env["STATE_TABLE"])
            state = call("state", table.get_item, Key={"pk": "host:"+host}, ConsistentRead=True).get("Item")
            if not state or state.get("subject") != subject:
                return result(403, "subject_host_binding_mismatch")
            if state.get("revoked", False):
                return result(403, "revoked")
            if not state.get("posture_raw") or not state.get("signature"):
                return result(403, "posture_missing")
            raw = bytes.fromhex(state["posture_raw"])
            statement = json.loads(raw)
            valid = call("posture_signature", kms.verify, KeyId=env["SIGNING_KEY"], Message=raw,
                         Signature=bytes.fromhex(state["signature"]), MessageType="RAW", SigningAlgorithm="ECDSA_SHA_256")
            if not valid.get("SignatureValid"):
                return result(403, "posture_signature_invalid")
            if statement.get("host") != host or statement.get("subject") != subject or statement.get("issuer") != env["TELEMETRY_ISSUER"]:
                return result(403, "posture_binding_invalid")
            if not statement.get("compliant") or not 0 <= int(time.time()*1000)-int(statement["observed_ms"]) <= 300000:
                return result(403, "posture_stale_or_noncompliant")
            managed = call("ssm", ssm.describe_instance_information, Filters=[{"Key":"InstanceIds","Values":[host]}]).get("InstanceInformationList", [])
            if not managed or managed[0].get("PingStatus") != "Online":
                return result(403, "ssm_posture_unavailable")
            ping = managed[0].get("LastPingDateTime")
            if ping is None or not 0 <= time.time()-ping.timestamp() <= 600:
                return result(403, "ssm_posture_stale")
            replay = ddb.Table(env["REPLAY_TABLE"])
            try:
                call("replay", replay.put_item, Item={"pk":hashlib.sha256((subject+":"+nonce).encode()).hexdigest(),
                     "expires_at": int(time.time())+600}, ConditionExpression=Attr("pk").not_exists())
            except replay.meta.client.exceptions.ConditionalCheckFailedException:
                return result(403, "replay")
            # Recheck revocation immediately before KMS; an atomic boundary with
            # an external key service is not claimed by this staging experiment.
            state = call("revocation_recheck", table.get_item, Key={"pk":"host:"+host}, ConsistentRead=True).get("Item")
            if not state or state.get("revoked", False):
                return result(403, "revoked_or_missing")
            if int(time.time()*1000) >= deadline:
                return result(403, "deadline_before_key")
        key_attempted = True
        data = call("kms", kms.generate_data_key, KeyId=env["DATA_KEY"], KeySpec="AES_256",
                    EncryptionContext={"Project":env["PROJECT"], "RequestId":request_id})
        key_succeeded = True
        # Synthetic operation only: material stays inside Lambda, never in logs.
        del data
        if not baseline and int(time.time()*1000) >= deadline:
            return result(403, "deadline_after_key_no_release")
        return result(200, "baseline_key_operation" if baseline else "permitted_key_operation",
                      telemetry="iam_ssm_observation_kms_signed" if not baseline else "not_evaluated")
    except kms.exceptions.KMSInvalidSignatureException:
        return result(403, "posture_signature_invalid")
    except ClientError as exc:
        return result(503, "dependency_authorization_or_service_error", error_code=exc.response.get("Error", {}).get("Code", "unknown"))
    except BotoCoreError as exc:
        return result(503, "dependency_transport_error", error_type=type(exc).__name__)
    except (ValueError, KeyError, TypeError, OverflowError):
        return result(403, "malformed_evidence")


def handler(event, context):
    global FIRST
    first = FIRST
    FIRST = False
    return evaluate(event, context, KMS, SSM, DDB, os.environ, first)
