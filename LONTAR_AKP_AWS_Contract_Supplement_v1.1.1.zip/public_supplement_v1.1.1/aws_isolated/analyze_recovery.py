"""Reconcile immutable recovery runs locally, without an AWS connection."""
import argparse
import collections
import csv
import datetime as dt
import hashlib
import json
from pathlib import Path
from zoneinfo import ZoneInfo


def main():
    parser=argparse.ArgumentParser();parser.add_argument('runs',nargs='+',type=Path)
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--later-audit',type=Path);args=parser.parse_args()
    args.output.mkdir(parents=True,exist_ok=True)
    summaries=[];outcomes=[];manifest={};units=set()
    for root in args.runs:
        protocol=json.loads((root/'protocol.json').read_text())
        summary=json.loads((root/'recovery_summary.json').read_text())
        if protocol['project']!='501250588559' or protocol['region']!='ap-southeast-2':raise ValueError('Project mismatch')
        rows=json.loads((root/'route_results.json').read_text())
        expected=json.loads((root/'SHA256_MANIFEST.json').read_text())
        for name,digest in expected.items():
            if Path(name).is_absolute() or '..' in Path(name).parts:raise ValueError('Invalid manifest path')
            actual=hashlib.sha256((root/name).read_bytes()).hexdigest()
            if actual!=digest:raise ValueError('Hash mismatch: '+name)
            manifest[str(root/name)]=actual
        audit=json.loads((args.later_audit or root/'kms_cloudtrail_observed.json').read_text())
        contexts={(e.get('encryption_context') or {}).get('RequestId') for e in audit['events'] if not e.get('error_code')}
        contexts.discard(None)
        counts=collections.Counter();positive=0;starts=[]
        for index,row in enumerate(rows):
            stamp=dt.datetime.fromisoformat(row['observed_utc'])
            if stamp.tzinfo is None:raise ValueError('Timestamp has no timezone')
            day=stamp.astimezone(ZoneInfo('Asia/Jakarta')).date().isoformat();units.add((row['host'],day))
            counts[str(row['status'])]+=1
            correlated=row['response'].get('request_id') in contexts
            positive+=int(correlated and row['outcome']=='key_success')
            if row.get('request_start_utc'):starts.append(dt.datetime.fromisoformat(row['request_start_utc']))
            outcomes.append({'run':root.name,'protocol':protocol['protocol'],'ordinal':index,
                'case':row['case'],'status':row['status'],'outcome':row['outcome'],
                'reason':row['response'].get('reason') or row['response'].get('message'),
                'latency_ms':row['latency_ms'],'cold_classification':row['cold_classification'],
                'key_attempted':row['response'].get('key_operation_attempted'),
                'key_succeeded':row['response'].get('key_operation_succeeded'),
                'cloudtrail_success_correlated':correlated,'host':row['host'],'day_asia_jakarta':day,
                'request_start_utc':row.get('request_start_utc'),'observed_utc':row['observed_utc']})
        gaps=[(b-a).total_seconds() for a,b in zip(starts,starts[1:])]
        summaries.append({'run':root.name,'protocol':protocol['protocol'],'requests':len(rows),
            'status_counts':dict(counts),'error_rate_descriptive':sum(r['status']!=200 for r in rows)/len(rows),
            'positive_kms_cloudtrail_correlations':positive,'minimum_observed_request_start_gap_seconds':min(gaps) if gaps else None,
            'declared_minimum_interval_seconds':protocol.get('minimum_request_interval_seconds'),
            'run_summary':summary})
    result={'project':'501250588559','region':'ap-southeast-2','runs':summaries,
        'observed_host_days':[{'host':h,'day':d} for h,d in sorted(units)],
        'request_total_preserved':len(outcomes),'primary_study_modified':False,
        'historical_failed_run_retained_separately':True,'confidence_interval':'not estimated from requests',
        'negative_audit_limit':'No missing CloudTrail event is treated as proof of no operation'}
    if args.later_audit:
        manifest[str(args.later_audit)]=hashlib.sha256(args.later_audit.read_bytes()).hexdigest()
        result['later_audit_source']=str(args.later_audit)
    (args.output/'recovery_analysis.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    (args.output/'input_sha256.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
    with (args.output/'recovery_outcomes.csv').open('w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(outcomes[0]));writer.writeheader();writer.writerows(outcomes)
    print(json.dumps({'runs':len(summaries),'requests':len(outcomes),'host_days':len(units)}))


if __name__=='__main__':main()
