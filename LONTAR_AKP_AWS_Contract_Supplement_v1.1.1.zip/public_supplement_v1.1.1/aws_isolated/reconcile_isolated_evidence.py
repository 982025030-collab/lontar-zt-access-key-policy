"""Analyze retained staging evidence without modifying or pooling primary data."""
import argparse
import csv
import datetime as dt
import hashlib
import json
import math
from pathlib import Path
import re
import statistics
from zoneinfo import ZoneInfo


def load(folder, name, default=None):
    p=folder/name
    return json.loads(p.read_text()) if p.exists() else default


def quantiles(values):
    s=sorted(values)
    if not s:return {"n":0}
    return {"n":len(s),"median_ms":statistics.median(s),
            "p95_ms":s[math.ceil(.95*len(s))-1],"p99_ms":s[math.ceil(.99*len(s))-1]}


def analyze(folder, later_audit=None):
    resources=load(folder,"resources.json",{})
    if resources.get("project")!="501250588559" or resources.get("region")!="ap-southeast-2":
        raise ValueError("Actual project/Region must match the isolated project")
    initial=load(folder,"route_results.json",[])
    followup=load(folder,"followup_route_results.json",[])
    if not initial:raise ValueError("Original request evidence is required")
    report_by_id={}
    for item in load(folder,"lambda_sanitized_audit.json",[]):
        text=item.get("message","")
        match=re.search(r"REPORT RequestId:\s*(\S+)",text)
        if match:
            init=re.search(r"Init Duration:\s*([\d.]+) ms",text)
            report_by_id[match[1]]={"cold":bool(init),"init_ms":float(init[1]) if init else None}
    all_rows=[];groups=set()
    for phase,rows in (("initial",initial),("followup",followup)):
        for i,row in enumerate(rows):
            response=row.get("response",{})
            stamp=dt.datetime.fromisoformat(row["observed_utc"])
            if stamp.tzinfo is None:raise ValueError("Naive timestamp cannot identify a host-day")
            day=stamp.astimezone(ZoneInfo("Asia/Jakarta")).date().isoformat()
            host=row.get("host")
            if not host:raise ValueError("Host missing from request evidence")
            groups.add((host,day))
            proof=report_by_id.get(response.get("lambda_request_id"),{})
            cold="cold_report" if proof.get("cold") else "warm_report" if proof and response.get("first_handler_invocation") is False else "unresolved"
            status=row.get("status")
            denied=(status==503 and response.get("error_code") in ("AccessDeniedException","AccessDenied")
                    and response.get("key_operation_attempted") is True and response.get("key_operation_succeeded") is False)
            all_rows.append({"phase":phase,"ordinal":i,"case":row["case"],"status":status,
                 "expected_status":row.get("expected_status"),"reason":response.get("reason"),
                 "error_code":response.get("error_code"),"error_type":response.get("error_type"),
                 "key_attempted":response.get("key_operation_attempted"),"key_succeeded":response.get("key_operation_succeeded"),
                 "actual_kms_authorization_denial":denied,"latency_ms":row.get("latency_ms"),"cold_classification":cold,
                 "host":host,"day_asia_jakarta":day,"observed_utc":row["observed_utc"],
                 "lambda_request_id":response.get("lambda_request_id"),"external_request_id":row.get("external_request_id")})
    latency={}
    for arm,pattern in (("initial_baseline",r"baseline_\d+$"),("initial_full",r"full_\d+$"),
                        ("followup_cold_baseline",r"cold_candidate_baseline_\d+$"),("followup_cold_full",r"cold_candidate_full_\d+$")):
        arm_rows=[r for r in all_rows if re.fullmatch(pattern,r["case"])]
        latency[arm]={"successful_all":quantiles([r["latency_ms"] for r in arm_rows if r["status"]==200]),
                      "proven_cold":quantiles([r["latency_ms"] for r in arm_rows if r["status"]==200 and r["cold_classification"]=="cold_report"]),
                      "proven_warm":quantiles([r["latency_ms"] for r in arm_rows if r["status"]==200 and r["cold_classification"]=="warm_report"]),
                      "error_count":sum(r["status"]!=200 for r in arm_rows)}
    audit=json.loads(later_audit.read_text()) if later_audit else load(folder,"kms_cloudtrail_observed.json",{})
    context_ids={(e.get("encryption_context") or {}).get("RequestId") for e in audit.get("events",[]) if not e.get("error_code")}
    context_ids.discard(None)
    for row,source in zip(all_rows,initial+followup):
        row["successful_kms_cloudtrail_correlation"]=source.get("response",{}).get("request_id") in context_ids
    summary={"schema":"lontar-staging-reconciliation-v1","project":resources["project"],"region":resources["region"],
             "initial_count":len(initial),"followup_count":len(followup),"all_requests_retained":len(all_rows),
             "initial_expected_status_mismatches":sum(r.get("expected_status") is not None and r.get("status")!=r["expected_status"] for r in initial),
             "actual_kms_authorization_denials":sum(r["actual_kms_authorization_denial"] for r in all_rows),
             "actual_kms_denial_in_initial_recovery_phase":sum(r["actual_kms_authorization_denial"] and r["case"].startswith("kms_recovery_probe_") for r in all_rows),
             "host_day_units_asia_jakarta":[{"host":h,"day":d} for h,d in sorted(groups)],"latency":latency,
             "successful_cloudtrail_correlations":sum(r["successful_kms_cloudtrail_correlation"] for r in all_rows),
             "negative_cloudtrail_evidence":"Absence of event is inconclusive; no closed audit window is assumed",
             "followup_final_state":load(folder,"followup_summary.json",{}),
             "followup_error":load(folder,"followup_error.json",{}),
             "followup_status":"FINAL_SUMMARY_PRESENT" if (folder/"followup_summary.json").exists() else "STOPPED_WITH_ERROR" if (folder/"followup_error.json").exists() else "INCOMPLETE_UNVERIFIED",
             "kms_audit_source":str(later_audit) if later_audit else str(folder/"kms_cloudtrail_observed.json"),
             "uncertainty":"Requests are repeated observations. No request-level CI substitutes for host-day replication.",
             "primary_study_modified":False,"pooled_with_historical_study":False,
             "claim_limits":["staging, not production","M2M, not human PKCE/nonce","signed IAM/SSM operational telemetry, not TPM/TEE attestation",
                             "transport fault, not AWS service outage","no settled monetary cost inference"]}
    return summary,all_rows


def main():
    parser=argparse.ArgumentParser();parser.add_argument("evidence",type=Path);parser.add_argument("--output",required=True,type=Path)
    parser.add_argument("--later-audit",type=Path,help="Separate, immutable later CloudTrail capture; originals remain unchanged")
    args=parser.parse_args()
    if args.output.resolve()==args.evidence.resolve():raise SystemExit("Output must not overwrite original evidence")
    summary,rows=analyze(args.evidence,args.later_audit)
    args.output.mkdir(parents=True,exist_ok=True)
    (args.output/"reconciled_summary.json").write_text(json.dumps(summary,indent=2,sort_keys=True)+"\n")
    with (args.output/"request_outcomes.csv").open("w",newline="") as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    manifest={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(args.evidence.iterdir()) if p.is_file() and p.suffix==".json"}
    if args.later_audit:manifest[str(args.later_audit)]=hashlib.sha256(args.later_audit.read_bytes()).hexdigest()
    (args.output/"input_sha256.json").write_text(json.dumps(manifest,indent=2,sort_keys=True)+"\n")
    lines=["# Isolated staging evidence reconciliation","",f"Project: {summary['project']}; Region: {summary['region']}.","",
           f"Retained {summary['initial_count']} original and {summary['followup_count']} follow-up requests across {len(summary['host_day_units_asia_jakarta'])} observed host-day unit(s), dated in Asia/Jakarta.","",
           f"The initial run had {summary['initial_expected_status_mismatches']} expected-status mismatches. These observations remain in the analysis. Actual KMS authorization denials: {summary['actual_kms_authorization_denials']}; {summary['actual_kms_denial_in_initial_recovery_phase']} occurred in the initial phase labeled recovery.","",
           "| Arm | n successful | Median ms | p95 ms | p99 ms | Errors | Proven cold | Proven warm |","|---|---:|---:|---:|---:|---:|---:|---:|"]
    for name,arm in summary["latency"].items():
        q=arm["successful_all"]
        lines.append(f"| {name} | {q['n']} | {q.get('median_ms','—')} | {q.get('p95_ms','—')} | {q.get('p99_ms','—')} | {arm['error_count']} | {arm['proven_cold']['n']} | {arm['proven_warm']['n']} |")
    lines += ["","Quantiles use the empirical nearest-rank estimator. Small-sample p95/p99 are descriptive, often equal to the sample maximum. No host-day confidence interval is fabricated.","",
              "A policy-update acknowledgment is not treated as immediate enforcement. A follow-up that changes environment generation and waits longer cannot identify the specific cache or propagation mechanism by itself.","",
              "Positive CloudTrail correlation supports observed operations. Missing events do not prove operation suppression. Handler assertions and independent service audit evidence remain distinct.","",
              f"Follow-up status: {summary['followup_status']}; retained error: {json.dumps(summary['followup_error'],sort_keys=True)}. Missing final summary is not treated as completion.","",
              "The primary frozen study and historical clusters are not modified or pooled. This evidence supports only the tested staging environment and machine-identity flow."]
    (args.output/"RESULTS.md").write_text("\n".join(lines)+"\n")
    print(json.dumps({"output":str(args.output),"requests_retained":len(rows),"host_day_units":len(summary['host_day_units_asia_jakarta'])}))


if __name__=="__main__":main()
