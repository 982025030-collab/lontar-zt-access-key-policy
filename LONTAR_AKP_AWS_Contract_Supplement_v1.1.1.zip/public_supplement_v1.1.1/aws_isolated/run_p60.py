"""Live P60 contract protocol; signed permits/tokens remain only in memory."""
import argparse
import base64
import copy
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import sys
import time
import urllib.request
import urllib.error
import zipfile
from zoneinfo import ZoneInfo
from deploy_isolated import Lab,PROJECT,REGION,now
from deploy_p60 import PREFIX
from p60_contract import canonical,fingerprint


def run(args):
    output=Path(args.output)
    if output.exists():raise ValueError('STOP_RUN_EXISTS')
    source=json.loads(Path(args.journal).read_text());p60=json.loads(Path(args.p60_journal).read_text())
    if p60.get('project')!=PROJECT or p60.get('prefix')!=PREFIX or p60.get('region')!=REGION:raise ValueError('STOP_PARITY_JOURNAL')
    lab=Lab(args);lab.r=source;lab.guard_resources();lab.write('base_resources.json',source);lab.write('p60_resources.json',p60)
    if Path(sys.argv[0]).suffix=='.pyz':(lab.root/'executed_source.pyz').write_bytes(Path(sys.argv[0]).read_bytes())
    fn=lab.client('lambda');ec2=lab.client('ec2');host=source['host_id'];rows=[];timeline=[];counter=0;telemetry_at=0;token=None;claims={};last=0;started=False;failure=None;cleanup=[]
    def event(label,**fields):
        timeline.append(dict(event=label,utc=now(),**fields));lab.write('timeline.json',timeline)
    def configuration(delay):
        current=fn.get_function(FunctionName=PREFIX+'-collector')
        if current['Configuration']['FunctionArn']!=p60['functions']['collector'] or current.get('Tags',{}).get('Project')!=PREFIX:raise ValueError('STOP_FUNCTION_OWNERSHIP')
        env=dict(p60['environment'],ROLE='collector')
        if delay:env['USE_DELAY_MS']=str(delay)
        fn.update_function_configuration(FunctionName=PREFIX+'-collector',Environment={'Variables':env})
        fn.get_waiter('function_updated_v2').wait(FunctionName=PREFIX+'-collector',WaiterConfig={'Delay':2,'MaxAttempts':40})
        event('collector_configuration',delay_ms=delay)
    def evidence():
        nonlocal token,claims,telemetry_at
        if token is None or time.time()>int(claims['exp'])-120:token,claims=lab.token()
        if not telemetry_at or time.monotonic()-telemetry_at>90:
            lab.telemetry(str(claims['sub']));obs=json.loads((lab.root/'telemetry_latest.json').read_text())
            lab.write('telemetry_'+str(obs['observed_ms'])+'.json',obs);telemetry_at=time.monotonic()
    def request(case,path,body,expected,headers=None):
        nonlocal last,counter
        evidence();delay=1-(time.monotonic()-last)
        if delay>0:time.sleep(delay)
        last=time.monotonic();began=time.perf_counter_ns();stamp=now()
        req=urllib.request.Request(p60['endpoint']+path,data=canonical(body),headers={'Authorization':'Bearer '+token,'Content-Type':'application/json',**(headers or {})},method='POST')
        try:
            with urllib.request.urlopen(req,timeout=20) as response:status=response.status;payload=json.load(response);external=response.headers.get('apigw-requestid')
        except urllib.error.HTTPError as error:
            status=error.code;external=error.headers.get('apigw-requestid')
            try:payload=json.load(error)
            except ValueError:payload={'reason':'non_json_error'}
        except urllib.error.URLError as error:status=None;external=None;payload={'reason':'runner_transport_error','error_type':type(error.reason).__name__}
        counter+=1
        row={'case':case,'status':status,'expected_status':expected,'request_start_utc':stamp,'observed_utc':now(),
            'latency_ms':round((time.perf_counter_ns()-began)/1e6,3),'external_request_id':external,'host':host,
            'runner':'AWS_CLOUDSHELL_CONTROL_RUNNER' if args.cloudshell else 'LOCAL_CLI_CONTROL_RUNNER',
            'response':{k:v for k,v in payload.items() if k!='permit'},'request_ordinal':counter}
        rows.append(row);lab.write('route_results.json',rows);print(json.dumps({'case':case,'status':status,'reason':payload.get('reason'),'gate':payload.get('gate'),'key_attempted':payload.get('key_operation_attempted')}),flush=True)
        return payload,row
    def issue(label):
        payload,row=request(label,'/permit',{'object':'alpha'},200)
        if row['status']!=200 or 'permit' not in payload:return None
        return payload['permit']
    def resign(envelope):
        g=copy.deepcopy(envelope);sig=lab.client('kms').sign(KeyId=p60['permit_key'],Message=canonical(g['claims']),MessageType='RAW',SigningAlgorithm='ECDSA_SHA_256')['Signature'];g['sig']=base64.b64encode(sig).decode();return g
    try:
        state=ec2.describe_instances(InstanceIds=[host])['Reservations'][0]['Instances'][0]['State']['Name']
        if state!='stopped':raise ValueError('STOP_EXCLUSIVE_HOST_NOT_STOPPED')
        ec2.start_instances(InstanceIds=[host]);started=True;event('host_start')
        for _ in range(90):
            info=lab.client('ssm').describe_instance_information(Filters=[{'Key':'InstanceIds','Values':[host]}]).get('InstanceInformationList',[])
            if info and info[0].get('PingStatus')=='Online':break
            time.sleep(5)
        else:raise ValueError('STOP_SSM_NOT_ONLINE')
        evidence()
        # Warm-up failures are retained, never silently retried into success rates.
        first=None
        for i in range(3):
            g=issue('initial_issue_'+str(i))
            if g:
                payload,row=request('initial_use_'+str(i),'/key',{'permit':g},200)
                if row['status']==200:first=g;break
        if first is None:raise ValueError('STOP_POSITIVE_CONTROL_NOT_OBSERVED')
        request('real_permit_replay','/key',{'permit':first},403)
        request('unsigned_historical_headers','/key',{},403,{'x-permit-issued-ms':str(int(time.time()*1000)),'x-deadline-ms':str(int(time.time()*1000)+60000)})
        for field,value in [('iat_ms',0),('exp_ms',9999999999999),('evidence_deadline_ms',60000)]:
            g=issue('tamper_'+field+'_issue')
            if g:
                g['claims'][field]=value;request('tampered_'+field,'/key',{'permit':g},403)
        for field,value in [('sub','wrong-subject'),('host','wrong-host'),('object','wrong-object'),('aud','wrong-audience'),('evidence_deadline_ms',100),('online',False)]:
            g=issue('fixture_'+field+'_issue')
            if g:
                g['claims'][field]=value;g=resign(g);request('signed_invalid_'+field,'/key',{'permit':g},403)
        g=issue('ttl_fixture_issue')
        if g:
            g['claims']['exp_ms']=g['claims']['iat_ms']+60001;g=resign(g);request('signed_ttl_extension','/key',{'permit':g},403)
        g=issue('delayed_use_issue')
        if g:
            event('real_expiry_wait_started',permit_sha256=fingerprint(g),wait_seconds=61)
            until=time.monotonic()+61
            while time.monotonic()<until:time.sleep(min(5,until-time.monotonic()))
            request('real_issued_permit_expired','/key',{'permit':g},403)
        # Fault configuration is on the isolated collector only.
        configuration(800)
        g=issue('late_evidence_issue')
        if g:request('late_evidence_800ms','/key',{'permit':g},503)
        configuration(100)
        g=issue('expiry_during_check_issue')
        if g:
            g['claims']['exp_ms']=int(time.time()*1000)+150;g=resign(g)
            request('permit_expiry_during_check','/key',{'permit':g},403)
        configuration(0)
        # Keep both warm and cold operational failures in the descriptive results.
        for i in range(10):
            g=issue('normal_issue_'+str(i))
            if g:request('normal_use_'+str(i),'/key',{'permit':g},200)
        g=issue('final_issue')
        if g:request('final_use','/key',{'permit':g},200)
    except Exception as error:
        failure={'error_type':type(error).__name__}
        if isinstance(error,ValueError) and str(error).startswith('STOP_'):failure['gate']=str(error)
        event('experiment_stopped',**failure)
    finally:
        try:configuration(0)
        except Exception as error:cleanup.append({'action':'collector_restore','error_type':type(error).__name__})
        if started:
            try:
                ec2.stop_instances(InstanceIds=[host]);event('host_stop_requested')
                ec2.get_waiter('instance_stopped').wait(InstanceIds=[host],WaiterConfig={'Delay':5,'MaxAttempts':60});event('host_stopped_verified')
            except Exception as error:cleanup.append({'action':'host_stop','error_type':type(error).__name__})
    logs=[]
    for role in ('collector','issuer','pep'):
        try:
            for page in lab.client('logs').get_paginator('filter_log_events').paginate(logGroupName='/aws/lambda/'+PREFIX+'-'+role):
                for item in page.get('events',[]):
                    msg=item.get('message','')
                    if msg.startswith(('REPORT RequestId:','INIT_START')) or '"lontar_p60_audit"' in msg:logs.append({'role':role,'timestamp':item['timestamp'],'message':msg})
        except Exception as error:event('log_capture_incomplete',role=role,error_type=type(error).__name__)
    lab.write('lambda_audit.json',logs)
    actual=fn.get_function_configuration(FunctionName=PREFIX+'-collector')['Environment']['Variables']
    state=ec2.describe_instances(InstanceIds=[host])['Reservations'][0]['Instances'][0]['State']['Name']
    summary={'project':PROJECT,'region':REGION,'prefix':PREFIX,'observed_utc':now(),'experiment_error':failure,'cleanup_errors':cleanup,
       'request_count':len(rows),'unexpected_statuses':[{'case':r['case'],'status':r['status'],'expected':r['expected_status']} for r in rows if r['status']!=r['expected_status']],
       'negative_key_operations':[r['case'] for r in rows if r['expected_status']!=200 and r['response'].get('key_operation_attempted') is True],
       'collector_configuration_restored':actual==dict(p60['environment'],ROLE='collector'),'host_state':state,
       'host_days':[list(x) for x in sorted({(r['host'],dt.datetime.fromisoformat(r['observed_utc']).astimezone(ZoneInfo('Asia/Jakarta')).date().isoformat()) for r in rows})],
       'semantics':{'signed_permit':True,'lifetime_max_ms':60000,'evidence_deadline_ms':500,'nonce_bound_live_evidence':True,'atomic_replay_before_check':True,'expiry_rechecked_after_evidence':True,'signature_algorithm':'KMS ECDSA_SHA_256; local primary Ed25519','protected_operation':'KMS GenerateDataKey; primary AES-GCM decrypt; no certificate transfer'}}
    lab.write('p60_summary.json',summary)
    manifest={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in lab.root.iterdir() if p.is_file()};lab.write('SHA256_MANIFEST.json',manifest)
    archive=lab.root.with_suffix('.zip')
    with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
        for p in lab.root.iterdir():
            if p.is_file():z.write(p,str(Path(lab.root.name)/p.name))
    print(json.dumps({'summary':summary,'archive':str(archive),'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()},sort_keys=True),flush=True)


def main():
    p=argparse.ArgumentParser();p.add_argument('--cloudshell',action='store_true');p.add_argument('--journal',required=True);p.add_argument('--p60-journal',required=True);p.add_argument('--output',required=True);p.add_argument('--confirm-project',required=True);args=p.parse_args()
    if args.confirm_project!=PROJECT:raise ValueError('STOP_PROJECT')
    if args.cloudshell and os.environ.get('AWS_EXECUTION_ENV')!='CloudShell':raise ValueError('STOP_CLOUDSHELL_REQUIRED')
    run(args)


if __name__=='__main__':main()
