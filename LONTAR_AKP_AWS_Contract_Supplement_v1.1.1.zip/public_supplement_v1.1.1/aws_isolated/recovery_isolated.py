"""New-run recovery-only checkpoint. No IAM changes or TTL relaxation.

Uses existing project-501 resources. Preserves failed historical runs. Generates
no primary-study risk certification; records each request, including failures.
"""
import argparse
import hashlib
import json
import math
from pathlib import Path
import statistics
import sys
import time
import urllib.error
import urllib.request
import uuid
import zipfile
from deploy_isolated import Lab, PREFIX, PROJECT, REGION, now


def classify(row):
    body = row.get('response', {})
    if row.get('status') == 200 and body.get('key_operation_succeeded') is True:
        return 'key_success'
    if body.get('error_code') in ('AccessDeniedException', 'AccessDenied') and body.get('key_operation_attempted') is True:
        return 'kms_denied'
    if body.get('reason') == 'posture_stale_or_noncompliant':
        return 'posture_rejected'
    return 'other_failure'


class Recovery:
    def __init__(self, lab):
        self.lab = lab
        self.rows = []
        self.timeline = []
        self.token = None
        self.claims = {}
        self.telemetry_at = 0
        self.last_request_start = None

    def pace(self):
        interval=self.lab.args.interval_seconds
        if self.last_request_start is not None:
            delay=interval-(time.monotonic()-self.last_request_start)
            if delay>0:time.sleep(delay)
        self.last_request_start=time.monotonic()

    def event(self, name, **fields):
        self.timeline.append(dict(event=name, utc=now(), **fields))
        self.lab.write('timeline.json', self.timeline)

    def fresh_evidence(self):
        if not self.token or time.time() > int(self.claims['exp'])-120:
            self.token, self.claims = self.lab.token()
            self.event('machine_token_obtained_not_retained')
        if time.monotonic()-self.telemetry_at >= 90 or not self.telemetry_at:
            self.lab.telemetry(str(self.claims['sub']))
            observation = json.loads((self.lab.root/'telemetry_latest.json').read_text())
            self.lab.write('telemetry_'+str(observation['observed_ms'])+'.json', observation)
            self.telemetry_at = time.monotonic()
            self.event('fresh_signed_operational_telemetry', observed_ms=observation['observed_ms'])

    def request(self, case, path='/key'):
        self.fresh_evidence()
        self.pace()
        issued = int(time.time()*1000)
        headers = {'Authorization':'Bearer '+self.token, 'Content-Type':'application/json',
                   'x-host':self.lab.r['host_id'], 'x-request-nonce':uuid.uuid4().hex,
                   'x-policy-version':self.lab.r['normal_environment']['POLICY_VERSION'],
                   'x-permit-issued-ms':str(issued), 'x-deadline-ms':str(issued+60000)}
        req = urllib.request.Request(self.lab.r['api_endpoint']+path, data=b'{}', headers=headers, method='POST')
        request_start=now(); start = time.perf_counter_ns()
        try:
            with urllib.request.urlopen(req, timeout=25) as response:
                status=response.status; body=json.load(response); external=response.headers.get('apigw-requestid')
        except urllib.error.HTTPError as error:
            status=error.code; external=error.headers.get('apigw-requestid')
            try: body=json.load(error)
            except (ValueError, UnicodeError): body={'reason':'non_json_http_error'}
        except urllib.error.URLError as error:
            status=None; external=None; body={'reason':'runner_transport_failure', 'error_type':type(error.reason).__name__}
        row={'case':case, 'status':status, 'response':body, 'external_request_id':external,
             'observed_utc':now(), 'request_start_utc':request_start,
             'latency_ms':round((time.perf_counter_ns()-start)/1e6,3),
             'host':self.lab.r['host_id'], 'runner':'AWS_CLOUDSHELL_CONTROL_RUNNER' if self.lab.args.cloudshell else 'LOCAL_CLI_CONTROL_RUNNER'}
        row['outcome']=classify(row)
        self.rows.append(row); self.lab.write('route_results.json',self.rows)
        print(json.dumps({'case':case,'status':status,'outcome':row['outcome']}),flush=True)
        return row

    def execute(self):
        lab=self.lab; lab.guard_resources()
        ec2=lab.client('ec2'); iam=lab.client('iam'); fn=lab.client('lambda')
        policies=[]
        for page in iam.get_paginator('list_role_policies').paginate(RoleName=PREFIX+'-pep-role'):
            policies.extend(page['PolicyNames'])
        env=fn.get_function_configuration(FunctionName=PREFIX+'-pep').get('Environment',{}).get('Variables',{})
        if PREFIX+'-fault-deny' in policies or env!=lab.r['normal_environment']:
            raise ValueError('STOP_BASELINE_CONFIGURATION_NOT_NORMAL')
        current=lab.state_table().get_item(Key={'pk':'host:'+lab.r['host_id']},ConsistentRead=True).get('Item',{})
        if current.get('revoked'):
            raise ValueError('STOP_EXISTING_REVOCATION_REQUIRES_REVIEW')
        plan={'project':PROJECT,'region':REGION,'created_utc':now(),'identity':lab.identity,
              'protocol':'recovery-only-paced-v2','minimum_request_interval_seconds':lab.args.interval_seconds,
              'recovery_budget_seconds':120,'required_consecutive_successes':3,
              'warm_requests_per_arm':20,'cold_candidates_per_arm':3,'telemetry_refresh_seconds':90,
              'posture_ttl_seconds_unchanged':300,'permit_ttl_seconds_unchanged':60,
              'new_iam_permissions':False,'prior_runs_modified':False,'cold_definition':'matched REPORT Init Duration',
              'host_stop_required':True,'claim':'staging recovery and descriptive latency; no primary certification transfer'}
        billing=lab.client('freetier').get_account_plan_state()
        plan['plan_type']=billing['accountPlanType']; plan['plan_status']=billing['accountPlanStatus']
        lab.write('protocol.json',plan)
        host=lab.r['host_id']; started=False; regenerated=False; failure=None; cleanup=[]; recovered=False
        try:
            state=ec2.describe_instances(InstanceIds=[host])['Reservations'][0]['Instances'][0]['State']['Name']
            if state!='stopped':raise ValueError('STOP_HOST_NOT_STOPPED_EXCLUSIVE_RUN')
            ec2.start_instances(InstanceIds=[host]); started=True; self.event('host_start_acknowledged')
            for _ in range(90):
                info=lab.client('ssm').describe_instance_information(Filters=[{'Key':'InstanceIds','Values':[host]}]).get('InstanceInformationList',[])
                if info and info[0].get('PingStatus')=='Online':break
                time.sleep(5)
            else:raise ValueError('STOP_SSM_NOT_ONLINE')
            began=time.monotonic(); consecutive=0; attempt=0
            while time.monotonic()-began<120:
                row=self.request('recovery_control_'+str(attempt)); attempt+=1
                consecutive=consecutive+1 if row['outcome']=='key_success' else 0
                if consecutive==3:recovered=True;break
                time.sleep(5)
            if not recovered:raise ValueError('STOP_RECOVERY_NOT_OBSERVED')
            self.event('three_consecutive_recovery_successes')
            for i in range(20):
                # Counterbalance order; requests remain repeated observations.
                arms=[('baseline','/baseline'),('full','/key')]
                if i%2:arms.reverse()
                for arm,path in arms:self.request('warm_candidate_'+arm+'_'+str(i),path)
            for i in range(3):
                for arm,path in [('baseline','/baseline'),('full','/key')]:
                    self.fresh_evidence()
                    regenerated=True; lab.configure(PROBE_GENERATION=uuid.uuid4().hex)
                    self.event('environment_generation_intervention',arm=arm,ordinal=i)
                    self.request('cold_candidate_'+arm+'_'+str(i),path)
            lab.configure(); regenerated=False; self.event('normal_environment_restored')
            self.request('final_control')
        except Exception as error:
            failure={'type':type(error).__name__}
            if isinstance(error,ValueError) and str(error).startswith('STOP_'):failure['gate']=str(error)
            # No exception text that could contain headers or credentials.
            self.event('experiment_stopped',**failure)
        finally:
            if regenerated:
                try:lab.configure(); self.event('normal_environment_restored_in_cleanup')
                except Exception as error:cleanup.append({'action':'restore_environment','type':type(error).__name__})
            if started:
                try:
                    ec2.stop_instances(InstanceIds=[host]); self.event('host_stop_requested')
                    ec2.get_waiter('instance_stopped').wait(InstanceIds=[host],WaiterConfig={'Delay':5,'MaxAttempts':60})
                    self.event('host_stopped_verified')
                except Exception as error:cleanup.append({'action':'stop_host','type':type(error).__name__})
        try:lab.collect_audit(self.rows)
        except Exception as error:self.event('audit_capture_incomplete',error_type=type(error).__name__)
        state=ec2.describe_instances(InstanceIds=[host])['Reservations'][0]['Instances'][0]['State']['Name']
        actual=fn.get_function_configuration(FunctionName=PREFIX+'-pep').get('Environment',{}).get('Variables',{})
        reports={}
        import re
        audit=lab.root/'lambda_sanitized_audit.json'
        if audit.exists():
            for item in json.loads(audit.read_text()):
                match=re.search(r'REPORT RequestId:\s*(\S+)',item['message'])
                if match:
                    init=re.search(r'Init Duration:\s*([\d.]+) ms',item['message'])
                    reports[match[1]]=bool(init)
        for row in self.rows:
            proof=reports.get(row['response'].get('lambda_request_id'))
            row['cold_classification']='cold_report' if proof is True else 'warm_report' if proof is False and row['response'].get('first_handler_invocation') is False else 'unresolved'
        lab.write('route_results.json',self.rows)
        summary={'project':PROJECT,'region':REGION,'verified_at_utc':now(),'recovery_observed':recovered,
                 'experiment_error':failure,'cleanup_errors':cleanup,'host_state':state,
                 'configuration_restored':actual==lab.r['normal_environment'],'request_count':len(self.rows),
                 'final_control_success':bool(self.rows and self.rows[-1]['case']=='final_control' and self.rows[-1]['outcome']=='key_success'),
                 'latency':{},'uncertainty':'descriptive repeated requests; no host-day CI or certification transfer'}
        for arm in ('baseline','full'):
            for kind in ('warm','cold'):
                subset=[r for r in self.rows if r['case'].startswith(kind+'_candidate_'+arm+'_')]
                values=sorted(r['latency_ms'] for r in subset if r['outcome']=='key_success' and r['cold_classification']==kind+'_report')
                summary['latency'][kind+'_'+arm]={'attempts':len(subset),'proven_successes':len(values),'errors':sum(r['outcome']!='key_success' for r in subset),'median_ms':statistics.median(values) if values else None,'p95_ms':values[math.ceil(.95*len(values))-1] if values else None,'p99_ms':values[math.ceil(.99*len(values))-1] if values else None}
        lab.write('recovery_summary.json',summary)
        return summary


def package(root):
    files=sorted(p for p in root.rglob('*') if p.is_file())
    manifest={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
    (root/'SHA256_MANIFEST.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
    archive=root.with_suffix('.zip')
    with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
        for p in files+[root/'SHA256_MANIFEST.json']:z.write(p,str(Path(root.name)/p.relative_to(root)))
    return {'archive':str(archive),'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()}


def main():
    parser=argparse.ArgumentParser(); parser.add_argument('--cloudshell',action='store_true')
    parser.add_argument('--journal',required=True,type=Path); parser.add_argument('--output',required=True,type=Path)
    parser.add_argument('--confirm-project',required=True)
    parser.add_argument('--interval-seconds',type=float,default=1.0); args=parser.parse_args()
    if args.interval_seconds<1 or args.interval_seconds>5:raise ValueError('STOP_REQUEST_INTERVAL_OUT_OF_BOUNDS')
    if args.confirm_project!=PROJECT:raise ValueError('STOP_CONFIRM_PROJECT')
    # Guard identity before creating a fresh run; never modify the old journal.
    source=args.journal.resolve(); journal=json.loads(source.read_text())
    if journal.get('project')!=PROJECT or journal.get('region')!=REGION:raise ValueError('STOP_JOURNAL_MISMATCH')
    if args.output.exists():raise ValueError('STOP_RUN_DIRECTORY_EXISTS')
    lab=Lab(args); lab.write('resources.json',journal); lab.r=journal
    source_archive=Path(sys.argv[0])
    if source_archive.suffix=='.pyz' and source_archive.is_file():
        (lab.root/'executed_source.pyz').write_bytes(source_archive.read_bytes())
    lab.write('provenance.json',{'source_journal':str(source),'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'source_not_modified':True})
    try:summary=Recovery(lab).execute()
    except Exception as error:
        summary={'status':'STOPPED','error_type':type(error).__name__}
        if isinstance(error,ValueError) and str(error).startswith('STOP_'):summary['gate']=str(error)
        lab.write('startup_error.json',summary)
    print(json.dumps({'summary':summary,**package(lab.root)},sort_keys=True),flush=True)


if __name__=='__main__':
    main()
