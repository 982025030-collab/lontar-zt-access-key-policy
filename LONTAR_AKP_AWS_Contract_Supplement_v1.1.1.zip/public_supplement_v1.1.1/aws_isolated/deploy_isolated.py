"""Create-only project-501 staging deployment and controlled route experiments.

Run from the reviewed zipapp. Plan is read-only. Apply/test require explicit flags.
The resource journal contains identifiers, never credential material. OAuth M2M
credentials and access tokens exist only in process memory and in Cognito itself.
"""
import argparse
import base64
import datetime as dt
import hashlib
import io
import json
import os
from pathlib import Path
import statistics
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid
import zipfile

import boto3
from botocore.config import Config
from botocore.exceptions import BotoCoreError, ClientError

PROJECT = "501250588559"
REGION = "ap-southeast-2"
PREFIX = "lontar-akp-isolated-20261022"
BUCKET = "lontar-zt-access-key-policy-501250588559-ap-southeast-2-an"
SCOPE = PREFIX+"/key"
TAGS = [{"Key":"Project","Value":PREFIX},{"Key":"Purpose","Value":"research-staging"}]
CONF = Config(connect_timeout=10, read_timeout=25, retries={"total_max_attempts":2,"mode":"standard"})


def now():
    return dt.datetime.now(dt.timezone.utc).isoformat()


class Lab:
    def __init__(self, args):
        self.args = args
        self.session = boto3.Session(region_name=REGION, **({} if args.cloudshell else {"profile_name":"aws-lontar-access-key-policy"}))
        self.clients = {}
        identity = self.client("sts").get_caller_identity()
        if identity["Account"] != PROJECT:
            raise ValueError("STOP_PROJECT_MISMATCH")
        self.identity = {k:identity[k] for k in ("Account","Arn")}
        self.root = Path(args.output).resolve()
        self.root.mkdir(parents=True, exist_ok=True)
        self.path = self.root/"resources.json"
        self.r = json.loads(self.path.read_text()) if self.path.exists() else {}
        if self.r and (self.r.get("project") != PROJECT or self.r.get("prefix") != PREFIX):
            raise ValueError("STOP_JOURNAL_MISMATCH")

    def client(self, name):
        if name not in self.clients:
            self.clients[name] = self.session.client(name, config=CONF)
        return self.clients[name]

    def write(self, name, obj):
        p = self.root/name
        p.write_text(json.dumps(obj, sort_keys=True, indent=2, default=str)+"\n")
        p.chmod(0o600)

    def record(self, key, value):
        self.r[key] = value
        self.write("resources.json", self.r)
        print(json.dumps({"step":key,"status":"RECORDED","time":now()}),flush=True)

    def plan(self):
        plan = self.client("freetier").get_account_plan_state()
        vpcs = self.client("ec2").describe_vpcs(Filters=[{"Name":"is-default","Values":["true"]}])["Vpcs"]
        out = {"project":PROJECT,"region":REGION,"identity":self.identity,"prefix":PREFIX,
               "mode":"READ_ONLY_PLAN","time":now(),"plan_type":plan["accountPlanType"],
               "plan_status":plan["accountPlanStatus"],"default_vpc_available":bool(vpcs),
               "resources":{"cognito":"one isolated pool, M2M client and resource-server scope; no human users/passwords",
                            "ec2":"one t3.micro, 8 GiB encrypted gp3, IMDSv2 required, no ingress; stop after tests",
                            "iam":"two new execution/instance roles scoped to staging resources; SSMManagedInstanceCore on new host",
                            "dynamodb":"two on-demand tables: state and replay; TTL on replay",
                            "kms":"two customer-managed single-Region keys: symmetric data key and ECC posture signing",
                            "lambda":"one Python PEP, 256 MiB, 15 s timeout; operator-only fault configuration",
                            "api":"HTTP API, JWT authorizer plus custom scope, POST /key and experiment-only POST /baseline",
                            "logs":"two groups, 7-day retention, access logs omit tokens and headers"},
               "faults":["actual IAM KMS GenerateDataKey deny","SSM transport timeout via deployment endpoint override",
                         "DynamoDB transport failure via deployment endpoint override","replay","revocation","rollback",
                         "bad/missing signature and posture","JWT missing/tampered","binding mismatch","deadline expired"],
               "retention":"No old-project changes. No existing prefix reuse without this exact journal. New host stopped after tests; S3 retained.",
               "claim_limits":["M2M access tokens, not human OIDC ID-token/PKCE nonce validation","SSM+KMS-signed operator observations, not hardware attestation",
                               "one runner/host/date; no independent host-day CI","transport injection is not AWS service outage","staging only; no production claim"]}
        self.write("deployment_plan.json",out)
        return out

    def role(self, suffix, principal):
        name=PREFIX+suffix
        trust={"Version":"2012-10-17","Statement":[{"Effect":"Allow","Principal":{"Service":principal},"Action":"sts:AssumeRole"}]}
        role=self.client("iam").create_role(RoleName=name, AssumeRolePolicyDocument=json.dumps(trust),Tags=TAGS)["Role"]
        self.record("role"+suffix,role["Arn"])
        return role["Arn"]

    def deploy(self):
        self.plan()
        if self.r:
            raise ValueError("STOP_EXISTING_JOURNAL_CREATE_ONLY_REVIEW_PARTIAL_STATE")
        # No existing resource with our ownership tag/name is adopted implicitly.
        iam=self.client("iam"); ec2=self.client("ec2"); cog=self.client("cognito-idp")
        for page in iam.get_paginator("list_roles").paginate():
            if any(x["RoleName"].startswith(PREFIX) for x in page["Roles"]):
                raise ValueError("STOP_PREFIX_ALREADY_EXISTS")
        self.record("project",PROJECT); self.record("region",REGION); self.record("prefix",PREFIX)
        self.record("identity",self.identity); self.record("created_utc",now())
        self.record("execution_environment","AWS_CLOUDSHELL_CONTROL_RUNNER" if self.args.cloudshell else "LOCAL_CLI_CONTROL_RUNNER")
        self.record("execution_env_variable",os.environ.get("AWS_EXECUTION_ENV","not_set"))
        kms=self.client("kms")
        for name,spec,usage in [("data_key","SYMMETRIC_DEFAULT","ENCRYPT_DECRYPT"),("signing_key","ECC_NIST_P256","SIGN_VERIFY")]:
            key=kms.create_key(Description=PREFIX+" "+name,KeySpec=spec,KeyUsage=usage,MultiRegion=False,Tags=[{"TagKey":x["Key"],"TagValue":x["Value"]} for x in TAGS])["KeyMetadata"]
            self.record(name,key["Arn"])
            kms.create_alias(AliasName="alias/"+PREFIX+"-"+name,TargetKeyId=key["KeyId"])
        ddb=self.client("dynamodb")
        for kind in ("state","replay"):
            name=PREFIX+"-"+kind
            ddb.create_table(TableName=name,AttributeDefinitions=[{"AttributeName":"pk","AttributeType":"S"}],KeySchema=[{"AttributeName":"pk","KeyType":"HASH"}],BillingMode="PAY_PER_REQUEST",Tags=TAGS)
            self.record(kind+"_table",name)
            ddb.get_waiter("table_exists").wait(TableName=name,WaiterConfig={"Delay":3,"MaxAttempts":30})
        ddb.update_time_to_live(TableName=self.r["replay_table"],TimeToLiveSpecification={"Enabled":True,"AttributeName":"expires_at"})
        pool=cog.create_user_pool(PoolName=PREFIX+"-idp",AdminCreateUserConfig={"AllowAdminCreateUserOnly":True},UserPoolTags={x["Key"]:x["Value"] for x in TAGS},UserPoolTier="LITE")["UserPool"]
        self.record("pool_id",pool["Id"])
        self.record("issuer",f"https://cognito-idp.{REGION}.amazonaws.com/{pool['Id']}")
        cog.create_resource_server(UserPoolId=pool["Id"],Identifier=PREFIX,Name=PREFIX,Scopes=[{"ScopeName":"key","ScopeDescription":"Synthetic access-key research requests only"}])
        client=cog.create_user_pool_client(UserPoolId=pool["Id"],ClientName=PREFIX+"-m2m",GenerateSecret=True,AllowedOAuthFlows=["client_credentials"],AllowedOAuthFlowsUserPoolClient=True,AllowedOAuthScopes=[SCOPE],AccessTokenValidity=15,TokenValidityUnits={"AccessToken":"minutes"},EnableTokenRevocation=True)["UserPoolClient"]
        self.record("client_id",client["ClientId"])
        # ClientSecret intentionally not persisted or printed.
        domain=PREFIX+"-501"
        cog.create_user_pool_domain(UserPoolId=pool["Id"],Domain=domain,ManagedLoginVersion=1)
        self.record("domain",domain)
        vpcs=ec2.describe_vpcs(Filters=[{"Name":"is-default","Values":["true"]}])["Vpcs"]
        if len(vpcs)!=1: raise ValueError("STOP_DEFAULT_VPC_REQUIRED")
        vpc=vpcs[0]["VpcId"]
        subnets=ec2.describe_subnets(Filters=[{"Name":"vpc-id","Values":[vpc]},{"Name":"default-for-az","Values":["true"]}])["Subnets"]
        if not subnets: raise ValueError("STOP_DEFAULT_SUBNET_REQUIRED")
        subnet=sorted(subnets,key=lambda x:x["AvailabilityZone"])[0]
        self.record("subnet",subnet["SubnetId"])
        sg=ec2.create_security_group(GroupName=PREFIX+"-telemetry",Description="No ingress; HTTPS egress for SSM only",VpcId=vpc,TagSpecifications=[{"ResourceType":"security-group","Tags":TAGS}])["GroupId"]
        self.record("security_group",sg)
        # Remove new SG's default outbound rule, not any pre-existing SG.
        ec2.revoke_security_group_egress(GroupId=sg,IpPermissions=[{"IpProtocol":"-1","IpRanges":[{"CidrIp":"0.0.0.0/0"}]}])
        ec2.authorize_security_group_egress(GroupId=sg,IpPermissions=[{"IpProtocol":"tcp","FromPort":443,"ToPort":443,"IpRanges":[{"CidrIp":"0.0.0.0/0"}]}])
        hostrole=self.role("-host-role","ec2.amazonaws.com")
        iam.attach_role_policy(RoleName=PREFIX+"-host-role",PolicyArn="arn:aws:iam::aws:policy/AmazonSSMManagedInstanceCore")
        iam.create_instance_profile(InstanceProfileName=PREFIX+"-host-profile",Tags=TAGS)
        self.record("instance_profile",PREFIX+"-host-profile")
        iam.add_role_to_instance_profile(InstanceProfileName=self.r["instance_profile"],RoleName=PREFIX+"-host-role")
        ami=self.client("ssm").get_parameter(Name="/aws/service/ami-amazon-linux-latest/al2023-ami-kernel-default-x86_64")["Parameter"]["Value"]
        self.record("ami",ami)
        time.sleep(12)
        instance=ec2.run_instances(ImageId=ami,MinCount=1,MaxCount=1,InstanceType="t3.micro",IamInstanceProfile={"Name":self.r["instance_profile"]},MetadataOptions={"HttpTokens":"required","HttpEndpoint":"enabled"},CreditSpecification={"CpuCredits":"standard"},BlockDeviceMappings=[{"DeviceName":"/dev/xvda","Ebs":{"VolumeSize":8,"VolumeType":"gp3","Encrypted":True,"DeleteOnTermination":True}}],NetworkInterfaces=[{"DeviceIndex":0,"SubnetId":subnet["SubnetId"],"Groups":[sg],"AssociatePublicIpAddress":True}],TagSpecifications=[{"ResourceType":t,"Tags":TAGS+[{"Key":"Name","Value":PREFIX+"-telemetry"}]} for t in ("instance","volume")],ClientToken=PREFIX+"-host")["Instances"][0]
        self.record("host_id",instance["InstanceId"])
        self.record("az",instance["Placement"]["AvailabilityZone"])
        role=self.role("-pep-role","lambda.amazonaws.com")
        log="/aws/lambda/"+PREFIX+"-pep"
        logs=self.client("logs")
        for group in (log,"/aws/apigateway/"+PREFIX):
            logs.create_log_group(logGroupName=group,tags={x["Key"]:x["Value"] for x in TAGS})
            logs.put_retention_policy(logGroupName=group,retentionInDays=7)
        policy={"Version":"2012-10-17","Statement":[
            {"Effect":"Allow","Action":["logs:CreateLogStream","logs:PutLogEvents"],"Resource":f"arn:aws:logs:{REGION}:{PROJECT}:log-group:{log}:*"},
            {"Effect":"Allow","Action":["kms:GenerateDataKey"],"Resource":self.r["data_key"],"Condition":{"StringEquals":{"kms:EncryptionContext:Project":PREFIX}}},
            {"Effect":"Allow","Action":["kms:Verify"],"Resource":self.r["signing_key"]},
            {"Effect":"Allow","Action":["ssm:DescribeInstanceInformation"],"Resource":"*"},
            {"Effect":"Allow","Action":["dynamodb:GetItem"],"Resource":f"arn:aws:dynamodb:{REGION}:{PROJECT}:table/{self.r['state_table']}"},
            {"Effect":"Allow","Action":["dynamodb:PutItem"],"Resource":f"arn:aws:dynamodb:{REGION}:{PROJECT}:table/{self.r['replay_table']}"}]}
        iam.put_role_policy(RoleName=PREFIX+"-pep-role",PolicyName=PREFIX+"-base",PolicyDocument=json.dumps(policy))
        self.write("pep_iam_policy.json",policy)
        env={"PROJECT":PREFIX,"POLICY_VERSION":"frozen-P60-staging-v1","POLICY_STATE":"active","HOST_ID":self.r["host_id"],"CLIENT_ID":self.r["client_id"],"ISSUER":self.r["issuer"],"SCOPE":SCOPE,"DATA_KEY":self.r["data_key"],"SIGNING_KEY":self.r["signing_key"],"TELEMETRY_ISSUER":PREFIX+"-ssm-operator","STATE_TABLE":self.r["state_table"],"REPLAY_TABLE":self.r["replay_table"]}
        self.record("normal_environment",env)
        source=read_handler()
        mem=io.BytesIO()
        with zipfile.ZipFile(mem,"w",zipfile.ZIP_DEFLATED) as z:z.writestr("isolated_pep.py",source)
        self.record("handler_sha256",hashlib.sha256(source).hexdigest())
        time.sleep(12)
        fn=self.client("lambda").create_function(FunctionName=PREFIX+"-pep",Runtime="python3.12",Role=role,Handler="isolated_pep.handler",Code={"ZipFile":mem.getvalue()},Timeout=15,MemorySize=256,Environment={"Variables":env},Tags={x["Key"]:x["Value"] for x in TAGS})
        self.record("function_arn",fn["FunctionArn"])
        self.client("lambda").get_waiter("function_active_v2").wait(FunctionName=PREFIX+"-pep",WaiterConfig={"Delay":3,"MaxAttempts":60})
        api=self.client("apigatewayv2")
        a=api.create_api(Name=PREFIX+"-api",ProtocolType="HTTP",Tags={x["Key"]:x["Value"] for x in TAGS})
        self.record("api_id",a["ApiId"]); self.record("api_endpoint",a["ApiEndpoint"])
        auth=api.create_authorizer(ApiId=a["ApiId"],Name=PREFIX+"-jwt",AuthorizerType="JWT",IdentitySource=["$request.header.Authorization"],JwtConfiguration={"Issuer":self.r["issuer"],"Audience":[self.r["client_id"]]})
        integration=api.create_integration(ApiId=a["ApiId"],IntegrationType="AWS_PROXY",IntegrationUri=fn["FunctionArn"],PayloadFormatVersion="2.0",TimeoutInMillis=15000)
        for route in ("POST /key","POST /baseline"):
            api.create_route(ApiId=a["ApiId"],RouteKey=route,Target="integrations/"+integration["IntegrationId"],AuthorizationType="JWT",AuthorizerId=auth["AuthorizerId"],AuthorizationScopes=[SCOPE])
        self.client("lambda").add_permission(FunctionName=PREFIX+"-pep",StatementId=PREFIX+"-gateway",Action="lambda:InvokeFunction",Principal="apigateway.amazonaws.com",SourceArn=f"arn:aws:execute-api:{REGION}:{PROJECT}:{a['ApiId']}/*/POST/*",SourceAccount=PROJECT)
        api.create_stage(ApiId=a["ApiId"],StageName="$default",AutoDeploy=True,DefaultRouteSettings={"ThrottlingBurstLimit":5,"ThrottlingRateLimit":5.0},AccessLogSettings={"DestinationArn":f"arn:aws:logs:{REGION}:{PROJECT}:log-group:/aws/apigateway/{PREFIX}","Format":json.dumps({"requestId":"$context.requestId","status":"$context.status","responseLatency":"$context.responseLatency","integrationError":"$context.integrationErrorMessage"})})
        self.record("deployment_status","CREATED_AWAITING_CONTROL_TEST")
        return self.r

    def guard_resources(self):
        if self.r.get("project")!=PROJECT or self.r.get("prefix")!=PREFIX: raise ValueError("STOP_MISSING_DEPLOYMENT")
        fn=self.client("lambda").get_function(FunctionName=PREFIX+"-pep")
        if fn["Configuration"]["FunctionArn"]!=self.r["function_arn"] or fn.get("Tags",{}).get("Project")!=PREFIX: raise ValueError("STOP_FUNCTION_OWNERSHIP")
        host=self.client("ec2").describe_instances(InstanceIds=[self.r["host_id"]])["Reservations"][0]["Instances"][0]
        if dict((x["Key"],x["Value"]) for x in host.get("Tags",[])).get("Project")!=PREFIX: raise ValueError("STOP_HOST_OWNERSHIP")

    def configure(self, **overrides):
        env=dict(self.r["normal_environment"],**overrides)
        self.client("lambda").update_function_configuration(FunctionName=PREFIX+"-pep",Environment={"Variables":env})
        self.client("lambda").get_waiter("function_updated_v2").wait(FunctionName=PREFIX+"-pep",WaiterConfig={"Delay":2,"MaxAttempts":40})

    def state_table(self):
        return self.session.resource("dynamodb",config=CONF).Table(self.r["state_table"])

    def telemetry(self, subject):
        self.guard_resources()
        ssm=self.client("ssm")
        # A fixed read-only command. Nothing from the HTTP caller enters this shell.
        command="python3 -c 'import json,platform,time,pathlib,subprocess; print(json.dumps({\"kernel\":platform.release(),\"observed_guest_epoch\":int(time.time()),\"boot_id\":pathlib.Path(\"/proc/sys/kernel/random/boot_id\").read_text().strip(),\"ssm_service_active\":subprocess.run([\"systemctl\",\"is-active\",\"amazon-ssm-agent\"],capture_output=True,text=True).stdout.strip()==\"active\"}))'"
        cid=ssm.send_command(InstanceIds=[self.r["host_id"]],DocumentName="AWS-RunShellScript",Parameters={"commands":[command]},TimeoutSeconds=60,Comment=PREFIX+" operational telemetry")['Command']['CommandId']
        for _ in range(40):
            try:inv=ssm.get_command_invocation(CommandId=cid,InstanceId=self.r["host_id"])
            except ssm.exceptions.InvocationDoesNotExist:time.sleep(3);continue
            if inv["Status"] in ("Success","Failed","Cancelled","TimedOut"):break
            time.sleep(3)
        else:raise ValueError("STOP_TELEMETRY_COMMAND_NOT_COMPLETE")
        if inv["Status"]!="Success":raise ValueError("STOP_TELEMETRY_COMMAND_FAILED")
        guest=json.loads(inv["StandardOutputContent"].strip())
        observation={"issuer":self.r["normal_environment"]["TELEMETRY_ISSUER"],"host":self.r["host_id"],"subject":subject,"observed_ms":int(time.time()*1000),"nonce":uuid.uuid4().hex,"compliant":bool(guest.get("ssm_service_active") and guest.get("boot_id")),"criterion":"SSM active and guest boot identifier present; not vulnerability or integrity assessment","guest":guest,"ssm_command_id":cid}
        raw=json.dumps(observation,sort_keys=True,separators=(",",":")).encode()
        sig=self.client("kms").sign(KeyId=self.r["signing_key"],Message=raw,MessageType="RAW",SigningAlgorithm="ECDSA_SHA_256")["Signature"]
        state={"pk":"host:"+self.r["host_id"],"subject":subject,"revoked":False,"posture_raw":raw.hex(),"signature":sig.hex()}
        self.state_table().put_item(Item=state)
        self.write("telemetry_latest.json",observation)
        return state

    def token(self):
        c=self.client("cognito-idp").describe_user_pool_client(UserPoolId=self.r["pool_id"],ClientId=self.r["client_id"])["UserPoolClient"]
        basic=base64.b64encode((c["ClientId"]+":"+c["ClientSecret"]).encode()).decode()
        request=urllib.request.Request(f"https://{self.r['domain']}.auth.{REGION}.amazoncognito.com/oauth2/token",data=urllib.parse.urlencode({"grant_type":"client_credentials","scope":SCOPE}).encode(),headers={"Authorization":"Basic "+basic,"Content-Type":"application/x-www-form-urlencoded"})
        for attempt in range(12):
            try:
                with urllib.request.urlopen(request,timeout=20) as response:body=json.load(response)
                token=body["access_token"]
                # Local decoding only supplies the registration subject; trust is
                # established by the route's real RSA/JWKS authorizer, not decoding.
                payload=token.split(".")[1]; claims=json.loads(base64.urlsafe_b64decode(payload+"="*(-len(payload)%4)))
                return token,claims
            except (urllib.error.URLError,KeyError):
                if attempt==11:raise ValueError("STOP_OAUTH_TOKEN_UNAVAILABLE") from None
                time.sleep(5)

    def tests(self):
        self.guard_resources()
        if self.r.get("deployment_status") not in ("CREATED_AWAITING_CONTROL_TEST","TESTS_FINISHED"):raise ValueError("STOP_DEPLOYMENT_INCOMPLETE")
        host=self.r["host_id"]; ec2=self.client("ec2"); ssm=self.client("ssm"); rows=[]
        current=ec2.describe_instances(InstanceIds=[host])["Reservations"][0]["Instances"][0]["State"]["Name"]
        if current=="stopped":ec2.start_instances(InstanceIds=[host])
        elif current not in ("running","pending"):raise ValueError("STOP_HOST_STATE_NOT_READY")
        for _ in range(90):
            info=ssm.describe_instance_information(Filters=[{"Key":"InstanceIds","Values":[host]}]).get("InstanceInformationList",[])
            if info and info[0].get("PingStatus")=="Online":break
            time.sleep(5)
        else:raise ValueError("STOP_SSM_HOST_NOT_ONLINE")
        token,claims=self.token(); subject=str(claims["sub"])
        self.write("identity_validation_boundary.json",{"flow":"Cognito OAuth2 client_credentials","claims_checked_in_backend":["issuer","client_id","token_use","iat","nbf_if_present","exp","scope"],"gateway_signature_validation":"real RSA issuer JWKS on authenticated route; successful route is required","subject_kind":"machine identity","pkce_nonce_gate":"NOT_TESTED_NOT_CLAIMED","token_retained":False})
        original=self.telemetry(subject)
        self.configure()
        def request(label, expected, path="/key", token_override=None, headers_override=None, shared_nonce=None):
            issued=int(time.time()*1000)
            headers={"Authorization":"Bearer "+(token if token_override is None else token_override),"Content-Type":"application/json","x-host":host,"x-request-nonce":shared_nonce or uuid.uuid4().hex,"x-policy-version":self.r["normal_environment"]["POLICY_VERSION"],"x-permit-issued-ms":str(issued),"x-deadline-ms":str(issued+60000)}
            headers.update(headers_override or {})
            req=urllib.request.Request(self.r["api_endpoint"]+path,data=b"{}",headers=headers,method="POST")
            began=time.perf_counter_ns()
            try:
                with urllib.request.urlopen(req,timeout=25) as response:status=response.status; raw=response.read(); external_id=response.headers.get("apigw-requestid")
            except urllib.error.HTTPError as error:status=error.code; raw=error.read();external_id=error.headers.get("apigw-requestid")
            except urllib.error.URLError as error:
                rows.append({"case":label,"expected_status":expected,"status":None,"transport_error_type":type(error.reason).__name__,"pass":False,"observed_utc":now()});self.write("route_results.json",rows);return None
            try:body=json.loads(raw)
            except (ValueError,UnicodeError):body={"non_json":True}
            row={"case":label,"expected_status":expected,"status":status,"response":body,"external_request_id":external_id,"latency_ms":round((time.perf_counter_ns()-began)/1e6,3),"observed_utc":now(),"runner":"AWS_CLOUDSHELL_CONTROL_RUNNER" if self.args.cloudshell else "LOCAL_CLI_CONTROL_RUNNER","host":host,"date_utc":now()[:10],"pass":status==expected}
            rows.append(row);self.write("route_results.json",rows)
            print(json.dumps({"case":label,"status":status,"pass":row["pass"]}),flush=True)
            time.sleep(.3)
            return row
        deny_policy={"Version":"2012-10-17","Statement":[{"Effect":"Deny","Action":"kms:GenerateDataKey","Resource":self.r["data_key"]}]}
        fault_name=PREFIX+"-fault-deny"
        try:
            control=request("control_allow",200)
            if not control or not control["pass"] or control["response"].get("key_operation_succeeded") is not True:raise ValueError("STOP_NO_SUCCESSFUL_ROUTE_CONTROL")
            request("missing_assertion",401,token_override="")
            # Change JWT signature bytes without retaining the token in evidence.
            parts=token.split("."); sig=parts[2]; parts[2]=("A" if sig[0]!="A" else "B")+sig[1:]
            request("tampered_signature",401,token_override=".".join(parts))
            request("host_mismatch",403,headers_override={"x-host":"invalid-host"})
            request("expired_permit",403,headers_override={"x-deadline-ms":"1"})
            nonce=uuid.uuid4().hex
            request("replay_first",200,shared_nonce=nonce);request("replay_reuse",403,shared_nonce=nonce)
            bad_signature=bytearray.fromhex(original["signature"]);bad_signature[-1]^=1
            for label,change in [("subject_binding_mismatch",{"subject":"invalid-subject"}),("missing_posture",{"posture_raw":""}),("invalid_posture_signature",{"signature":bad_signature.hex()}),("revoked",{"revoked":True})]:
                self.state_table().put_item(Item=dict(original,**change));request(label,403);self.state_table().put_item(Item=original)
            stale=json.loads(bytes.fromhex(original["posture_raw"]));stale["observed_ms"]=int(time.time()*1000)-600001
            raw=json.dumps(stale,sort_keys=True,separators=(",",":")).encode()
            signature=self.client("kms").sign(KeyId=self.r["signing_key"],Message=raw,MessageType="RAW",SigningAlgorithm="ECDSA_SHA_256")["Signature"]
            self.state_table().put_item(Item=dict(original,posture_raw=raw.hex(),signature=signature.hex()));request("signed_stale_posture",403);self.state_table().put_item(Item=original)
            self.configure(POLICY_STATE="rollback");request("rollback",403);self.configure();request("rollback_recovery",200)
            # Actual KMS authorization failure, not a mocked exception.
            self.client("iam").put_role_policy(RoleName=PREFIX+"-pep-role",PolicyName=fault_name,PolicyDocument=json.dumps(deny_policy))
            try:
                # IAM propagation is observed rather than assumed instantaneous.
                for i in range(12):
                    fault=request("kms_deny_probe_"+str(i),503)
                    if fault and fault["status"]==503 and fault["response"].get("error_code") in ("AccessDeniedException","AccessDenied"):break
                    time.sleep(5)
            finally:self.client("iam").delete_role_policy(RoleName=PREFIX+"-pep-role",PolicyName=fault_name)
            for i in range(12):
                recovered=request("kms_recovery_probe_"+str(i),200)
                if recovered and recovered["pass"]:break
                time.sleep(5)
            for label,override in [("ssm_transport_fault",{"SSM_ENDPOINT":"https://10.255.255.1"}),("dynamodb_transport_fault",{"DDB_ENDPOINT":"https://10.255.255.1"})]:
                self.telemetry(subject);self.configure(**override)
                try:request(label,503)
                finally:self.configure()
                request(label+"_recovery",200)
            self.telemetry(subject)
            # Descriptive route overhead only; no request-level cluster CI.
            for i in range(10):
                request("baseline_"+str(i),200,path="/baseline")
                request("full_"+str(i),200)
            self.collect_audit(rows)
        finally:
            # Restore only dedicated experimental configuration. Preserve evidence.
            self.configure()
            self.state_table().put_item(Item=original)
            ec2.stop_instances(InstanceIds=[host])
            self.record("host_stop_requested_utc",now())
        self.record("deployment_status","TESTS_FINISHED")
        self.summarize(rows)
        self.archive()
        return {"rows":len(rows),"status":"STAGING_TESTS_FINISHED_RESULTS_REQUIRE_REVIEW"}

    def collect_audit(self, rows):
        # CloudTrail management-event delivery can lag. An empty observation is
        # explicitly inconclusive; the script does not prove absence from silence.
        ct=self.client("cloudtrail"); matched=[]
        since=dt.datetime.fromisoformat(self.r["created_utc"])
        for page in ct.get_paginator("lookup_events").paginate(LookupAttributes=[{"AttributeKey":"EventName","AttributeValue":"GenerateDataKey"}],StartTime=since,PaginationConfig={"MaxItems":500}):
            for item in page.get("Events",[]):
                e=json.loads(item.get("CloudTrailEvent","{}"));params=e.get("requestParameters") or {}
                if (params.get("encryptionContext") or {}).get("Project")==PREFIX:
                    matched.append({"event_id":e.get("eventID"),"time":e.get("eventTime"),"aws_request_id":e.get("requestID"),"error_code":e.get("errorCode"),"encryption_context":params.get("encryptionContext"),"event_source":e.get("eventSource")})
        self.write("kms_cloudtrail_observed.json",{"observed_utc":now(),"events":matched,"absence_conclusion":"INCONCLUSIVE_DELIVERY_WINDOW_NOT_CLOSED","no_key_operation_response_is":"handler evidence; use positive CloudTrail correlation where available"})
        logs=self.client("logs");events=[]
        for page in logs.get_paginator("filter_log_events").paginate(logGroupName="/aws/lambda/"+PREFIX+"-pep",PaginationConfig={"MaxItems":2000}):
            for e in page.get("events",[]):
                message=e.get("message","")
                if message.startswith(("INIT_START","START RequestId:","REPORT RequestId:")) or '"lontar_audit"' in message:
                    events.append({"timestamp":e["timestamp"],"stream":e["logStreamName"],"message":message})
        self.write("lambda_sanitized_audit.json",events)

    def summarize(self, rows):
        def quantiles(values):
            s=sorted(values)
            def q(p):return s[max(0,min(len(s)-1,int(__import__('math').ceil(len(s)*p))-1))]
            return {"n":len(s),"median_ms":statistics.median(s),"p95_ms":q(.95),"p99_ms":q(.99)} if s else {"n":0}
        summary={"project":PROJECT,"created_utc":now(),"environment":"AWS staging","host":self.r["host_id"],"runner_count":1,"new_host_day_clusters":1,"primary_data_modified":False,"primary_certification_transferred":False,"protocol":"M2M control route and operator-controlled faults; not PKCE/hardware attestation/production","latency":{},"failures":[]}
        for name in ("baseline","full"):
            arm=[r for r in rows if r["case"].startswith(name+"_")]
            summary["latency"][name]={"all":quantiles([r["latency_ms"] for r in arm if r.get("status")==200]),"error_count":sum(r.get("status")!=200 for r in arm),"cold_definition":"Only REPORT Init Duration/INIT_START evidence can substantiate cold start; first_handler_invocation alone is provisional"}
        for r in rows:
            if not r.get("pass"):summary["failures"].append({"case":r["case"],"status":r.get("status"),"expected":r["expected_status"]})
        summary["cluster_uncertainty"]="NOT_ESTIMABLE_FROM_ONE_HOST_DAY; request quantiles descriptive only"
        self.write("summary.json",summary)

    def archive(self):
        manifest={}
        for p in self.root.iterdir():
            if p.is_file() and p.suffix==".json":manifest[p.name]=hashlib.sha256(p.read_bytes()).hexdigest()
        self.write("manifest.json",manifest)
        key="isolated/20261022/"+self.root.name+"/"
        for p in self.root.iterdir():
            if p.is_file() and p.suffix==".json":self.client("s3").upload_file(str(p),BUCKET,key+p.name,ExtraArgs={"ServerSideEncryption":"AES256","ContentType":"application/json"})
        print(json.dumps({"evidence_s3_prefix":"s3://"+BUCKET+"/"+key,"secrets_retained":False}),flush=True)

    def stop_new_host_after_failure(self):
        if not self.r.get("host_id"):return
        host=self.client("ec2").describe_instances(InstanceIds=[self.r["host_id"]])["Reservations"][0]["Instances"][0]
        tags={x["Key"]:x["Value"] for x in host.get("Tags",[])}
        if tags.get("Project")!=PREFIX:raise ValueError("STOP_FAILURE_CLEANUP_OWNERSHIP")
        if host["State"]["Name"] in ("pending","running"):
            self.client("ec2").stop_instances(InstanceIds=[self.r["host_id"]])
            self.record("failure_host_stop_requested_utc",now())


def read_handler():
    if zipfile.is_zipfile(sys.argv[0]):
        with zipfile.ZipFile(sys.argv[0]) as archive:return archive.read("isolated_pep.py")
    return Path(__file__).with_name("isolated_pep.py").read_bytes()


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("action",choices=["plan","deploy","test","archive"])
    parser.add_argument("--cloudshell",action="store_true")
    parser.add_argument("--output",default="lontar-akp-isolated-run-20261022")
    parser.add_argument("--confirm-project")
    args=parser.parse_args()
    if args.action!="plan" and args.confirm_project!=PROJECT:raise SystemExit("STOP_CONFIRM_PROJECT_REQUIRED")
    lab=None
    try:
        lab=Lab(args)
        out=getattr(lab,args.action if args.action!="test" else "tests")()
        print(json.dumps({"result":out},default=str),flush=True)
    except (ClientError,BotoCoreError,ValueError,KeyError,urllib.error.URLError) as error:
        safe={"status":"STOPPED","error_type":type(error).__name__}
        if isinstance(error,ClientError):safe["error_code"]=error.response.get("Error",{}).get("Code","unknown")
        if isinstance(error,ValueError) and str(error).startswith("STOP_"):safe["gate"]=str(error)
        if lab:
            lab.write("execution_error.json",safe)
            if args.action in ("deploy","test"):
                try:lab.stop_new_host_after_failure()
                except (ClientError,BotoCoreError,ValueError,KeyError) as cleanup:
                    lab.write("host_stop_error.json",{"error_type":type(cleanup).__name__,"status":"MANUAL_HOST_STOP_REVIEW_REQUIRED"})
        print(json.dumps(safe),flush=True)
        return 1
    return 0


if __name__=="__main__":
    sys.exit(main())
