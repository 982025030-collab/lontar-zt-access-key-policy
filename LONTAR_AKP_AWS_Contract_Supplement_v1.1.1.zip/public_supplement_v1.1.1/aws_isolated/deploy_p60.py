"""Create-only isolated P60 contract deployment; no changes to old endpoints/roles."""
import argparse
import io
import json
import os
import sys
from pathlib import Path
import time
import zipfile
from deploy_isolated import Lab,PROJECT,REGION,SCOPE,now

PREFIX='lontar-akp-isolated-p60-20261028'


def run(args):
    source=json.loads(Path(args.journal).read_text())
    if source.get('project')!=PROJECT or source.get('region')!=REGION:raise ValueError('STOP_PROJECT_JOURNAL')
    lab=Lab(args);lab.r=source;lab.guard_resources()
    target=Path(args.output).resolve()
    journal=target/'p60_resources.json'
    if journal.exists():raise ValueError('STOP_EXISTING_DEPLOYMENT_JOURNAL')
    r={'project':PROJECT,'region':REGION,'prefix':PREFIX,'created_utc':now(),'source_journal':str(Path(args.journal).resolve()),'old_project_modified':False}
    def record(k,v):
        r[k]=v;journal.write_text(json.dumps(r,indent=2,sort_keys=True)+'\n');print(json.dumps({'step':k,'status':'RECORDED'}),flush=True)
    record('identity',lab.identity)
    plan=lab.client('freetier').get_account_plan_state();record('plan_type',plan['accountPlanType'])
    # No existing deployment is implicitly adopted.
    iam=lab.client('iam');kms=lab.client('kms');lam=lab.client('lambda');logs=lab.client('logs')
    for page in iam.get_paginator('list_roles').paginate():
        if any(x['RoleName'].startswith(PREFIX) for x in page['Roles']):raise ValueError('STOP_PREFIX_ALREADY_EXISTS')
    key=kms.create_key(Description=PREFIX+' issuer permit signature',KeySpec='ECC_NIST_P256',KeyUsage='SIGN_VERIFY',MultiRegion=False,Tags=[{'TagKey':'Project','TagValue':PREFIX}])['KeyMetadata']['Arn']
    record('permit_key',key)
    arns={role:f'arn:aws:lambda:{REGION}:{PROJECT}:function:{PREFIX}-{role}' for role in ('collector','issuer','pep')}
    record('functions',arns)
    base=source['normal_environment']
    for role in ('collector','issuer','pep'):
        name=PREFIX+'-'+role+'-role'
        trust={'Version':'2012-10-17','Statement':[{'Effect':'Allow','Principal':{'Service':'lambda.amazonaws.com'},'Action':'sts:AssumeRole'}]}
        arn=iam.create_role(RoleName=name,AssumeRolePolicyDocument=json.dumps(trust),Tags=[{'Key':'Project','Value':PREFIX}])['Role']['Arn'];record(role+'_role',arn)
        group='/aws/lambda/'+PREFIX+'-'+role;logs.create_log_group(logGroupName=group,tags={'Project':PREFIX});logs.put_retention_policy(logGroupName=group,retentionInDays=7)
        statements=[{'Effect':'Allow','Action':['logs:CreateLogStream','logs:PutLogEvents'],'Resource':f'arn:aws:logs:{REGION}:{PROJECT}:log-group:{group}:*'}]
        if role=='collector':
            statements += [{'Effect':'Allow','Action':['kms:Sign','kms:Verify'],'Resource':source['signing_key']},
                {'Effect':'Allow','Action':'dynamodb:GetItem','Resource':f'arn:aws:dynamodb:{REGION}:{PROJECT}:table/{source["state_table"]}',
                 'Condition':{'ForAllValues:StringEquals':{'dynamodb:LeadingKeys':['host:'+source['host_id']]},'Null':{'dynamodb:LeadingKeys':'false'}}},
                {'Effect':'Allow','Action':'ssm:DescribeInstanceInformation','Resource':'*'}]
        else:
            statements += [{'Effect':'Allow','Action':'lambda:InvokeFunction','Resource':arns['collector']},
                           {'Effect':'Allow','Action':'kms:Verify','Resource':source['signing_key']}]
            statements += [{'Effect':'Allow','Action':'kms:Sign' if role=='issuer' else 'kms:Verify','Resource':key}]
            if role=='pep':
                statements += [{'Effect':'Allow','Action':'kms:GenerateDataKey','Resource':source['data_key'],'Condition':{'StringEquals':{'kms:EncryptionContext:Project':PREFIX}}},
                 {'Effect':'Allow','Action':'dynamodb:PutItem','Resource':f'arn:aws:dynamodb:{REGION}:{PROJECT}:table/{source["replay_table"]}',
                  'Condition':{'ForAllValues:StringLike':{'dynamodb:LeadingKeys':[PREFIX+':*']},'Null':{'dynamodb:LeadingKeys':'false'}}}]
        policy={'Version':'2012-10-17','Statement':statements};lab.write(role+'_policy.json',policy)
        iam.put_role_policy(RoleName=name,PolicyName=PREFIX+'-scoped',PolicyDocument=json.dumps(policy))
    data=io.BytesIO()
    with zipfile.ZipFile(data,'w',zipfile.ZIP_DEFLATED) as z:
        for file in ('p60_runtime.py','p60_contract.py'):
            if Path(sys.argv[0]).suffix=='.pyz':
                with zipfile.ZipFile(sys.argv[0]) as archive:raw=archive.read(file)
            else:raw=Path(__file__).with_name(file).read_bytes()
            z.writestr(file,raw)
    env={'PROJECT':PREFIX,'HOST_ID':source['host_id'],'STATE_TABLE':source['state_table'],'REPLAY_TABLE':source['replay_table'],
         'PERMIT_KEY':key,'POSTURE_KEY':source['signing_key'],'DATA_KEY':source['data_key'],'TELEMETRY_ISSUER':base['TELEMETRY_ISSUER'],
         'CLIENT_ID':source['client_id'],'ISSUER':source['issuer'],'SCOPE':SCOPE,'COLLECTOR_ARN':arns['collector']}
    record('environment',env)
    for role in ('collector','issuer','pep'):
        for attempt in range(20):
            try:
                lam.create_function(FunctionName=PREFIX+'-'+role,Runtime='python3.12',Role=r[role+'_role'],Handler='p60_runtime.handler',Code={'ZipFile':data.getvalue()},Timeout=15,MemorySize=256,Environment={'Variables':dict(env,ROLE=role)},Tags={'Project':PREFIX})
                break
            except lam.exceptions.InvalidParameterValueException:
                if attempt==19:raise
                time.sleep(3)
        lam.get_waiter('function_active_v2').wait(FunctionName=PREFIX+'-'+role,WaiterConfig={'Delay':2,'MaxAttempts':40})
        record(role+'_active',True)
    api=lab.client('apigatewayv2');a=api.create_api(Name=PREFIX,ProtocolType='HTTP',Tags={'Project':PREFIX})
    record('api_id',a['ApiId']);record('endpoint',a['ApiEndpoint'])
    auth=api.create_authorizer(ApiId=a['ApiId'],Name=PREFIX+'-jwt',AuthorizerType='JWT',IdentitySource=['$request.header.Authorization'],JwtConfiguration={'Audience':[source['client_id']],'Issuer':source['issuer']})
    for role,path in [('issuer','/permit'),('pep','/key')]:
        integration=api.create_integration(ApiId=a['ApiId'],IntegrationType='AWS_PROXY',IntegrationUri=arns[role],PayloadFormatVersion='2.0',TimeoutInMillis=15000)
        api.create_route(ApiId=a['ApiId'],RouteKey='POST '+path,Target='integrations/'+integration['IntegrationId'],AuthorizationType='JWT',AuthorizerId=auth['AuthorizerId'],AuthorizationScopes=[SCOPE])
        lam.add_permission(FunctionName=PREFIX+'-'+role,StatementId=PREFIX+'-gateway',Action='lambda:InvokeFunction',Principal='apigateway.amazonaws.com',SourceAccount=PROJECT,SourceArn=f'arn:aws:execute-api:{REGION}:{PROJECT}:{a["ApiId"]}/*/POST{path}')
    api.create_stage(ApiId=a['ApiId'],StageName='$default',AutoDeploy=True,DefaultRouteSettings={'ThrottlingBurstLimit':5,'ThrottlingRateLimit':5.0})
    record('deployment_status','CREATED_UNTESTED');return r


def main():
    p=argparse.ArgumentParser();p.add_argument('--cloudshell',action='store_true');p.add_argument('--journal',required=True);p.add_argument('--output',required=True);p.add_argument('--confirm-project',required=True);args=p.parse_args()
    if args.confirm_project!=PROJECT:raise ValueError('STOP_CONFIRM_PROJECT')
    if args.cloudshell and os.environ.get('AWS_EXECUTION_ENV')!='CloudShell':raise ValueError('STOP_CLOUDSHELL_REQUIRED')
    try:print(json.dumps({'result':run(args)},sort_keys=True),flush=True)
    except Exception as error:
        safe={'status':'STOPPED','error_type':type(error).__name__}
        if hasattr(error,'response'):safe['error_code']=error.response.get('Error',{}).get('Code')
        if isinstance(error,ValueError) and str(error).startswith('STOP_'):safe['gate']=str(error)
        target=Path(args.output)
        if target.exists():(target/'deployment_error.json').write_text(json.dumps(safe)+'\n')
        print(json.dumps(safe),flush=True)


if __name__=='__main__':main()
