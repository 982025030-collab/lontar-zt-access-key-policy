"""P60 contract primitives. Millisecond timestamps; no AWS dependencies."""
import hashlib
import json
import math

POLICY='online_60_patient'
TTL_MS=60000
EVIDENCE_DEADLINE_MS=500


def canonical(value):
    return json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False).encode()


def fingerprint(value):
    return hashlib.sha256(canonical(value)).hexdigest()


def valid_time(claim,now_ms):
    for name in ('iat_ms','exp_ms'):
        if type(claim[name]) is not int:raise ValueError('invalid_time_type')
    if not claim['iat_ms']<=now_ms<claim['exp_ms']:raise ValueError('expired_or_future')


def permit_valid(g,subject,host,project,now_ms):
    valid_time(g,now_ms)
    expected={'typ':'lontar-permit-v1','iss':project+'-issuer','aud':project+'-pep',
              'sub':subject,'host':host,'object':'alpha','operation':'protected_key_use',
              'policy':POLICY,'online':True,'evidence_deadline_ms':EVIDENCE_DEADLINE_MS}
    if any(g.get(k)!=v or type(g.get(k)) is not type(v) for k,v in expected.items()):raise ValueError('permit_binding')
    if not isinstance(g.get('jti'),str) or not 16<=len(g['jti'])<=128:raise ValueError('permit_jti')
    if g['exp_ms']>min(g['iat_ms']+TTL_MS,g['evidence_exp_ms'],g['identity_exp_ms']):raise ValueError('permit_expiry_binding')


def evidence_valid(e,subject,host,project,audience,nonce,now_ms):
    valid_time(e,now_ms)
    expected={'typ':'lontar-evidence-v1','iss':project+'-collector','aud':audience,
              'sub':subject,'host':host,'object':'alpha','nonce':nonce,'healthy':True,'entitled':True}
    if any(e.get(k)!=v or type(e.get(k)) is not type(v) for k,v in expected.items()):raise ValueError('evidence_binding_or_negative')


def deadline_valid(elapsed_ms):
    if not math.isfinite(elapsed_ms) or elapsed_ms>EVIDENCE_DEADLINE_MS:raise ValueError('evidence_deadline')
