"""Reanalyse retained AWS responses; no cloud access or fitted risk certificate."""
from pathlib import Path
import hashlib
import json
import math
import re
import statistics

ROOT = Path(__file__).resolve().parent


def main():
    run = ROOT / 'lontar-akp-isolated-p60-run-20261028-01'
    private_manifest = run / 'SHA256_MANIFEST.json'
    manifest_root = run if private_manifest.exists() else ROOT
    manifest_path = private_manifest if private_manifest.exists() else ROOT / 'PUBLIC_SHA256.json'
    manifest = json.loads(manifest_path.read_text())
    bad = [name for name, digest in manifest.items()
           if hashlib.sha256((manifest_root / name).read_bytes()).hexdigest() != digest]
    if bad:
        raise ValueError(f'Integrity failure: {bad}')
    rows = json.loads((run / 'route_results.json').read_text())
    logs = json.loads((run / 'lambda_audit.json').read_text())
    reports = {}
    for item in logs:
        match = re.search(r'REPORT RequestId:\s*(\S+)', item['message'])
        if match:
            reports[match[1]] = item['message']
    arms = []
    for role in ('issuer', 'pep'):
        for cold in (False, True):
            group = [r for r in rows if r['response']['role'] == role and r['status'] == 200
                     and r['response']['lambda_request_id'] in reports
                     and ('Init Duration:' in reports[r['response']['lambda_request_id']]) == cold]
            values = sorted(r['latency_ms'] for r in group)
            if values:
                arms.append(dict(role=role, state='cold' if cold else 'warm', n=len(values),
                                 median_ms=statistics.median(values),
                                 p95_ms=values[math.ceil(.95 * len(values)) - 1],
                                 p99_ms=values[math.ceil(.99 * len(values)) - 1]))
    negative = [r for r in rows if r['expected_status'] != 200]
    result = dict(requests=len(rows), permit_issues=sum(r['response']['role'] == 'issuer' for r in rows),
                  successful_key_operations=sum(r['response']['key_operation_succeeded'] for r in rows),
                  negative_cases=len(negative),
                  status_mismatches=[r['case'] for r in rows if r['status'] != r['expected_status']],
                  negative_key_attempts=[r['case'] for r in negative if r['response']['key_operation_attempted']],
                  missing_report_matches=[r['case'] for r in rows if r['response']['lambda_request_id'] not in reports],
                  latency_descriptive_only=arms, independent_host_days=1,
                  statistical_boundary='No request-level risk CI, no pooling with primary splits or older AWS protocols.')
    (ROOT / 'analysis.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
