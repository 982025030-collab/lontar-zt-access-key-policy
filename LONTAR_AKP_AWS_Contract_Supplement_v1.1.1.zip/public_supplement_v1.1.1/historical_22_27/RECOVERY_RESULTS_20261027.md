# Checkpoint recovery LONTAR ZT Access Key Policy — 27 Oktober 2026

**Recovery jalur staging API Gateway–PEP berhasil pada dua run baru. Kedua run telah selesai, konfigurasi normal dipulihkan, dan host dihentikan.** Hasil gagal sebelumnya tetap berlaku sebagai observasi historis; keberhasilan hari ini tidak membuktikan waktu pemulihan dari fault tanggal 22 Oktober.

## Eksekusi dan ruang lingkup

- Project **501250588559**, Region **ap-southeast-2**, runner **AWS CloudShell**.
- Host yang digunakan kembali: `i-074539dcf12635143`. Tidak ada host, IAM permission, Cognito client, key, atau endpoint publik baru.
- Project lama **322037002388** tidak diakses atau diubah oleh protokol ini. Dataset dan sertifikasi studi utama tidak diubah.
- Host semula stopped; protokol memverifikasi ownership, environment Lambda normal, ketiadaan policy deny sementara, dan tidak adanya revocation sebelum memulai host.
- Keduanya memakai token Cognito M2M aktual dalam memori, telemetry operasional SSM yang ditandatangani KMS, lalu request HTTPS ke endpoint API Gateway yang sama.
- Telemetry direfresh oleh produser sah setelah 90 detik. TTL posture tetap 300 detik dan lifetime permit tetap 60 detik. Snapshot telemetry disimpan per timestamp dan tercakup dalam manifest per-run.
- Tidak dilakukan deny injection baru. Ini checkpoint recovery saat ini, bukan pengukuran ulang latency propagasi IAM sejak fault lama.

## Protokol dan hasil per run

Recovery mensyaratkan tiga respons HTTP 200 berturut-turut yang menyatakan operasi kunci berhasil. Setelah itu dikumpulkan 20 kandidat warm per arm dalam urutan bergantian, tiga kandidat cold per arm melalui intervensi generation environment Lambda, dan satu kontrol akhir. Sampel hanya diklasifikasikan cold jika RequestId cocok dengan REPORT yang mengandung Init Duration; warm memerlukan REPORT cocok tanpa Init Duration serta first-handler-invocation=false.

| Hasil | Run01: tanpa pacing | Run02: paced |
|---|---:|---:|
| Jumlah request, semuanya dipertahankan | 50 | 50 |
| HTTP 200 | 42 | 50 |
| HTTP 429, Too Many Requests | 8 | 0 |
| Proporsi respons gagal yang diamati | 16% | 0% |
| Tiga kontrol recovery berturut-turut | Berhasil | Berhasil |
| Kontrol akhir | Berhasil | Berhasil |
| Environment normal dipulihkan | Ya | Ya |
| Host akhir | stopped | stopped |
| Error eksperimen / cleanup | Tidak ada | Tidak ada |
| Waktu verifikasi akhir, WIB | 27 Okt 23:07:19 | 27 Okt 23:14:52 |

Run01 tetap menyimpan kegagalan layanannya. Sesudah mengamati 429, protokol run02 direvisi secara eksplisit dengan minimum jeda satu detik antar-request. Throttle gateway tidak diubah. Minimum interval start-to-start yang terukur pada run02 adalah **1.000058 detik**. Waktu menunggu jadwal tidak dimasukkan ke latency HTTP.

Ini perubahan desain setelah melihat hasil run01, bukan protokol paced yang dipraregistrasikan sebelum seluruh eksperimen. Kedua run tidak digabung menjadi satu estimasi latency. Hasil tidak mengidentifikasi secara kausal bahwa pacing adalah satu-satunya penyebab perbedaan error: urutan run, waktu, dan keadaan runtime juga berbeda. HTTP 429 membuktikan penolakan rate-limit pada jalur yang diamati; tanpa atribusi log tambahan, jangan menyebut komponen tertentu sebagai penyebab tunggal.

## Latency run02, hanya sampel sukses dengan klasifikasi REPORT yang cocok

| Jalur / keadaan | n | Median ms | p95 ms | p99 ms | Gagal / kandidat |
|---|---:|---:|---:|---:|---:|
| Baseline, warm | 20 | 54.026 | 86.831 | 93.408 | 0/20 |
| PEP penuh, warm | 20 | 118.3975 | 178.804 | 178.848 | 0/20 |
| Baseline, cold | 3 | 845.680 | 933.488 | 933.488 | 0/3 |
| PEP penuh, cold | 3 | 1049.687 | 1161.193 | 1161.193 | 0/3 |

Selisih median deskriptif warm adalah **64.3715 ms**, cold **204.007 ms**. Ini perbedaan ringkasan dua arm, bukan efek kausal berpasangan, SLA produksi, atau keunggulan universal. Cold n=3 sangat kecil; p95/p99 memakai nearest-rank dan sama dengan maksimum sampel. Seluruh respons gagal run01 tersedia dalam CSV, bukan disembunyikan dalam statistik sampel sukses.

Baseline tetap melewati JWT authorizer dan operasi KMS, sementara arm penuh menambahkan pemeriksaan evidence/state/replay/SSM dan enforcement PEP sesuai implementasi staging. Karena itu angka ini bukan perbandingan terhadap layanan yang tidak melakukan kriptografi maupun baseline framework NIST/CISA.

## Bukti dan ketidakpastian

Kedua run menghasilkan **100 observasi dari satu host–hari, 27 Oktober 2026**. Banyaknya request tidak menambah jumlah host/hari independen. Jangan menggabungkannya dengan sembilan cluster historis project lama atau test set utama. Tidak dihitung confidence interval request-level sebagai pengganti ketidakpastian berbasis host–hari. Nol kegagalan pada 50 request paced bukan bukti risiko populasi nol atau sertifikasi batas risiko baru.

Respons PEP dan log Lambda memuat status operasi serta RequestId; REPORT mendukung klasifikasi cold/warm. Capture CloudTrail segera sesudah run belum menghasilkan korelasi positif baru. Capture read-only yang lebih lambat, **27 Oktober pukul 23:19:51 WIB**, memuat **166 event GenerateDataKey berhasil**: 74 dari bukti sebelumnya serta **92 yang cocok dengan seluruh request baru berhasil—42 run01 dan 50 run02**. Pencocokan memakai encryption-context RequestId, bukan sekadar kesamaan jumlah. Capture awal tetap dipertahankan sebagai contoh delivery window yang belum lengkap. Ketiadaan event untuk respons gagal tidak digunakan untuk membuktikan tidak adanya operasi. Pemeriksaan resource pada capture akhir kembali mengonfirmasi environment normal, policy deny sementara tidak ada, Lambda Active, dan host stopped.

Sesi CLI lokal masih expired; CloudShell tidak diekspor untuk memperbarui credential laptop. Token, client secret dan key material tidak disimpan pada artefak. Scan pola credential pada berkas dan isi source zipapp tidak menemukan access-key ID, JWT bearer atau private-key PEM; cakupan scan ini terbatas pada pola yang diperiksa.

## Integritas arsip

| Arsip CloudShell asli | Byte | SHA-256 | File manifest diverifikasi |
|---|---:|---|---:|
| `lontar-akp-isolated-recovery-20261027-run01.zip` | 57524 | `a92760c0c104ffa99410d35d4f3a9d28992d14b93506e3a9a26a3e380cb07cfa` | 11 |
| `lontar-akp-isolated-recovery-20261027-run02.zip` | 67006 | `11129c8394aee987cfd9f87c3e3d4d122d991fa23ab536e01b588da4354638d5` | 11 |

Checksum di laptop cocok dengan nilai yang dicetak CloudShell; CRC ZIP lulus. Source bundle turut disimpan dalam setiap run. Source run01 SHA-256: `746ef7178fc269cb6632b15bbf5b2aefce879e4d06598a5d88da4a21b2794f10`. Source paced run02: `419279811fb4fd5d4fef3fde9fe4f165ea975c0a9afa333b436dc2a158f01d39`. Pemeriksaan source dan manifest memakai berkas aktual, tanpa mengganti source lama dengan versi baru.

Replikasi analisis lokal:

```sh
python3 lontar_zt/aws_isolated/analyze_recovery.py \
  outputs/aws_isolated_20261027/lontar-akp-isolated-recovery-20261027-run01 \
  outputs/aws_isolated_20261027/lontar-akp-isolated-recovery-20261027-run02 \
  --later-audit outputs/aws_isolated_20261027/lontar_evidence_501_20261027_231951/kms_cloudtrail_later_window.json \
  --output outputs/aws_isolated_20261027/recovery_analysis
```

Hasil CSV, JSON dan input checksum ada di `recovery_analysis/`. Laporan verifikasi 11:41 WIB dan arsip sebelumnya tidak ditimpa: keduanya menggambarkan keadaan sebelum pengujian baru malam ini.

## Batas klaim dan pekerjaan berikutnya

Untuk artikel, bukti baru dapat mendukung **current staging recovery with fresh signed operational telemetry** dan latency warm/cold deskriptif. Tidak mendukung klaim human OIDC PKCE/nonce, TPM/TEE attestation, KMS Recipient, produksi, independensi site atau validasi biaya uang settled. Korelasi positif CloudTrail kini tersedia untuk seluruh operasi baru yang berhasil. Pekerjaan berikutnya adalah replikasi host–hari yang memadai dan rekonsiliasi hasil ini ke naskah dengan batas klaim yang sama; pengujian deny-propagation tetap harus dipisahkan dari recovery-only checkpoint ini. Jangan mengganti hasil follow-up gagal tanggal 22 Oktober dengan label berhasil berdasarkan checkpoint tanggal 27 Oktober.

## Cadangan S3

Kedua ZIP run berhasil diunggah tanpa perubahan akses bucket ke `s3://lontar-zt-access-key-policy-501250588559-ap-southeast-2-an/isolated/20261027/recovery/`, memakai SSE AES256. Keberhasilan perintah upload terlihat di CloudShell. Pemeriksaan ulang checksum object S3 belum dilakukan; verifikasi byte/checksum dalam laporan ini berlaku untuk salinan CloudShell-ke-laptop. Bucket tetap aktif. Capture audit lanjutan dan laporan final disimpan di laptop; jangan menganggap keduanya otomatis sudah dicadangkan ke S3.
