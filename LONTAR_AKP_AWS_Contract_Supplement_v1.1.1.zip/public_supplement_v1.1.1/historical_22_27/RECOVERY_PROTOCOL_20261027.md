# Recovery-only checkpoint, 27 October 2026

Target: project 501250588559, ap-southeast-2; existing isolated resources only.

New immutable output directory, with copied journal and journal hash. No IAM changes or new infrastructure. Confirm normal Lambda configuration and absence of temporary deny before starting the existing host. Acquire genuine Cognito M2M token in memory; obtain SSM operational telemetry and KMS signature from its existing authorized producer. Refresh evidence every 90 seconds; preserve each observation. Posture freshness remains 300 seconds and permit lifetime remains 60 seconds. Stop rather than overwrite an existing revocation.

Recovery requires three consecutive HTTP 200 responses with successful key-operation flags within a 120-second observation budget after readiness. Preserve all failures. Then collect 20 requests per arm in counterbalanced order and three cold candidates per arm via explicitly recorded environment-generation changes. Only matched Lambda REPORT Init Duration establishes a cold sample. Restore the exact original environment and stop the host, including on failure; save cleanup failures separately.

The run measures current recovery only. It does not estimate the elapsed recovery time since the 22 October fault or identify the cause of the earlier delay. No new deny injection is planned in this checkpoint. Latency quantiles are descriptive. New observations must retain actual day and host identity and remain separate from primary certification and older AWS clusters.

Software regression checks: four offline tests passed (freshness refresh/snapshots, outcome separation, key-success requirement, archive checksum). These tests do not establish AWS success. Source archive SHA256: 746ef7178fc269cb6632b15bbf5b2aefce879e4d06598a5d88da4a21b2794f10.

## Predeclared refinement for run02

Run01 retained 8 HTTP 429 responses among 50 requests. Run02 uses a distinct source archive and output directory, minimum one second between request starts, with scheduling wait excluded from network latency. API Gateway throttle and policy TTL are unchanged. Source SHA256: 419279811fb4fd5d4fef3fde9fe4f165ea975c0a9afa333b436dc2a158f01d39. Five local regression checks passed, including scheduling spacing. This is a design refinement after observing run01; do not present it as the original preregistered protocol or pool both protocols silently.
