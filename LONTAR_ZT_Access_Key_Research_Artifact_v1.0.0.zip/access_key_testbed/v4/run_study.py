import argparse,base64,concurrent.futures,contextlib,importlib.util,json,math,os,random,shutil,ssl,subprocess,sys,tempfile,threading,time,uuid
from pathlib import Path
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from common import *
from selector import select

HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('pki_helpers',HERE.parent/'v3/run_pilot.py');helpers=importlib.util.module_from_spec(spec);spec.loader.exec_module(helpers)
PROTOCOL=json.loads((HERE/'protocol.json').read_text())

def write(p,value):
 p=Path(p);tmp=p.with_suffix(p.suffix+'.tmp');tmp.write_text(json.dumps(value,indent=2));tmp.chmod(0o600);tmp.replace(p)

@contextlib.contextmanager
def lab(out,selected):
 processes=[];logs=[];kc=HERE.parent/'v2/vendor/keycloak';java=next((HERE.parent/'v2/vendor/java').glob('*/Contents/Home'))
 lockfile=kc/'lontar-pilot.lock';fd=os.open(lockfile,os.O_CREAT|os.O_EXCL|os.O_WRONLY,0o600);os.close(fd)
 realmfile=kc/'data/import/lontar-realm.json'
 def launch(command,name,env=None):
  f=open(out/f'{name}.log','w');logs.append(f);p=subprocess.Popen(command,stdout=f,stderr=subprocess.STDOUT,env=env);processes.append(p);return p
 with tempfile.TemporaryDirectory(prefix='lontar-v4-') as temp:
  root=Path(temp);cfg=helpers.pki(root);trials=root/'trials';trials.mkdir(mode=0o700);secret=uuid.uuid4().hex+uuid.uuid4().hex
  k=cfg['keycloak'];issuer=f"https://localhost:{k['port']}/realms/lontar"
  realm={'realm':'lontar','enabled':True,'sslRequired':'all','accessTokenLifespan':3600,'clientScopes':[{'name':'decrypt','protocol':'openid-connect','attributes':{'include.in.token.scope':'true'}}],'clients':[{'clientId':'workload-a','enabled':True,'protocol':'openid-connect','publicClient':False,'secret':secret,'serviceAccountsEnabled':True,'standardFlowEnabled':False,'directAccessGrantsEnabled':False,'defaultClientScopes':['decrypt'],'protocolMappers':[{'name':'gateway-audience','protocol':'openid-connect','protocolMapper':'oidc-audience-mapper','config':{'included.custom.audience':'lontar-gateway','id.token.claim':'false','access.token.claim':'true'}}]}]}
  try:
   write(realmfile,realm);env=os.environ.copy();env['JAVA_HOME']=str(java);env['JAVA_OPTS_APPEND']='-Xms128m -Xmx512m -XX:ActiveProcessorCount=2'
   kp=launch([str(kc/'bin/kc.sh'),'start','--cache=local','--db=dev-mem','--http-enabled=false',f"--https-port={k['port']}",f"--https-certificate-file={k['cert']}",f"--https-certificate-key-file={k['key']}",'--https-protocols=TLSv1.3','--http-host=127.0.0.1',f"--hostname=https://localhost:{k['port']}",'--import-realm'],'keycloak',env)
   tc=context(cfg['runner']);deadline=time.monotonic()+180
   while True:
    try:
     s,discovery=call(issuer+'/.well-known/openid-configuration',ctx=tc)
     if s==200:break
    except Exception:pass
    if kp.poll() is not None or time.monotonic()>deadline:raise RuntimeError('Keycloak startup failed')
    time.sleep(.3)
   s,t=call(discovery['token_endpoint'],{'grant_type':'client_credentials','client_id':'workload-a','client_secret':secret,'scope':'decrypt'},tc,True)
   if s!=200:raise RuntimeError('token acquisition failed')
   token=t['access_token'];subject=json.loads(b64(token.split('.')[1]))['sub']
   for role in ['collector','kms','gateway']:
    c=cfg[role];c.update(trials=str(trials),audit=str(out/f'{role}_audit.jsonl'),subject=subject,issuer=issuer,audience='lontar-gateway',client_id='workload-a',collector_public=str(root/'collector.pub'),pdp_public=str(root/'gateway.pub'),collector_url=f"https://localhost:{cfg['collector']['port']}/",kms_url=f"https://localhost:{cfg['kms']['port']}/",policies=PROTOCOL['policies'],selected_policy=selected)
    p=root/role/'config.json';write(p,c);child=launch([sys.executable,str(HERE/'service.py'),'--config',str(p)],role);deadline=time.monotonic()+20
    while not Path(c['ready']).exists():
     if child.poll() is not None or time.monotonic()>deadline:raise RuntimeError(role+' startup failed')
     time.sleep(.02)
   yield {'trials':trials,'url':f"https://localhost:{cfg['gateway']['port']}/",'ctx':context(cfg['runner'],True),'token':token,'pids':[p.pid for p in processes]}
  finally:
   for p in reversed(processes):
    if p.poll() is None:
     p.terminate()
     try:p.wait(timeout=15)
     except subprocess.TimeoutExpired:p.kill();p.wait(timeout=5)
   for f in logs:f.close()
   realmfile.unlink(missing_ok=True);lockfile.unlink(missing_ok=True)

def trial(lab,stage,block,policy,scenario,parameters,selected):
 trace=f'{stage}-{block}-{policy}-{scenario}';d=lab['trials']/trace;d.mkdir(mode=0o700)
 key=AESGCM.generate_key(256);nonce=os.urandom(12);plain=os.urandom(128)
 write(d/'store.json',{'key_b64':base64.b64encode(key).decode(),'nonce_b64':base64.b64encode(nonce).decode(),'ciphertext_b64':base64.b64encode(AESGCM(key).encrypt(nonce,plain,b'alpha')).decode()})
 mode='unavailable' if 'unavailable' in scenario else 'slow' if 'slow' in scenario else 'normal'
 use_delay=parameters['long_delay'] if 'delayed' in scenario else parameters['fast_delay']
 write(d/'spec.json',{'mode':mode,'use_delay':use_delay,'evidence_delay':parameters['evidence_delay']});write(d/'state.json',{'revoked':False})
 cancel=threading.Event();change={}
 def inject():
  deadline=time.monotonic()+20
  while not cancel.is_set() and time.monotonic()<deadline:
   try:issued=json.loads((d/'issued.json').read_text());break
   except (FileNotFoundError,json.JSONDecodeError):cancel.wait(.003)
  else:return
  if cancel.wait(parameters['transition']):return
  if scenario.startswith('posture'):(d/'store.json').chmod(0o644)
  if scenario.startswith('revoke'):write(d/'state.json',{'revoked':True})
  change.update(transition_wall_ns=time.time_ns(),transition_monotonic_ns=time.monotonic_ns(),issued_at=issued['issued_at'])
 worker=threading.Thread(target=inject);worker.start();start=time.perf_counter_ns()
 transport=False
 try:s,r=call(lab['url'],{'trace_id':trace,'access_token':lab['token'],'object':'alpha','policy':'selected' if stage=='test' and policy==selected else policy},lab['ctx'])
 except Exception as e:s,r=599,{'error':'client_transport_'+type(e).__name__};transport=True
 elapsed=(time.perf_counter_ns()-start)/1e6;cancel.set();worker.join()
 disclosed='plaintext_b64' in r;correct=disclosed and sha(base64.b64decode(r['plaintext_b64']))==sha(plain)
 adverse=not scenario.startswith('healthy');wait=r.get('gateway_wait_ms')
 return {'trace_id':trace,'stage':stage,'block':block,'policy':policy,'scenario':scenario,'adverse':adverse,'http_status':s,'reason':r.get('error'),'plaintext_disclosed':disclosed,'correct_plaintext':bool(correct),'security_loss':int(adverse and disclosed),'service_loss':int(not adverse and not (s==200 and correct)),'latency_ms':elapsed,'gateway_wait_ms':wait,'active_latency_ms':None if wait is None else elapsed-wait,'client_transport_error':transport,'use_delay_seconds':use_delay,**parameters,**change}

def summarize(rows):
 blocks=[]
 for block in sorted({r['block'] for r in rows}):
  for p in PROTOCOL['policies']:
   x=[r for r in rows if r['block']==block and r['policy']==p];h=[r for r in x if not r['adverse']]
   if len(x)!=7 or len(h)!=1:raise RuntimeError('incomplete_block')
   blocks.append({'block':block,'policy':p,'security_loss':int(any(r['security_loss'] for r in x)),'service_loss':h[0]['service_loss'],'healthy_scenario':h[0]['scenario'],'healthy_active_ms':h[0]['active_latency_ms']})
 return blocks

def stage_run(base,stage,n,seed,selected=None):
 out=base/stage;out.mkdir(exist_ok=False);rng=random.Random(seed);rows=[]
 with lab(out,selected) as instance,concurrent.futures.ThreadPoolExecutor(max_workers=42) as pool:
  write(out/'start.json',{'stage':stage,'blocks':n,'seed':seed,'selected_policy':selected,'pids':instance['pids'],'started_ns':time.time_ns()})
  for block in range(n):
   params={'long_delay':rng.uniform(*PROTOCOL['delay_long_uniform_seconds']),'fast_delay':rng.uniform(*PROTOCOL['delay_fast_uniform_seconds']),'transition':rng.uniform(*PROTOCOL['transition_uniform_seconds']),'evidence_delay':rng.uniform(*PROTOCOL['slow_evidence_uniform_seconds'])}
   distribution=PROTOCOL['healthy_distribution'];healthy=rng.choices(list(distribution),weights=list(distribution.values()))[0]
   jobs=[(p,s) for p in PROTOCOL['policies'] for s in PROTOCOL['adverse_scenarios']+[healthy]];rng.shuffle(jobs)
   futures=[pool.submit(trial,instance,stage,block,p,s,params,selected) for p,s in jobs]
   batch=[f.result() for f in futures];rows.extend(batch)
   with open(out/'results.jsonl','a') as f:
    for r in batch:f.write(json.dumps(r)+'\n')
   if block%10==0 or block==n-1:print(json.dumps({'stage':stage,'blocks_complete':block+1,'planned':n}),flush=True)
 # All child services finished; reconcile outcomes and transition order against KMS.
 events=[json.loads(x) for x in (out/'kms_audit.jsonl').read_text().splitlines()];bytrace={}
 for e in events:bytrace.setdefault(e['trace_id'],[]).append(e)
 for r in rows:
  ev=bytrace.get(r['trace_id'],[]);decrypt=[e for e in ev if e['event']=='decrypted'];received=[e for e in ev if e['event']=='received']
  if len(decrypt)!=int(r['plaintext_disclosed']):raise RuntimeError('client_KMS_disagreement')
  if not received or 'transition_monotonic_ns' not in r:raise RuntimeError('missing_transition_or_KMS_trace')
  if not r['transition_monotonic_ns']<received[0]['monotonic_ns']:raise RuntimeError('transition_not_before_use')
  if any(e['event']=='received' and (e['tls']!='TLSv1.3' or e['peer']!='gateway') for e in ev):raise RuntimeError('transport_binding')
  r['kms_decryptions']=len(decrypt);r['actual_age_seconds']=received[0]['wall_ns']/1e9-r['issued_at']
 blocks=summarize(rows);write(out/'blocks.json',blocks)
 write(out/'validation.json',{'requests':len(rows),'blocks':n,'client_KMS_agreement':True,'transitions_before_use':True,'client_transport_errors':sum(r['client_transport_error'] for r in rows),'completed_ns':time.time_ns()})
 return blocks,rows

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,required=True);ap.add_argument('--smoke',action='store_true');a=ap.parse_args();base=a.output.resolve();base.mkdir(parents=True,exist_ok=False)
 files=['protocol.json','SCOPE_FREEZE.md','common.py','selector.py','service.py','run_study.py']
 manifest={'frozen_ns':time.time_ns(),'source_hashes':{f:sha((HERE/f).read_bytes()) for f in files},'protocol':PROTOCOL,'old_pilot_rows_used':0,'smoke':a.smoke};write(base/'freeze.json',manifest)
 if a.smoke:stage_run(base,'smoke',2,40001);return
 tuning,trows=stage_run(base,'tuning',PROTOCOL['tuning_blocks'],PROTOCOL['seeds']['tuning'])
 import statistics
 costs={p:{'service_failures':sum(b['service_loss'] for b in tuning if b['policy']==p),'median_active_ms':statistics.median(r['active_latency_ms'] for r in trows if r['policy']==p and not r['adverse'] and r['active_latency_ms'] is not None)} for p in PROTOCOL['policies']}
 ranking=sorted(costs,key=lambda p:(costs[p]['service_failures'],costs[p]['median_active_ms'],p));write(base/'tuning_lock.json',{'costs':costs,'ranking':ranking,'locked_ns':time.time_ns()})
 certification,_=stage_run(base,'certification',PROTOCOL['certification_blocks'],PROTOCOL['seeds']['certification'])
 certificate=select(certification,PROTOCOL,ranking);certificate['locked_ns']=time.time_ns();write(base/'selection_lock.json',certificate)
 stage_run(base,'test',PROTOCOL['test_blocks'],PROTOCOL['seeds']['test'],certificate['selected_policy'])
 if any(sha((HERE/f).read_bytes())!=h for f,h in manifest['source_hashes'].items()):raise RuntimeError('frozen_source_changed')
 write(base/'complete.json',{'completed_ns':time.time_ns(),'selected_policy':certificate['selected_policy'],'source_hashes_unchanged':True})

if __name__=='__main__':main()
