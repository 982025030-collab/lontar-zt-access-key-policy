# Analysis before opening the final test

Primary certification is fixed in protocol.json. Report every candidate, including rejected candidates and a possible empty feasible set. Final testing does not change the selected policy or certify it again.

Final-test marginal uncertainty: two-sided 95% Clopper-Pearson intervals on binary block losses. These descriptive intervals are not simultaneous family guarantees. Latency: median, 95th percentile and paired difference to online_60_patient, using complete paired blocks. Bootstrap 2,000 draws, fixed seed 44001, percentile interval. Report degenerate bootstrap intervals alongside nonzero binomial upper limits; never interpret no observed failures as zero population risk. Include lag-1 descriptives and first/second-half rates to expose obvious temporal instability, without claiming that such checks prove IID.

Grouped sensitivity: divide the ordered test into ten contiguous batches of ten blocks, resample entire batches, and contrast the width of paired intervals. This is an exploratory dependence sensitivity; ten batches are not ten independent hosts or deployments.

Service mixture: report realized proportions for all four healthy scenarios, denial rates by scenario and overall. Experimental 50/35/10/5 percent weights are not production prevalence. Security scenarios are six challenges in every block, not natural traffic frequencies.

Cost sensitivity: using all tuning healthy active latencies, freeze the empirical 95th percentile as a normalization scale. Report measured binary security loss, binary service loss, normalized clipped active time, and thread CPU separately. Optional scores w_s*security + w_a*service + w_t*time use preference vectors (1,1,0), (10,1,0.1), (100,1,1). These are declared preferences, not calibrated monetary damages. This sensitivity never overrides the frozen primary selection.

Abnormal observations: preserve denials due to unavailable or overdue evidence as fail-closed outcomes. Report unexpected 503/599 separately. No deletion of slow requests, no packet-level replication of sample size. Verify disjoint trial IDs, source hashes, ordering of tuning lock, certification lock, and test start, and all KMS/client traces.
