import base64, json, hashlib, ssl, time, math, urllib.request, urllib.error, urllib.parse
from pathlib import Path
from cryptography.hazmat.primitives.asymmetric import rsa, padding, ed25519
from cryptography.hazmat.primitives import hashes,serialization

def canonical(x):return json.dumps(x,sort_keys=True,separators=(',',':')).encode()
def sha(x):return hashlib.sha256(x).hexdigest()
def b64(x):return base64.urlsafe_b64decode(x+'='*((-len(x))%4))
def context(cfg,client=False):
 c=ssl.create_default_context(cafile=cfg['ca']);c.minimum_version=c.maximum_version=ssl.TLSVersion.TLSv1_3
 if client:c.load_cert_chain(cfg['cert'],cfg['key'])
 return c

def call(url,payload=None,ctx=None,form=False):
 headers={};data=None
 if payload is not None:
  if form:
   data=urllib.parse.urlencode(payload).encode();headers['Content-Type']='application/x-www-form-urlencoded'
  else:data=canonical(payload);headers['Content-Type']='application/json'
 req=urllib.request.Request(url,data,headers)
 try:
  with urllib.request.urlopen(req,context=ctx,timeout=10) as r:return r.status,json.loads(r.read())
 except urllib.error.HTTPError as e:
  raw=e.read()
  try:body=json.loads(raw)
  except Exception:body={'error':'non_json_response'}
  return e.code,body

class Identity:
 def __init__(self,cfg):
  self.cfg=cfg;self.ctx=context(cfg);self.refresh()
 def refresh(self):
  s,d=call(self.cfg['issuer']+'/.well-known/openid-configuration',ctx=self.ctx)
  if s!=200 or d.get('issuer')!=self.cfg['issuer']:raise ValueError('discovery_issuer')
  # Local trust boundary fixed by operator, not supplied by a token header.
  if not d['jwks_uri'].startswith(self.cfg['issuer']+'/'):raise ValueError('jwks_origin')
  s,j=call(d['jwks_uri'],ctx=self.ctx)
  if s!=200:raise ValueError('jwks_unavailable')
  self.keys={k['kid']:k for k in j['keys'] if k.get('kty')=='RSA' and k.get('use')=='sig' and k.get('alg')=='RS256'}
 def verify(self,token):
  try:
   a,b,s=token.split('.');head=json.loads(b64(a));c=json.loads(b64(b))
   if head.get('alg')!='RS256':raise ValueError()
   if head.get('kid') not in self.keys:self.refresh()
   k=self.keys[head['kid']];key=rsa.RSAPublicNumbers(int.from_bytes(b64(k['e']),'big'),int.from_bytes(b64(k['n']),'big')).public_key()
   key.verify(b64(s),(a+'.'+b).encode(),padding.PKCS1v15(),hashes.SHA256())
   now=time.time()
   for name in ['exp','iat']:
    if type(c[name]) not in [int,float] or not math.isfinite(c[name]):raise ValueError()
   nbf=c.get('nbf',0)
   if type(nbf) not in [int,float] or not math.isfinite(nbf):raise ValueError()
   if not nbf<=now<c['exp'] or c['iat']>now:raise ValueError()
   aud=c['aud'];aud=[aud] if isinstance(aud,str) else aud
   if c['iss']!=self.cfg['issuer'] or self.cfg['audience'] not in aud or c.get('azp')!=self.cfg['client_id'] or c.get('sub')!=self.cfg['subject']:raise ValueError()
   if 'decrypt' not in c.get('scope','').split():raise ValueError()
   return c
  except Exception:raise ValueError('invalid_access_token') from None

def signed(key,c):return {'claims':c,'sig':base64.b64encode(key.sign(canonical(c))).decode()}
def checked(key,e,issuer,audience):
 try:
  c=e['claims'];key.verify(base64.b64decode(e['sig'],validate=True),canonical(c));now=time.time()
  if c['iss']!=issuer or c['aud']!=audience or not c['iat']<=now<c['exp']:raise ValueError()
  return c
 except Exception:raise ValueError('invalid_signed_evidence') from None

def private(path):return serialization.load_pem_private_key(Path(path).read_bytes(),password=None)
def public(path):return serialization.load_pem_public_key(Path(path).read_bytes())
