import unittest,math
from selector import upper,select

class ScreeningTests(unittest.TestCase):
 def test_zero_failure_formula(self):self.assertAlmostEqual(upper(0,107,.05/12),1-(.05/12)**(1/107))
 def test_planned_size(self):self.assertEqual(math.ceil(math.log(.05/12)/math.log(.95)),107)
 def test_empty_is_not_zero(self):self.assertIsNone(upper(0,0,.05))
 def test_all_fail(self):self.assertEqual(upper(7,7,.05),1)
 def test_selection_does_not_rescue_unsafe_low_cost(self):
  p={'policies':{'unsafe':{},'safe':{}},'family_alpha':.05,'certification_blocks':107,'security_limit':.05,'service_limit':.2}
  rows=[{'policy':name,'block':i,'security_loss':int(name=='unsafe'),'service_loss':0} for name in p['policies'] for i in range(107)]
  self.assertEqual(select(rows,p,['unsafe','safe'])['selected_policy'],'safe')
  p['service_limit']=0;self.assertIsNone(select(rows,p,['unsafe','safe'])['selected_policy'])
 def test_duplicate_rejected(self):
  p={'policies':{'p':{}},'family_alpha':.05,'certification_blocks':2,'security_limit':.05,'service_limit':.2}
  with self.assertRaises(ValueError):select([{'block':0,'policy':'p','security_loss':0,'service_loss':0}]*2,p,['p'])

if __name__=='__main__':unittest.main()
