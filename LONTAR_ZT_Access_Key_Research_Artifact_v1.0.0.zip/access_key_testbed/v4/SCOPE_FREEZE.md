# LONTAR-ZT access-key study: scope freeze

The scientific object is a complete authorization policy: evidence verification, a bound key-use permit, its lifetime, and the rule at use. The contribution combines a verifiable enforcement contract with explicit refusal to certify an inadequately supported policy. Exact binomial bounds and multiple-comparison correction are established methods, not new mathematical results.

RQ1: Which frozen policies meet the two prespecified risk limits under the experimental generator?
RQ2: How do lifetime and fail-closed online-check deadlines change post-transition disclosure and legitimate service denial?
RQ3: Does tuning-ranked, risk-screened selection remain feasible on untouched test episodes, and at what measured time/CPU cost relative to fixed candidates?

The original pilot results motivated this design but contribute zero observations to tuning, certification or testing. Security loss is a block-level union of six adverse outcomes; the separate service loss is one draw from a declared legitimate workload mixture. The 5% security and 20% service limits are laboratory design targets, not customer requirements. In particular the healthy workload mixture is experimental, not measured production prevalence.

Costs are recorded in physical units and as actual failure counts. No financial damage coefficients will be fabricated. The primary feasible-policy ranking is lexicographic service failure, active latency, policy ID. A weighted security-service loss is a sensitivity analysis with explicitly assumed preferences.

Stopping rule: fixed 16 tuning, 107 certification, 100 test blocks. No post-result increases to obtain significance. Each block uses fresh object keys and state. Policies share the same sampled workload parameters within a block. All temporal changes use real waiting and recorded clocks. The certificate assumes independent identically distributed blocks conditional on the fixed host and generator; a single-host study cannot establish that assumption for deployments.

The study can conclude no feasible policy, equivalence to a strong baseline, or lack of incremental benefit. None is repaired by changing risk limits after inspecting results. Human authors must verify authorship, funding, competing interests and final publication declarations before submission.
