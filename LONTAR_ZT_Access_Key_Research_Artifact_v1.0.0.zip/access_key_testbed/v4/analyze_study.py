import argparse,collections,csv,hashlib,json,math,random,statistics,sys
from pathlib import Path
from selector import upper

def quantile(x,p):
 x=sorted(x);i=(len(x)-1)*p;j=int(i);return x[j]+(x[min(j+1,len(x)-1)]-x[j])*(i-j)
def interval(k,n):return [0.0 if k==0 else 1-upper(n-k,n,.025),upper(k,n,.025)]
def bootstrap(d,batch=False):
 rng=random.Random(44001);groups=[d[i:i+10] for i in range(0,len(d),10)] if batch else [[x] for x in d];samples=[]
 for _ in range(2000):
  x=[v for i in rng.choices(range(len(groups)),k=len(groups)) for v in groups[i]];samples.append(statistics.mean(x))
 return [quantile(samples,.025),quantile(samples,.975)]
def csvwrite(path,rows):
 with open(path,'w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def main():
 ap=argparse.ArgumentParser();ap.add_argument('study',type=Path);ap.add_argument('--output',type=Path,required=True);a=ap.parse_args();out=a.output;out.mkdir(parents=True,exist_ok=True)
 study=a.study;freeze=json.loads((study/'freeze.json').read_text());p=freeze['protocol'];complete=json.loads((study/'complete.json').read_text());selection=json.loads((study/'selection_lock.json').read_text());tlock=json.loads((study/'tuning_lock.json').read_text())
 assert tlock['locked_ns']<json.loads((study/'certification/start.json').read_text())['started_ns']
 assert selection['locked_ns']<json.loads((study/'test/start.json').read_text())['started_ns']
 rows={s:[json.loads(x) for x in (study/s/'results.jsonl').read_text().splitlines()] for s in ['tuning','certification','test']};blocks={s:json.loads((study/s/'blocks.json').read_text()) for s in rows}
 ids=[{r['trace_id'] for r in rows[s]} for s in rows];assert not (ids[0]&ids[1] or ids[0]&ids[2] or ids[1]&ids[2]);assert freeze['old_pilot_rows_used']==0
 # Verify all archived source hashes still identify the actual execution code.
 here=Path(__file__).resolve().parent
 assert all(hashlib.sha256((here/f).read_bytes()).hexdigest()==h for f,h in freeze['source_hashes'].items())
 cpu=collections.defaultdict(float)
 for role in ['gateway','collector','kms']:
  for line in (study/'test'/f'{role}_audit.jsonl').read_text().splitlines():
   e=json.loads(line)
   if e['event']=='response':cpu[e['trace_id']]+=e['thread_cpu_ms']
 summary=[];scenario_summary=[];paired=[];sensitivity=[]
 norm=quantile([r['active_latency_ms'] for r in rows['tuning'] if not r['adverse'] and r['active_latency_ms'] is not None],.95)
 reference='online_60_patient';ref={b['block']:b for b in blocks['test'] if b['policy']==reference}
 for policy in p['policies']:
  b=sorted([x for x in blocks['test'] if x['policy']==policy],key=lambda x:x['block']);n=len(b);sec=sum(x['security_loss'] for x in b);svc=sum(x['service_loss'] for x in b)
  healthy=[r for r in rows['test'] if r['policy']==policy and not r['adverse']];lat=[r['active_latency_ms'] for r in healthy if r['active_latency_ms'] is not None]
  entry={'policy':policy,'n_blocks':n,'security_failures':sec,'security_rate':sec/n,'security_ci_low':interval(sec,n)[0],'security_ci_high':interval(sec,n)[1],'service_failures':svc,'service_rate':svc/n,'service_ci_low':interval(svc,n)[0],'service_ci_high':interval(svc,n)[1],'active_p50_ms':statistics.median(lat),'active_p95_ms':quantile(lat,.95),'total_p50_ms':statistics.median(r['latency_ms'] for r in healthy),'thread_cpu_p50_ms':statistics.median(cpu[r['trace_id']] for r in healthy),'selected':policy==selection['selected_policy']};summary.append(entry)
  for metric in ['security_loss','service_loss','healthy_active_ms']:
   d=[x[metric]-ref[x['block']][metric] for x in b if x[metric] is not None and ref[x['block']][metric] is not None]
   ci=bootstrap(d);batchci=bootstrap(d,True);paired.append({'policy':policy,'reference':reference,'metric':metric,'paired_blocks':len(d),'mean_difference':statistics.mean(d),'bootstrap_low':ci[0],'bootstrap_high':ci[1],'batch_bootstrap_low':batchci[0],'batch_bootstrap_high':batchci[1]})
  for scenario in sorted({r['scenario'] for r in rows['test']}):
   x=[r for r in rows['test'] if r['policy']==policy and r['scenario']==scenario]
   scenario_summary.append({'policy':policy,'scenario':scenario,'n':len(x),'disclosures':sum(r['plaintext_disclosed'] for r in x),'denials':sum(not r['plaintext_disclosed'] for r in x),'median_active_ms':statistics.median(r['active_latency_ms'] for r in x if r['active_latency_ms'] is not None)})
  for ws,wa,wt in [(1,1,0),(10,1,.1),(100,1,1)]:sensitivity.append({'policy':policy,'w_security':ws,'w_service':wa,'w_time':wt,'score':ws*sec/n+wa*svc/n+wt*statistics.mean(min(1,x/norm) for x in lat),'tuning_time_scale_ms':norm,'status':'posthoc preference sensitivity, not selection'})
 healthy_counts=collections.Counter(b['healthy_scenario'] for b in blocks['test'] if b['policy']==reference)
 stability=[]
 for policy in p['policies']:
  b=sorted([x for x in blocks['test'] if x['policy']==policy],key=lambda x:x['block'])
  for metric in ['security_loss','service_loss']:
   x=[z[metric] for z in b];mean=statistics.mean(x);den=sum((v-mean)**2 for v in x)
   stability.append({'policy':policy,'metric':metric,'first_half':statistics.mean(x[:50]),'second_half':statistics.mean(x[50:]),'lag1_descriptive':None if not den else sum((x[i]-mean)*(x[i-1]-mean) for i in range(1,len(x)))/den})
 csvwrite(out/'test_policy_summary.csv',summary);csvwrite(out/'test_scenarios.csv',scenario_summary);csvwrite(out/'paired_block_intervals.csv',paired);csvwrite(out/'cost_sensitivity.csv',sensitivity);csvwrite(out/'temporal_sensitivity.csv',stability)
 certificate_rows=[]
 for policy,v in selection['bounds'].items():certificate_rows.append({'policy':policy,'security_failures':v['security_loss']['failures'],'security_upper':v['security_loss']['upper'],'service_failures':v['service_loss']['failures'],'service_upper':v['service_loss']['upper'],'eligible':policy in selection['eligible']})
 csvwrite(out/'certification_summary.csv',certificate_rows)
 result={'selected_policy':selection['selected_policy'],'status':selection['status'],'counts':{s:len(x) for s,x in rows.items()},'block_counts':{s:len(x)//len(p['policies']) for s,x in blocks.items()},'healthy_test_prevalence':dict(healthy_counts),'policies':summary,'certification':certificate_rows,'protocol_hash':freeze['source_hashes']['protocol.json'],'time_normalization_ms':norm,'verification':{'splits_disjoint':True,'pilot_excluded':True,'selection_locked_before_test':True,'sources_unchanged':True},'limitations':['single host, stage services shared across reset blocks','certificate conditional on IID and fixed generator','no multi-host generalization','laboratory prevalence, not production mix','baseline policies not reproductions of prior complete systems']}
 (out/'summary.json').write_text(json.dumps(result,indent=2))
 # Compact tables consumed directly by the LaTeX manuscript.
 labels={'offline_2':'O2','offline_60':'O60','online_2_fast':'F2','online_60_fast':'F60','online_2_patient':'P2','online_60_patient':'P60'}
 lines=[]
 for i,r in enumerate(certificate_rows):
  ending=' \\\\' if i<len(certificate_rows)-1 else ''
  lines.append(f"{labels[r['policy']]} & {r['security_failures']}/107 & {r['security_upper']:.3f} & {r['service_failures']}/107 & {r['service_upper']:.3f} & {'Yes' if r['eligible'] else 'No'}"+ending)
 (out/'certification_rows.tex').write_text('\n'.join(lines)+'\n')
 lines=[]
 for i,r in enumerate(summary):
  ending=' \\\\' if i<len(summary)-1 else ''
  lines.append(f"{labels[r['policy']]} & {r['security_failures']}/100 & {r['security_ci_high']:.3f} & {r['service_failures']}/100 & [{r['service_ci_low']:.3f}, {r['service_ci_high']:.3f}] & {r['active_p50_ms']:.1f} & {r['active_p95_ms']:.1f}"+ending)
 (out/'test_rows.tex').write_text('\n'.join(lines)+'\n')
 selected=next((r for r in summary if r['selected']),None)
 (out/'result_macros.tex').write_text('\\newcommand{\\SelectedPolicy}{'+(labels[selection['selected_policy']] if selected else 'none')+'}\n'+('\\newcommand{\\SelectedSecurity}{'+str(selected['security_failures'])+'}\n\\newcommand{\\SelectedService}{'+str(selected['service_failures'])+'}\n' if selected else ''))
 print(json.dumps(result,indent=2))

if __name__=='__main__':main()
