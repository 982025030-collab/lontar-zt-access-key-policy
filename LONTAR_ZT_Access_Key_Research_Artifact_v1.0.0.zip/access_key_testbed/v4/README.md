# LONTAR-ZT v4: frozen access-key policy experiment

This is a local research testbed, not a production access gateway. The protocol and scope were written before the main data collection. Earlier v1/v2/v3 pilots are not calibration or test data.

## Reproduce

Use Python 3.12 with `cryptography==50.0.1`. Exact binomial limits and bootstrap inference use the Python standard library. The tested platform is macOS ARM64. Portable Keycloak 26.7.3 and Temurin Java 21 are placed under `access_key_testbed/v2/vendor` by the included v2 preparation script and pinned vendor manifest. See that script's help and the v2 README for downloads; binaries are not included in this archive.

From the reproduction-package root:

```sh
python3 -m pip install -r access_key_testbed/v4/requirements.txt
python3 access_key_testbed/v4/test_selector.py
python3 access_key_testbed/v4/run_study.py --output access_key_testbed/v4/results/my_smoke --smoke
python3 access_key_testbed/v4/run_study.py --output access_key_testbed/v4/results/my_study
python3 access_key_testbed/v4/analyze_study.py access_key_testbed/v4/results/my_study --output my_analysis
```

Run directories must not already exist. The runner acquires an exclusive lock on its dedicated Keycloak distribution, opens loopback-only TLS ports, creates a temporary CA and client certificates, and deletes private runtime state on exit. All services are stopped and waited for in a finally block. No external target is contacted during data collection. Keycloak must be installed before collection.

The v3 helper supplies PKI generation only. No v3 observations are imported. The package preserves this helper dependency. A study takes several minutes and writes progress once every ten blocks. Do not change protocol or execution files while a frozen run is active.

## Interpretation

Each stage initializes fresh Keycloak and three Python service processes. Each trial has new object cryptographic material and isolated posture/entitlement state. The fixed host and persistent stage services are shared between blocks. This is conditional replication of a controlled generator, not independent hosts or sites. The certificate assumes IID blocks, explicitly limits its population, and is not a deployment guarantee.

The six candidates vary TTL and live-evidence deadlines. `selected` is a gateway configuration alias resolved only from the pre-test selection lock. Test comparisons execute all candidates, but do not change the selected alias. If certification yields no feasible policy, no selected alias is deployed; test results for fixed candidates may still be collected and reported.

Unavailable or overdue evidence denies key use for online candidates. An injected healthy outage is counted as service loss, not hidden as a passed request. Intentional gateway waiting is recorded separately from active latency. Thread CPU measures Python handler work, not total machine energy or all TLS handshake CPU. A response deadline is a bounded client-call condition, not a hard real-time scheduler guarantee.

`analyze_study.py` checks split disjointness, lock ordering, unchanged source hashes, and old-pilot exclusion. The runner separately reconciles every KMS decryption with the client outcome and checks transition ordering. Analysis outputs include exact certification bounds, test intervals, paired and contiguous-batch bootstrap intervals, observed scenario prevalence, and preference-weight sensitivity.

## Remaining research limitations

No production risk target, financial harm calibration, cross-host generalization, transactional revocation, complete RAdAC implementation comparison, or identity-provider logout/revocation experiment is claimed. Initial and live evidence use local storage mode and resource entitlement. The broader dissertation's detector, hysteresis, rollback, drift governance and online adaptation are not implemented by this experiment.
