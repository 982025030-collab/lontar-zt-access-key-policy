"""Service-separated, loopback-only research testbed. No production deployment."""
import argparse,base64,json,os,ssl,time,threading,stat,socket,urllib.request,urllib.error
from pathlib import Path
from http.server import ThreadingHTTPServer,BaseHTTPRequestHandler
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from common import *

ap=argparse.ArgumentParser();ap.add_argument('--config',required=True);a=ap.parse_args()
cfg=json.loads(Path(a.config).read_text());role=cfg['role'];root=Path(cfg['trials']);lock=threading.Lock();used=set()
ctx=context(cfg,True);identity=Identity(cfg) if role=='gateway' else None
signer=private(cfg['signing_private']) if role in ['gateway','collector'] else None
collector_key=public(cfg['collector_public']) if role in ['gateway','kms'] else None
grant_key=public(cfg['pdp_public']) if role=='kms' else None

def log(trace,event,**kw):
 with lock:
  with open(cfg['audit'],'a') as f:f.write(json.dumps(dict(trace_id=trace,service=role,pid=os.getpid(),event=event,wall_ns=time.time_ns(),monotonic_ns=time.monotonic_ns(),**kw))+'\n')

def rpc(url,payload,timeout=10):
 req=urllib.request.Request(url,canonical(payload),{'Content-Type':'application/json'})
 try:
  with urllib.request.urlopen(req,context=ctx,timeout=timeout) as r:return r.status,json.loads(r.read())
 except urllib.error.HTTPError as e:return e.code,json.loads(e.read())

def route(b,peer):
 trace=b['trace_id']
 if not isinstance(trace,str) or not trace.replace('-','').replace('_','').isalnum():raise ValueError('trace_format')
 d=root/trace
 if not d.is_dir():raise ValueError('unknown_trial')
 spec=json.loads((d/'spec.json').read_text())
 if role=='collector':
  phase=b['phase'];aud='gateway' if phase=='issue' else 'kms'
  if peer!=aud:raise ValueError('collector_peer')
  if phase!='issue':
   if spec['mode']=='unavailable':return 503,{'error':'injected_evidence_unavailable'}
   if spec['mode']=='slow':time.sleep(spec['evidence_delay'])
  measured=time.time();state=json.loads((d/'state.json').read_text())
  mode=stat.S_IMODE((d/'store.json').stat().st_mode)
  claim={'iss':'collector','aud':aud,'iat':measured,'exp':measured+120,'trace_id':trace,'nonce':b['nonce'],'sub':cfg['subject'],'object':'alpha','healthy':mode==0o600,'entitled':not state['revoked'],'mode':mode}
  log(trace,'evidence',phase=phase,healthy=claim['healthy'],entitled=claim['entitled'],nonce=b['nonce'])
  return 200,signed(signer,claim)
 if role=='gateway':
  if peer!='runner':raise ValueError('gateway_peer')
  c=identity.verify(b['access_token']);pid=b['policy']
  if pid=='selected':pid=cfg.get('selected_policy')
  if pid not in cfg['policies']:raise ValueError('unknown_policy')
  policy=cfg['policies'][pid]
  if b.get('object')!='alpha':raise ValueError('object_denied')
  s,e=rpc(cfg['collector_url'],{'trace_id':trace,'phase':'issue','nonce':trace+'issue'})
  if s!=200:raise ValueError('issue_evidence_unavailable')
  e=checked(collector_key,e,'collector','gateway')
  if e['trace_id']!=trace or e['nonce']!=trace+'issue' or e['sub']!=c['sub'] or e['object']!='alpha':raise ValueError('evidence_binding')
  if not e['healthy'] or not e['entitled']:raise ValueError('issue_evidence_negative')
  now=time.time();g={'iss':'pdp','aud':'kms','iat':now,'exp':min(now+policy['ttl'],e['exp'],c['exp']),'sub':c['sub'],'object':'alpha','operation':'decrypt','jti':trace,'trace_id':trace,'policy':pid,'online':policy['online'],'deadline':policy['deadline']}
  envelope=signed(signer,g);log(trace,'permit',policy=pid,issued_at=now,expires_at=g['exp'])
  (d/'issued.json').write_text(json.dumps({'issued_at':now,'monotonic_ns':time.monotonic_ns()}))
  t=time.perf_counter_ns();time.sleep(spec['use_delay']);wait_ns=time.perf_counter_ns()-t
  s,r=rpc(cfg['kms_url'],{'trace_id':trace,'grant':envelope,'object':'alpha'})
  r['gateway_wait_ms']=wait_ns/1e6
  return s,r
 if role=='kms':
  if peer!='gateway':raise ValueError('kms_peer')
  g=checked(grant_key,b['grant'],'pdp','kms')
  if g['trace_id']!=trace or g['jti']!=trace or g['sub']!=cfg['subject'] or g['object']!=b['object'] or g['operation']!='decrypt':raise ValueError('grant_binding')
  if g['policy'] not in cfg['policies']:raise ValueError('unknown_policy')
  p=cfg['policies'][g['policy']]
  if g['online']!=p['online'] or g['deadline']!=p['deadline'] or g['exp']-g['iat']>p['ttl']+1e-6:raise ValueError('policy_binding')
  with lock:
   if trace in used:raise ValueError('grant_replay')
   used.add(trace)
  if g['online']:
   start=time.monotonic()
   try:s,e=rpc(cfg['collector_url'],{'trace_id':trace,'phase':'use','nonce':trace+'use'},g['deadline'])
   except Exception:raise ValueError('evidence_unavailable_or_timeout') from None
   elapsed=time.monotonic()-start
   if elapsed>g['deadline'] or s!=200:raise ValueError('evidence_unavailable_or_timeout')
   e=checked(collector_key,e,'collector','kms')
   if e['trace_id']!=trace or e['nonce']!=trace+'use' or e['sub']!=g['sub'] or e['object']!=g['object']:raise ValueError('live_evidence_binding')
   if not e['healthy'] or not e['entitled']:raise ValueError('live_evidence_negative')
   log(trace,'live_verified',evidence_latency_ms=elapsed*1000)
  # A permit valid before an online check may expire while waiting for evidence.
  checked(grant_key,b['grant'],'pdp','kms')
  store=json.loads((d/'store.json').read_text());plain=AESGCM(base64.b64decode(store['key_b64'])).decrypt(base64.b64decode(store['nonce_b64']),base64.b64decode(store['ciphertext_b64']),b'alpha')
  log(trace,'decrypted',plaintext_sha256=sha(plain),grant_age_seconds=time.time()-g['iat'])
  return 200,{'plaintext_b64':base64.b64encode(plain).decode()}
 raise ValueError('role')

class Handler(BaseHTTPRequestHandler):
 def log_message(self,*args):pass
 def do_POST(self):
  trace='unparsed';start=time.perf_counter_ns();cpu=time.thread_time_ns()
  try:
   n=int(self.headers.get('Content-Length',0))
   if not 0<n<65536:raise ValueError('body_size')
   b=json.loads(self.rfile.read(n));trace=b['trace_id'];peer=None
   for group in self.connection.getpeercert().get('subject',()):
    for key,value in group:
     if key=='commonName':peer=value
   log(trace,'received',peer=peer,tls=self.connection.version());s,r=route(b,peer)
  except (ValueError,KeyError,TypeError) as e:s,r=403,{'error':str(e)}
  except Exception as e:s,r=503,{'error':'unexpected_service_error'};log(trace,'exception',type=type(e).__name__)
  log(trace,'response',status=s,elapsed_ms=(time.perf_counter_ns()-start)/1e6,thread_cpu_ms=(time.thread_time_ns()-cpu)/1e6)
  raw=canonical(r)
  try:self.send_response(s);self.send_header('Content-Length',str(len(raw)));self.end_headers();self.wfile.write(raw)
  except (BrokenPipeError,ConnectionResetError,ssl.SSLError):log(trace,'client_deadline_closed_connection')

class Server(ThreadingHTTPServer):request_queue_size=128;daemon_threads=True
server=Server(('127.0.0.1',cfg['port']),Handler)
tls=ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER);tls.minimum_version=tls.maximum_version=ssl.TLSVersion.TLSv1_3
tls.load_cert_chain(cfg['cert'],cfg['key']);tls.load_verify_locations(cfg['ca']);tls.verify_mode=ssl.CERT_REQUIRED
server.socket=tls.wrap_socket(server.socket,server_side=True)
Path(cfg['ready']).write_text(json.dumps({'role':role,'pid':os.getpid()}));server.serve_forever(.05)
