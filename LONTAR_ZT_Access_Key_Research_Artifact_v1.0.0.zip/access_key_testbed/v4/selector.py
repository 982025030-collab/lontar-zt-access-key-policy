"""Exact binomial finite-family screening; existing statistics, not a new bound."""
import math

def upper(k,n,alpha):
 if n<=0:return None
 if not 0<=k<=n or not 0<alpha<1:raise ValueError('invalid_binomial_arguments')
 if k==n:return 1.0
 # Invert P_p[X <= k] = alpha. Log-sum-exp avoids underflow in the tails.
 def cdf(p):
  terms=[math.lgamma(n+1)-math.lgamma(j+1)-math.lgamma(n-j+1)+j*math.log(p)+(n-j)*math.log1p(-p) for j in range(k+1)]
  m=max(terms);return math.exp(m)*sum(math.exp(t-m) for t in terms)
 lo,hi=0.0,1.0
 for _ in range(60):
  mid=(lo+hi)/2
  if cdf(mid)>alpha:lo=mid
  else:hi=mid
 return (lo+hi)/2

def select(blocks,protocol,ranking):
 policies=protocol['policies'];alpha=protocol['family_alpha']/(len(policies)*2)
 bounds={};eligible=[]
 for p in policies:
  x=[b for b in blocks if b['policy']==p]
  if len(x)!=protocol['certification_blocks']:raise ValueError('incomplete_certification_blocks')
  if len({b['block'] for b in x})!=len(x):raise ValueError('duplicate_blocks')
  bounds[p]={metric:{'failures':sum(b[metric] for b in x),'n':len(x),'upper':upper(sum(b[metric] for b in x),len(x),alpha)} for metric in ['security_loss','service_loss']}
  if bounds[p]['security_loss']['upper']<=protocol['security_limit'] and bounds[p]['service_loss']['upper']<=protocol['service_limit']:eligible.append(p)
 chosen=next((p for p in ranking if p in eligible),None)
 return {'selected_policy':chosen,'eligible':eligible,'bounds':bounds,'per_comparison_alpha':alpha,'status':'conditionally_certified' if chosen else 'no_feasible_policy','assumptions':'IID reset blocks conditional on fixed laboratory generator and host; no deployment guarantee'}
