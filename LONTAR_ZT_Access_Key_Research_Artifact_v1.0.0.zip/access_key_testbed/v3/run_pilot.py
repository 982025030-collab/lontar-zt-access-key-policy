import threading
import argparse,base64,json,os,random,shutil,socket,ssl,subprocess,sys,tempfile,time,uuid
from datetime import datetime,timedelta,timezone
from pathlib import Path
from cryptography import x509
from cryptography.x509.oid import NameOID,ExtendedKeyUsageOID
from cryptography.hazmat.primitives import hashes,serialization
from cryptography.hazmat.primitives.asymmetric import rsa,ed25519
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from common import *
HERE=Path(__file__).resolve().parent

def write(p,v):p.write_text(json.dumps(v,indent=2));p.chmod(0o600)
def port():
 with socket.socket() as s:s.bind(('127.0.0.1',0));return s.getsockname()[1]
def pki(root):
 key=rsa.generate_private_key(public_exponent=65537,key_size=2048);now=datetime.now(timezone.utc);name=x509.Name([x509.NameAttribute(NameOID.COMMON_NAME,'LONTAR v2 local CA')])
 ca=x509.CertificateBuilder().subject_name(name).issuer_name(name).public_key(key.public_key()).serial_number(x509.random_serial_number()).not_valid_before(now-timedelta(minutes=1)).not_valid_after(now+timedelta(days=1)).add_extension(x509.BasicConstraints(ca=True,path_length=0),True).sign(key,hashes.SHA256())
 cap=root/'ca.pem';cap.write_bytes(ca.public_bytes(serialization.Encoding.PEM));configs={}
 for role in ['keycloak','collector','gateway','kms','runner']:
  d=root/role;d.mkdir(mode=0o700);k=rsa.generate_private_key(public_exponent=65537,key_size=2048)
  cert=x509.CertificateBuilder().subject_name(x509.Name([x509.NameAttribute(NameOID.COMMON_NAME,role)])).issuer_name(name).public_key(k.public_key()).serial_number(x509.random_serial_number()).not_valid_before(now-timedelta(minutes=1)).not_valid_after(now+timedelta(days=1)).add_extension(x509.BasicConstraints(ca=False,path_length=None),True).add_extension(x509.SubjectAlternativeName([x509.DNSName('localhost')]),False).add_extension(x509.ExtendedKeyUsage([ExtendedKeyUsageOID.SERVER_AUTH,ExtendedKeyUsageOID.CLIENT_AUTH]),False).sign(key,hashes.SHA256())
  (d/'tls.pem').write_bytes(cert.public_bytes(serialization.Encoding.PEM));(d/'tls.key').write_bytes(k.private_bytes(serialization.Encoding.PEM,serialization.PrivateFormat.PKCS8,serialization.NoEncryption()));(d/'tls.key').chmod(0o600)
  configs[role]={'role':role,'ca':str(cap),'cert':str(d/'tls.pem'),'key':str(d/'tls.key'),'port':port(),'ready':str(d/'ready.json')}
 for role in ['collector','gateway']:
  k=ed25519.Ed25519PrivateKey.generate();d=root/role
  (d/'sign.key').write_bytes(k.private_bytes(serialization.Encoding.PEM,serialization.PrivateFormat.PKCS8,serialization.NoEncryption()));(d/'sign.key').chmod(0o600)
  (root/f'{role}.pub').write_bytes(k.public_key().public_bytes(serialization.Encoding.PEM,serialization.PublicFormat.SubjectPublicKeyInfo));configs[role]['signing_private']=str(d/'sign.key')
 return configs

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,required=True);ap.add_argument('--blocks',type=int,default=10);ap.add_argument('--seed',type=int,default=20260910);a=ap.parse_args()
 if a.blocks<1:ap.error('blocks must be positive')
 a.output=a.output.resolve();a.output.mkdir(parents=True,exist_ok=False)
 kc=HERE.parent/'v2/vendor/keycloak';java=list((HERE.parent/'v2/vendor/java').glob('*/Contents/Home'))
 if not java or not (kc/'bin/kc.sh').exists():raise RuntimeError('Portable Keycloak/Java missing; see README')
 processes=[];logs=[];rows=[];manifest={'seed':a.seed,'blocks':a.blocks,'source_hashes':{p.name:sha(p.read_bytes()) for p in [HERE/'run_pilot.py',HERE/'service.py',HERE/'common.py',HERE/'protocol_v3.json']},'services':[]}
 rng=random.Random(a.seed)
 with tempfile.TemporaryDirectory(prefix='lontar-v2-') as temp:
  root=Path(temp);cfg=pki(root);kcc=cfg['keycloak'];issuer=f"https://localhost:{kcc['port']}/realms/lontar";secret=uuid.uuid4().hex+uuid.uuid4().hex
  realm={'realm':'lontar','enabled':True,'sslRequired':'all','accessTokenLifespan':300,'clientScopes':[{'name':'decrypt','protocol':'openid-connect','attributes':{'include.in.token.scope':'true'}}],'clients':[{'clientId':'workload-a','enabled':True,'protocol':'openid-connect','publicClient':False,'secret':secret,'serviceAccountsEnabled':True,'standardFlowEnabled':False,'directAccessGrantsEnabled':False,'defaultClientScopes':['decrypt'],'protocolMappers':[{'name':'gateway-audience','protocol':'openid-connect','protocolMapper':'oidc-audience-mapper','config':{'included.custom.audience':'lontar-gateway','id.token.claim':'false','access.token.claim':'true'}}]}]}
  # Only one local pilot may run at once with this dedicated portable distribution.
  lockfile=kc/'lontar-pilot.lock';fd=os.open(lockfile,os.O_CREAT|os.O_EXCL|os.O_WRONLY,0o600);os.close(fd)
  imp=kc/'data/import';imp.mkdir(parents=True,exist_ok=True);realmfile=imp/'lontar-realm.json';write(realmfile,realm)
  def launch(cmd,env,name):
   log=open(a.output/f'{name}.log','w');logs.append(log);p=subprocess.Popen(cmd,env=env,stdout=log,stderr=subprocess.STDOUT);processes.append(p);manifest['services'].append({'name':name,'pid':p.pid});return p
  def stop(p):
   if p.poll() is None:
    p.terminate()
    try:p.wait(timeout=15)
    except subprocess.TimeoutExpired:p.kill();p.wait(timeout=5)
  try:
   env=os.environ.copy();env['JAVA_HOME']=str(java[0]);env['JAVA_OPTS_APPEND']='-Xms128m -Xmx512m -XX:ActiveProcessorCount=2'
   kp=launch([str(kc/'bin/kc.sh'),'start','--cache=local','--db=dev-mem','--http-enabled=false',f"--https-port={kcc['port']}",f"--https-certificate-file={kcc['cert']}",f"--https-certificate-key-file={kcc['key']}",'--https-protocols=TLSv1.3','--http-host=127.0.0.1',f"--hostname=https://localhost:{kcc['port']}",'--import-realm'],env,'keycloak')
   tokenctx=context(cfg['runner']);deadline=time.monotonic()+180
   while True:
    try:
     status,discovery=call(issuer+'/.well-known/openid-configuration',ctx=tokenctx)
     if status==200:break
    except Exception:pass
    if kp.poll() is not None or time.monotonic()>deadline:raise RuntimeError('Keycloak failed to start; inspect keycloak.log')
    time.sleep(.5)
   t=time.perf_counter_ns();status,tok=call(discovery['token_endpoint'],{'grant_type':'client_credentials','client_id':'workload-a','client_secret':secret,'scope':'decrypt'},tokenctx,True);token_ms=(time.perf_counter_ns()-t)/1e6
   if status!=200:raise RuntimeError('Keycloak token acquisition failed: '+str(tok.get('error')))
   token=tok['access_token'];claims=json.loads(b64(token.split('.')[1]));subject=claims['sub']
   manifest.update(issuer=issuer,idp_product='Keycloak 26.7.3',grant='client_credentials',subject=subject,token_acquisition_ms=token_ms,discovery_fields=sorted(discovery),python=sys.version,openssl=ssl.OPENSSL_VERSION)
   key=AESGCM.generate_key(256);nonce=os.urandom(12);plain=b'LONTAR v2 protected alpha payload';store=root/'kms/store.json';write(store,{'key_b64':base64.b64encode(key).decode(),'nonce_b64':base64.b64encode(nonce).decode(),'ciphertext_b64':base64.b64encode(AESGCM(key).encrypt(nonce,plain,b'alpha')).decode()});expected=sha(plain)
   revocation=root/'revocation.json';write(revocation,{'revoked':False})
   for role in ['collector','gateway','kms']:
    cfg[role].update(revocation=str(revocation),subject=subject,device='local-workload-host',store=str(store),service_hash=sha((HERE/'service.py').read_bytes()),audit=str(a.output/f'{role}_audit.jsonl'),collector_public=str(root/'collector.pub'),pdp_public=str(root/'gateway.pub'),issuer=issuer,audience='lontar-gateway',client_id='workload-a',collector_url=f"https://localhost:{cfg['collector']['port']}/",kms_url=f"https://localhost:{cfg['kms']['port']}/")
   children={}
   for role in ['collector','kms']:
    path=root/role/'config.json';write(path,cfg[role]);children[role]=launch([sys.executable,str(HERE/'service.py'),'--config',str(path)],os.environ.copy(),role)
    deadline=time.monotonic()+15
    while not Path(cfg[role]['ready']).exists():
     if children[role].poll() is not None or time.monotonic()>deadline:raise RuntimeError(role+' failed')
     time.sleep(.05)
   for block in range(a.blocks):
    policies=['L_OFF','S_OFF','L_ON','S_ON'];rng.shuffle(policies)
    for policy in policies:
     cfg['gateway']['policy']=policy;cfg['gateway']['port']=port();Path(cfg['gateway']['ready']).unlink(missing_ok=True);path=root/'gateway/config.json';write(path,cfg['gateway'])
     gp=launch([sys.executable,str(HERE/'service.py'),'--config',str(path)],os.environ.copy(),f'gateway_{block}_{policy}')
     deadline=time.monotonic()+20
     while not Path(cfg['gateway']['ready']).exists():
      if gp.poll() is not None or time.monotonic()>deadline:raise RuntimeError('gateway failed')
      time.sleep(.05)
     url=f"https://localhost:{cfg['gateway']['port']}/";clientctx=context(cfg['runner'])
     # One warmup per policy instance; included in audit, excluded from measured rows.
     status,_=call(url,{'trace_id':f'warmup-{block}-{policy}','access_token':token,'object':'alpha','operation':'decrypt'},clientctx)
     if status!=200:raise RuntimeError('warmup failed: '+str(status))
     cases=[(scenario,delay) for scenario in ['healthy_delay','posture_change','revocation'] for delay in [.3,2.3]];rng.shuffle(cases)
     for case,delay in cases:
      trace=f'{block}-{policy}-{case}-{delay}-{uuid.uuid4().hex[:8]}'
      store.chmod(0o600);write(revocation,{'revoked':False});fault={};cancel=threading.Event()
      def transition():
       deadline=time.monotonic()+10
       while not cancel.is_set() and time.monotonic()<deadline:
        audit=Path(cfg['gateway']['audit'])
        events=[json.loads(x) for x in audit.read_text().splitlines()] if audit.exists() else []
        if any(e['trace_id']==trace and e['event']=='permit' for e in events):
         if cancel.wait(.05):return
         if case=='posture_change':store.chmod(0o644)
         if case=='revocation':write(revocation,{'revoked':True})
         fault['transition_wall_ns']=time.time_ns();return
        cancel.wait(.005)
      worker=threading.Thread(target=transition);worker.start();start=time.perf_counter_ns()
      try:
       status,res=call(url,{'trace_id':trace,'access_token':token,'object':'alpha','operation':'decrypt','delay_seconds':delay},clientctx)
       latency=(time.perf_counter_ns()-start)/1e6
      finally:
       cancel.set();worker.join();store.chmod(0o600);write(revocation,{'revoked':False})
      if not fault:raise RuntimeError('Transition not observed')
      disclosed='plaintext_b64' in res;correct=disclosed and sha(base64.b64decode(res['plaintext_b64']))==expected
      permit=not (policy.startswith('S') and delay>2) and not (policy.endswith('ON') and case!='healthy_delay')
      passed=(status==200 and correct) if permit else (status==403 and not disclosed)
      rows.append({'trace_id':trace,'block':block,'policy':policy,'scenario':case,'requested_delay_seconds':delay,'latency_ms':latency,'http_status':status,'plaintext_disclosed':disclosed,'correct_plaintext':bool(correct),'expected_permit_by_policy':permit,'behavior_check_passed':passed,'contextual_exposure':case!='healthy_delay' and disclosed,'service_denial':case=='healthy_delay' and not disclosed,'reason':res.get('error'),**fault})
     stop(gp)
   # Validate each returned outcome against independent KMS audit.
   events=[json.loads(x) for x in (a.output/'kms_audit.jsonl').read_text().splitlines()]
   for r in rows:
    n=sum(e['trace_id']==r['trace_id'] and e['event']=='decrypted' for e in events);r['kms_decryptions']=n
    if n!=int(r['plaintext_disclosed']):raise RuntimeError('KMS/client outcome disagreement')
   gevents=[json.loads(x) for x in (a.output/'gateway_audit.jsonl').read_text().splitlines()]
   for r in rows:
    permit=next(e for e in gevents if e['trace_id']==r['trace_id'] and e['event']=='permit')
    receive=next(e for e in events if e['trace_id']==r['trace_id'] and e['event']=='received')
    r['actual_grant_age_seconds']=receive['wall_ns']/1e9-permit['issued_at']
    r['transition_after_issue_seconds']=r['transition_wall_ns']/1e9-permit['issued_at']
    assert 0<r['transition_after_issue_seconds']<r['actual_grant_age_seconds']
   manifest['all_behavior_checks_passed']=all(r['behavior_check_passed'] for r in rows);manifest['requests']=len(rows);manifest['status']='completed'
  finally:
   for p in reversed(processes):stop(p)
   for f in logs:f.close()
   realmfile.unlink(missing_ok=True);lockfile.unlink(missing_ok=True)
   (a.output/'results.jsonl').write_text(''.join(json.dumps(r)+'\n' for r in rows));write(a.output/'manifest.json',manifest);shutil.copy2(HERE/'protocol_v3.json',a.output/'protocol_v3.json')
 if not manifest.get('all_behavior_checks_passed'):raise SystemExit('Behavior check failed')
 print(json.dumps({'output':str(a.output),'requests':len(rows),'behavior_checks_passed':sum(r['behavior_check_passed'] for r in rows),'status':manifest['status']}))
if __name__=='__main__':main()
