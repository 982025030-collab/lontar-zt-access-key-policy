"""Pinned portable dependencies for the tested macOS arm64 laboratory."""
import hashlib,json,platform,tarfile,urllib.request
from pathlib import Path
HERE=Path(__file__).resolve().parent
if platform.system()!='Darwin' or platform.machine()!='arm64':raise SystemExit('This lock targets macOS arm64; obtain the matching JDK for your platform.')
lock=json.loads((HERE/'vendor_lock.json').read_text());vendor=HERE/'vendor';vendor.mkdir(exist_ok=True)
for name,item in lock.items():
 p=vendor/item['archive']
 if not p.exists():
  part=p.with_suffix(p.suffix+'.part')
  urllib.request.urlretrieve(item['url'],part);part.rename(p)
 with p.open('rb') as f:actual=hashlib.file_digest(f,'sha256').hexdigest()
 if actual!=item['sha256']:raise SystemExit('Checksum mismatch: '+name)
 if name=='java':
  target=vendor/'java'
  if not target.exists():
   target.mkdir()
   with tarfile.open(p) as t:t.extractall(target,filter='data')
 else:
  target=vendor/'keycloak'
  if not target.exists():
   unpack=vendor/'keycloak_unpack';unpack.mkdir(exist_ok=True)
   with tarfile.open(p) as t:t.extractall(unpack,filter='data')
   (unpack/'keycloak-26.7.3').rename(target);unpack.rmdir()
 print(name,'verified')
