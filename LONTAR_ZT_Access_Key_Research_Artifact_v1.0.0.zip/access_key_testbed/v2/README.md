# LONTAR-ZT v2 — proses terpisah, Keycloak, posture terukur, pilot biaya

Versi ini memperluas eksperimen v1; berkas dan hasil v1 tidak ditimpa. Protokol pilot dibekukan dalam `protocol_v2.json` sebelum pilot. Hasil bukan test final artikel dan tidak disertifikasi secara statistik.

## Yang sudah diimplementasikan

- Keycloak 26.7.3 sebagai proses Java tersendiri, HTTPS TLS 1.3, realm sementara dan basis data in-memory.
- Identitas workload melalui OAuth 2.0 `client_credentials`. Ini access token service account, bukan login manusia atau ID token OIDC.
- Gateway memakai discovery, issuer yang dikonfigurasi, JWKS RS256, verifikasi signature, issuer, audience, subject, authorized party/client, scope, expiry, issue time dan not-before. URI JWKS berasal dari discovery tepercaya, bukan header token.
- Collector, gateway/PEP, dan key manager berjalan dalam proses Python berbeda. Sertifikat TLS tiap layanan berbeda. Collector dan KMS membutuhkan mutual TLS dengan role gateway.
- Collector mengukur izin file key store yang benar-benar digunakan KMS, pemilik file, dan hash kode layanan. Posture bertanda tangan memuat identitas workload, perangkat yang dipetakan administrator, waktu dan hasil probe.
- Key manager melakukan dekripsi AES-256-GCM aktual dengan grant bertanda tangan yang terikat pada subject, objek, operasi, trace, audience, expiry, epoch, dan ID sekali pakai.
- Audit antarproses memakai trace ID. Hasil plaintext client dicocokkan dengan event dekripsi KMS.

Tidak ada skor ML atau ciphertext buatan yang dilaporkan sebagai hasil dataset publik. Nonce dan kunci dibuat acak untuk setiap run, tidak di-hardcode.

## Tiga kebijakan pilot

| Kebijakan | Gate akses | Izin penggunaan kunci |
|---|---|---|
| B0 | Identitas dan entitlement statis | Objek eksak, single-use, TTL 60 detik |
| B1 | Identitas, entitlement, dan posture terukur | Objek eksak, single-use, TTL tetap 60 detik |
| P | Gate posture yang sama dengan B1 | Objek eksak, single-use, expiry minimum dari 2 detik, expiry posture dan expiry token |

P adalah kandidat tetap untuk menguji plumbing dan biaya, belum hasil pemilihan kebijakan risk-bounded. B1 adalah pembanding dinamis yang lebih kuat; manfaat terhadap B0 tidak boleh dianggap otomatis sebagai manfaat terhadap B1. Semua memakai validasi token, entitlement, TLS, mTLS internal, signature grant dan KMS yang sama. B0 sengaja tidak menggunakan posture sehingga kegagalannya pada konteks posture buruk merupakan kelemahan kebijakan statis yang diketahui.

## Posture nyata dengan fault terkontrol

Collector membaca `stat` file key store dan SHA256 kode secara langsung, tanpa menerima field `healthy` dari client. Untuk skenario `insecure_store_mode`, harness mengubah mode key store sementara dari 0600 ke 0644 dan mengembalikannya setelah permintaan. Parent directory tetap 0700. Ini pengujian pelanggaran aturan permission yang terukur; bukan bukti data telah terbaca pengguna lain. UID dan integritas kode juga diukur, tetapi belum diuji dengan fault tersendiri.

Posture tidak mencakup EDR, patch age, FileVault, remote attestation, atau sensor perangkat fisik. Pemetaan workload–host dikelola konfigurasi, bukan bukti hardware-bound identity. Collector yang dikompromikan dapat berbohong. Keystore berisi kunci laboratorium dan berada di direktori sementara yang dihapus ketika proses selesai.

## Reproduksi

Diperlukan Python 3.12+ dengan `cryptography==50.0.1`, distribusi Keycloak dan Java portabel. Pada mesin ini dependensi ada di `vendor/`. Java tidak dipasang global. Paket ZIP hasil tidak menyertakan vendor berukuran besar. Untuk menyiapkan ulang dari arsip resmi yang dikunci:

```bash
python3 access_key_testbed/v2/prepare_vendor.py
python3 -m unittest discover -s access_key_testbed/v2 -p test_validation.py -v
python3 access_key_testbed/v2/run_pilot.py --blocks 20 --seed 20260910 --output access_key_testbed/v2/results/run_baru
```

Di komputer ini interpreter yang sudah memiliki cryptography adalah `/Users/meitonboru/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3`. Persiapan vendor memerlukan internet. Pilot membutuhkan izin membuka port loopback. Jangan jalankan dua pilot bersamaan pada distribusi Keycloak ini; lock mencegah penggunaan bersamaan. Gunakan direktori output baru. Semua proses dihentikan dan realm berisi secret sementara dihapus setelah selesai melalui jalur cleanup normal. Jika proses di-kill secara paksa, periksa dan hapus sisa kredensial sementara sebelum dipakai ulang.

`prepare_vendor.py` ditargetkan untuk macOS Apple Silicon sesuai mesin yang diuji. Platform lain memerlukan JDK yang sesuai dan penyesuaian lokasi Java. Hash Temurin diperiksa terhadap metadata resmi saat pengunduhan; hash Keycloak dikunci dari arsip HTTPS resmi yang diunduh, bukan hasil verifikasi tanda tangan upstream. Versi dan hash ada di `vendor_lock.json`.

## Pengukuran biaya dan batasnya

Dalam setiap blok, urutan B0/B1/P diacak, gateway di-restart, satu warm-up dijalankan, lalu empat skenario diacak. Keycloak, collector dan KMS tetap hidup sepanjang run. Kedua run pilot memakai startup penuh baru dan seed berbeda.

Latensi operasi diukur dari client sebelum HTTPS gateway sampai response selesai; memakai konteks TLS client yang sudah dibuat, tetapi koneksi HTTP/TLS baru untuk setiap permintaan. Mencakup validasi token di gateway, pengambilan posture sesuai kebijakan, enforcement KMS dan pengembalian plaintext. Akuisisi token diukur terpisah satu kali per run. Startup Java, warm-up, perubahan permission oleh harness, dan cleanup tidak menjadi biaya online selector. Tidak ada klaim session-resumption, koneksi pooled, concurrent load atau throughput.

Service CPU berasal dari `process_time_ns` pada handler; biaya CPU lintas layanan dapat dijumlahkan pada request yang serial. Elapsed gateway sudah mencakup waktu menunggu layanan internal; jangan menjumlahkan elapsed gateway, collector dan KMS sebagai latency end-to-end. Crypto CPU adalah bagian CPU KMS dan tidak ditambahkan lagi. Biaya CPU Keycloak saat penerbitan token tidak diukur.

Skenario negatif memiliki frekuensi seimbang buatan; bukan class prevalence produksi. Semua latensi, delta berpasangan dan biaya hanya deskriptif untuk pilot satu host. Tidak ada confidence interval populasi, uji signifikansi, biaya moneter, atau sertifikat risiko. Hasil pilot dapat digunakan merancang cost normalization dan ukuran studi selanjutnya, bukan memilih konfigurasi lalu mengklaim test independen pada data yang sama.

## Batas isolasi dan pekerjaan berikutnya

Proses sudah terpisah, tetapi masih berjalan sebagai pengguna OS yang sama dan dapat membaca file pengguna tersebut. Ini bukan isolasi keamanan container/VM, least-privilege antar-UID, HSM, atau deployment multi-host. Keycloak memakai mode start dengan HTTPS, namun database in-memory dan CA sementara menjadikannya lingkungan pengujian, bukan konfigurasi produksi.

Langkah berikutnya: pemisahan UID/container dan trust store per layanan, IdP eksternal bila tersedia, posture tambahan yang relevan, uji key lease/expiry dan revocation dengan skenario state transition nyata, serta pilot beban dan repeated-day blocks. Baru setelah biaya dan keluarga kebijakan ditetapkan, kumpulkan episode sertifikasi dan test independen. Keunggulan joint access–key terhadap B1 belum otomatis dibuktikan oleh pilot ini.

## Sumber primer

- Keycloak downloads: https://www.keycloak.org/downloads
- Keycloak server administration, service accounts: https://www.keycloak.org/docs/latest/server_admin/
- Keycloak configuration: https://www.keycloak.org/server/all-config
- OpenID Connect Discovery 1.0: https://openid.net/specs/openid-connect-discovery-1_0.html
- Eclipse Temurin: https://adoptium.net/installation

Panduan dibaca 10 September 2026. Tidak ada klaim sertifikasi konformansi OIDC untuk gateway khusus ini.
