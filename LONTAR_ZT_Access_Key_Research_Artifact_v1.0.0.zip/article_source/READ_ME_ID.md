# Paket artikel LONTAR-ZT

Judul: Evidence-Aware Risk-Bounded Access-Key Policy Selection for Zero-Trust Data Centers.

Lima tahap yang diminta sudah dijalankan dalam ruang lingkup laboratorium: kontribusi dan protokol dibekukan, selector diintegrasikan, enam pembanding diuji dengan keterlambatan dan ketidaktersediaan bukti, data baru dikumpulkan dalam tiga split, serta naskah LaTeX disusun dari hasil aktual.

Data utama terdiri dari 16 episode tuning, 107 sertifikasi, dan 100 test. Setiap episode memiliki 42 permintaan berpasangan sehingga total 9.366 permintaan. Sampel statistik tetap episode; angka 9.366 tidak dipakai sebagai jumlah sampel independen. Data pilot tidak digunakan ulang.

Selector memilih izin 60 detik dengan pemeriksaan bukti langsung, deadline 0,5 detik, dan fail-closed. Batas atas sertifikasi keamanan 4,9931% dan penolakan layanan 16,7621%, dibanding target laboratorium 5% dan 20%. Pada test: 0/100 episode mengalami paparan dalam tantangan yang diuji dan 5/100 permintaan sah ditolak karena bukti tidak tersedia. Selang 95% marginal test: keamanan 0-3,6217%, penolakan layanan 1,6432-11,2835%.

Hasil tersebut tidak membuktikan keunggulan atas baseline kuat yang sama. Ia menunjukkan bahwa selector menolak kebijakan murah yang tidak aman dan memilih kandidat yang memenuhi batas bersyarat. Izin pendek 2 detik bukan pemenang dalam campuran beban ini.

Klaim tetap dibatasi: satu host, proses layanan dipakai bersama antar-episode, konteks sintetis terkendali, dan asumsi IID bersyarat. Pengulangan lintas host/hari serta replikasi metode pembanding terdahulu secara lengkap belum dilakukan. Biaya yang tersedia adalah kegagalan, waktu dan CPU; kerugian finansial tidak direkayasa. Hysteresis, rollback, drift governance dan online adaptation tidak tercakup.

Naskah berstatus draf penelitian untuk pemeriksaan penulis. Lengkapi fakta kepenulisan, pendanaan, konflik kepentingan, CRediT dan identitas repositori sebelum submission. Kesesuaian editorial dan kuartil jurnal tetap perlu diperiksa pada tahun/kategori yang ditetapkan kampus.

Lihat SUBMISSION_STATUS.md untuk status format dan deklarasi, BUILD.md untuk kompilasi, serta paket replikasi untuk kode dan jejak pengukuran.
