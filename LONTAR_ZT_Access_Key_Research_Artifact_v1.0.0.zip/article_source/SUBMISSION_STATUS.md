# Submission status and author actions

The package is an executed research draft for author review. It is not a declaration that Computers & Security will accept the work or that every scientific concern has been resolved.

## Format and scope

The manuscript uses Elsevier `elsarticle`, editable LaTeX and BibTeX, numbered equations, captions, abstract and keywords. Submission sources will be flat in one folder, following Elsevier's general LaTeX instructions:
https://www.elsevier.com/researcher/author/policies-and-guidelines/latex-instructions

The journal-specific guide returned HTTP 403 during this preparation. Recheck its latest requirements in the submission interface:
https://www.sciencedirect.com/journal/computers-and-security/publish/guide-for-authors

Elsevier's official journal listing states exclusions for principal cryptology contributions and a moratorium for significant AI/ML components. This experiment has no ML component and no novel cipher, but the editor determines fit. The article's subject is access-key authorization and empirical policy selection. Do not conceal a significant learning contribution as an external input in later revisions.
https://shop.elsevier.com/journals/subjects/physical-sciences-and-engineering/computer-science/computer-systems-organization/computer-systems-organization-general

Choose the subscription option if the journal offers it for this article. Do not select paid open access by default. Verify any page, color, or other charges in the current portal. This document does not certify current prices, a current Q1 category/year, or acceptance.

## Declarations requiring factual confirmation

The following declarations are now supplied by the authors and incorporated in the manuscript:

- Meiton Boru (corresponding author), Irwan Sembiring, and Wiwin Sulistyo; all affiliated with the Faculty of Information Technology, Satya Wacana Christian University, Salatiga, Indonesia.
- Correspondence: 982025030@student.uksw.edu; ORCIDs are shown in the manuscript front matter.
- No external funding; the research is funded independently by the authors.
- No known competing financial interests or personal relationships.

The following still require completion before submission:

- CRediT roles approved by each author.
- Human approval of the AI-use statement after technical and citation review.
- A rights-holder-approved license, public GitHub release under `982025030-collab`, Zenodo archive, release tag, and DOI.

## Scientific boundaries

The strongest fixed baseline may equal the selected policy. Report this explicitly. Risk bounds use 107 blocks, not 4,494 independent requests, and depend on conditional IID assumptions. The study ran on one physical host: process separation does not create host-, device-, day-, or site-level independence. The exact intervals quantify only the laboratory block generator and exclude between-host/day operational variation. Six component baselines are not full reproductions of SMAAC or INFFLOW-RT. The posture probe is one local file-permission mode plus a controlled entitlement record; it is not remote attestation, TPM/TEE verification, boot-integrity validation, comprehensive device health, or IdP token revocation.

Before claiming submission readiness, the human research team should decide whether the systems formulation and conditional experimental evidence are sufficient for its novelty claim or whether a multi-host study and direct implementation of a nearest prior method are required. Formatting does not resolve that decision.
