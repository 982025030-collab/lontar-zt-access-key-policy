# LaTeX build

All submission sources are kept at one directory level. With a TeX Live installation providing `elsarticle`:

```sh
pdflatex manuscript.tex
bibtex manuscript
pdflatex manuscript.tex
pdflatex manuscript.tex
```

Alternatively use `tectonic --keep-logs --keep-intermediates manuscript.tex`.

The verified local compiler is Tectonic 0.17.0 for macOS ARM64. The downloaded archive SHA-256 was verified against the official GitHub release API:
`a3f1cac7c5678f01661a92212f58480ae3b0634115d880dbc59e2953ded45667`.

Analysis-generated tables must correspond to the included frozen experiment. Do not manually alter numeric cells in the LaTeX files. Re-run analysis after an authorized new study and rewrite the narrative to reflect its results. Changing the experiment after inspecting test data requires a new protocol and an untouched test split.
